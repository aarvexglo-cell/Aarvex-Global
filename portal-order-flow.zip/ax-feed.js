/* Aarvex Portal — Community Feed + profile cover + favourites shops tab +
 * notifications tabs + settings toggles.
 * Load AFTER portal-marketplace.js (wraps mpLoadNotifications/switchPanel)
 * and after ax-delivery-ux.js (shares small helpers).
 */
'use strict';

/* ── tiny helpers ── */
function axEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function axTimeAgo(iso) {
  if (!iso) return '';
  const d = new Date(/(?:Z|[+-]\d{2}:?\d{2})$/.test(iso) ? iso : iso + 'Z');
  if (isNaN(d.getTime())) return '';
  const s = Math.max(1, Math.floor((Date.now() - d.getTime()) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  if (s < 604800) return Math.floor(s / 86400) + 'd ago';
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}
function axCount(n) {
  n = +n || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return String(n);
}
function axAvatarHtml(name, photo, cls) {
  const initial = axEsc((name || 'A').trim().charAt(0).toUpperCase());
  return photo
    ? '<img class="' + cls + '" src="' + axEsc(photo) + '" alt="" loading="lazy">'
    : '<span class="' + cls + ' ax-avatar-initial">' + initial + '</span>';
}

/* ══════════════════ FEED ══════════════════ */
let _axFeedPosts = [];
let _axFeedNextOffset = null;
let _axFeedLoading = false;
let _axViewedIds = {};      // ids already counted this session
let _axViewQueue = [];
let _axViewTimer = null;
let _axFeedObserver = null;

async function axLoadFeed(reset) {
  const list = document.getElementById('axFeedList');
  if (!list || _axFeedLoading) return;
  _axFeedLoading = true;
  if (reset !== false) { _axFeedPosts = []; _axFeedNextOffset = null; }
  if (!_axFeedPosts.length) {
    list.innerHTML = '<div class="ax-feed-loading"><i class="fa-solid fa-spinner fa-spin"></i> Loading community feed…</div>';
  }
  try {
    const url = '/feed?limit=10' + (_axFeedNextOffset ? '&offset=' + _axFeedNextOffset : '');
    const data = await mpApi(url);
    const fresh = (data && data.posts) || [];
    _axFeedPosts = _axFeedNextOffset ? _axFeedPosts.concat(fresh) : fresh;
    _axFeedNextOffset = data ? data.next_offset : null;
    axRenderFeed();
  } catch (e) {
    if (!_axFeedPosts.length) list.innerHTML = '<div class="ax-feed-loading">Could not load the feed — pull to refresh.</div>';
  }
  _axFeedLoading = false;
}

function axRenderFeed() {
  const list = document.getElementById('axFeedList');
  const more = document.getElementById('axFeedMore');
  if (!list) return;
  if (!_axFeedPosts.length) {
    list.innerHTML =
      '<div class="ax-feed-empty">' +
        '<i class="fa-regular fa-images"></i>' +
        '<b>No posts yet</b>' +
        '<p>Be the first — share a photo or video of your produce, shop or delivery!</p>' +
        '<button type="button" class="btn-primary btn-sm" onclick="axOpenComposer()"><i class="fa-solid fa-plus"></i> Create the first post</button>' +
      '</div>';
    if (more) more.style.display = 'none';
    return;
  }
  const mySub = (typeof currentUser !== 'undefined' && currentUser) ? currentUser.sub : '';
  let html = '';
  _axFeedPosts.forEach(function (p, i) {
    html += axPostCardHtml(p, mySub);
    // Star Performer strip after every 2nd post.
    if ((i + 1) % 2 === 0) html += axFeedShopsStripHtml(((i + 1) / 2) - 1);
  });
  list.innerHTML = html;
  if (more) more.style.display = _axFeedNextOffset != null ? '' : 'none';
  // Standalone Star Performer band is redundant once it lives inside the feed.
  const standalone = document.getElementById('topShopsSection');
  if (standalone) standalone.style.display = _axFeedPosts.length >= 2 ? 'none' : '';
  axObserveViews();
}

function axPostCardHtml(p, mySub) {
  const own = p.user_sub === mySub;
  const media = p.media_url
    ? (p.media_type === 'video'
      ? '<video class="ax-post-media" src="' + axEsc(p.media_url) + '" controls playsinline preload="metadata"></video>'
      : '<img class="ax-post-media" src="' + axEsc(p.media_url) + '" alt="" loading="lazy" onclick="axOpenMedia(\'' + axEsc(p.media_url) + '\')">')
    : '';
  return '<article class="ax-post-card" data-post-id="' + axEsc(p.post_id) + '">' +
    '<header class="ax-post-head">' +
      axAvatarHtml(p.user_name, p.user_photo, 'ax-post-avatar') +
      '<div class="ax-post-head-text">' +
        '<b>' + axEsc(p.user_name) + '</b>' +
        '<small>' + axTimeAgo(p.created_at) + '</small>' +
      '</div>' +
      (own
        ? '<button type="button" class="ax-post-menu-btn" onclick="axPostMenu(\'' + axEsc(p.post_id) + '\')" aria-label="Post options"><i class="fa-solid fa-ellipsis"></i></button>'
        : '') +
    '</header>' +
    media +
    '<div class="ax-post-actions">' +
      '<button type="button" class="ax-post-act' + (p.liked_by_me ? ' liked' : '') + '" onclick="axToggleLike(\'' + axEsc(p.post_id) + '\', this)">' +
        '<i class="fa-' + (p.liked_by_me ? 'solid' : 'regular') + ' fa-heart"></i> <span>' + axCount(p.like_count) + '</span></button>' +
      '<button type="button" class="ax-post-act" onclick="axOpenComments(\'' + axEsc(p.post_id) + '\')">' +
        '<i class="fa-regular fa-comment"></i> <span>' + axCount(p.comment_count) + '</span></button>' +
      '<button type="button" class="ax-post-act" onclick="axSharePost(\'' + axEsc(p.post_id) + '\')">' +
        '<i class="fa-solid fa-arrow-up-from-bracket"></i></button>' +
      '<span class="ax-post-views"><i class="fa-regular fa-eye"></i> ' + axCount(p.view_count) + '</span>' +
    '</div>' +
    (p.description
      ? '<p class="ax-post-desc"><b>' + axEsc(p.user_name) + '</b> ' + axEsc(p.description) + '</p>'
      : '') +
    (p.comment_count > 0
      ? '<button type="button" class="ax-post-viewcomments" onclick="axOpenComments(\'' + axEsc(p.post_id) + '\')">View all ' + axCount(p.comment_count) + ' comments</button>'
      : '') +
  '</article>';
}

function axFeedShopsStripHtml(idx) {
  const shops = window._axTopShops || [];
  if (!shops.length) return '';
  const start = (idx * 3) % Math.max(shops.length, 1);
  const pick = shops.slice(start, start + 3).concat(shops.slice(0, Math.max(0, start + 3 - shops.length)));
  return '<div class="ax-feed-shops-strip">' +
    '<div class="ax-feed-shops-title"><i class="fa-solid fa-trophy"></i> Star Performer Shop</div>' +
    '<div class="ax-feed-shops-row">' +
      pick.map(function (s) {
        const name = s.shop_name || 'Shop';
        const initials = name.trim().split(/\s+/).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
        return '<button type="button" class="ax-star-shop-cell" onclick="navigateToShop(\'' + axEsc(s.shop_id) + '\')">' +
          (s.shop_logo_url
            ? '<img class="ax-star-shop-photo" src="' + axEsc(s.shop_logo_url) + '" alt="">'
            : '<div class="ax-star-shop-photo ax-star-shop-initials">' + axEsc(initials || 'S') + '</div>') +
          '<div class="ax-star-shop-name">' + axEsc(name) + '</div>' +
          '<div class="ax-star-shop-meta"><span class="ax-star-shop-rating"><i class="fa-solid fa-star"></i> ' + (s.avg_rating || 0) + '</span>' +
          '<span class="ax-star-shop-likes"><i class="fa-solid fa-heart"></i> ' + (s.like_count || 0) + '</span></div>' +
        '</button>';
      }).join('') +
    '</div></div>';
}

/* ── view counting (IntersectionObserver, batched) ── */
function axObserveViews() {
  if (!('IntersectionObserver' in window)) return;
  if (_axFeedObserver) _axFeedObserver.disconnect();
  _axFeedObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      const id = en.target.getAttribute('data-post-id');
      if (!id || _axViewedIds[id]) return;
      _axViewedIds[id] = true;
      _axViewQueue.push(id);
      _axFeedObserver.unobserve(en.target);
    });
    if (_axViewQueue.length) {
      clearTimeout(_axViewTimer);
      _axViewTimer = setTimeout(function () {
        const ids = _axViewQueue.splice(0, 25);
        mpApi('/feed/view', { method: 'POST', body: JSON.stringify({ post_ids: ids }) }).catch(function () {});
      }, 1200);
    }
  }, { threshold: 0.55 });
  document.querySelectorAll('#axFeedList .ax-post-card').forEach(function (el) {
    _axFeedObserver.observe(el);
  });
}

/* ── like / comment / share ── */
async function axToggleLike(postId, btn) {
  const data = await mpApi('/feed/like', { method: 'POST', body: JSON.stringify({ post_id: postId }) });
  if (!data || !data.success) { showToast((data && data.error) || 'Could not like', 'error'); return; }
  const p = _axFeedPosts.find(function (x) { return x.post_id === postId; });
  if (p) { p.liked_by_me = data.liked; p.like_count = data.like_count; }
  if (btn) {
    btn.classList.toggle('liked', data.liked);
    btn.innerHTML = '<i class="fa-' + (data.liked ? 'solid' : 'regular') + ' fa-heart"></i> <span>' + axCount(data.like_count) + '</span>';
  }
}

let _axCommentsPostId = null;
async function axOpenComments(postId) {
  _axCommentsPostId = postId;
  let sheet = document.getElementById('axCommentsSheet');
  if (sheet) sheet.remove();
  sheet = document.createElement('div');
  sheet.id = 'axCommentsSheet';
  sheet.className = 'ax-comments-overlay';
  sheet.innerHTML =
    '<div class="ax-comments-box">' +
      '<div class="ax-comments-head"><b>Comments</b>' +
        '<button type="button" class="ax-strip-icon-btn" onclick="document.getElementById(\'axCommentsSheet\').remove()" aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="ax-comments-list" id="axCommentsList"><p class="ax-feed-loading"><i class="fa-solid fa-spinner fa-spin"></i> Loading…</p></div>' +
      '<div class="ax-comments-inputrow">' +
        '<input type="text" id="axCommentInput" maxlength="300" placeholder="Write a comment…" autocomplete="off">' +
        '<button type="button" class="btn-primary btn-sm" onclick="axSubmitComment()"><i class="fa-solid fa-paper-plane"></i></button>' +
      '</div>' +
    '</div>';
  sheet.addEventListener('click', function (e) { if (e.target === sheet) sheet.remove(); });
  document.body.appendChild(sheet);
  const data = await mpApi('/feed/comments?post_id=' + encodeURIComponent(postId));
  const listEl = document.getElementById('axCommentsList');
  if (!listEl) return;
  const comments = (data && data.comments) || [];
  listEl.innerHTML = comments.length
    ? comments.map(function (c) {
        return '<div class="ax-comment-row">' +
          axAvatarHtml(c.user_name, c.user_photo, 'ax-comment-avatar') +
          '<div class="ax-comment-body"><b>' + axEsc(c.user_name) + '</b> ' + axEsc(c.text) +
          '<small>' + axTimeAgo(c.created_at) + '</small></div></div>';
      }).join('')
    : '<p class="ax-feed-loading">No comments yet — be the first!</p>';
  const inp = document.getElementById('axCommentInput');
  if (inp) {
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') axSubmitComment(); });
    inp.focus();
  }
}

async function axSubmitComment() {
  const inp = document.getElementById('axCommentInput');
  const text = (inp && inp.value || '').trim();
  if (!text || !_axCommentsPostId) return;
  inp.value = '';
  const data = await mpApi('/feed/comment', { method: 'POST', body: JSON.stringify({ post_id: _axCommentsPostId, text: text }) });
  if (data && data.success) {
    const p = _axFeedPosts.find(function (x) { return x.post_id === _axCommentsPostId; });
    if (p) p.comment_count = (+p.comment_count || 0) + 1;
    axOpenComments(_axCommentsPostId); // reload list
  } else {
    showToast((data && data.error) || 'Could not comment', 'error');
  }
}

async function axSharePost(postId) {
  const p = _axFeedPosts.find(function (x) { return x.post_id === postId; }) || {};
  const text = (p.user_name ? p.user_name + ' on Aarvex Global: ' : '') + (p.description || 'Check out this post on Aarvex Global!');
  const url = location.origin && location.origin !== 'null'
    ? location.origin + location.pathname + '?feed_post=' + encodeURIComponent(postId)
    : 'https://aarvexglobal.com/portal.html?feed_post=' + encodeURIComponent(postId);
  mpApi('/feed/share', { method: 'POST', body: JSON.stringify({ post_id: postId }) }).catch(function () {});
  if (navigator.share) {
    navigator.share({ title: 'Aarvex Global', text: text, url: url }).catch(function () {});
  } else if (typeof axCopyText === 'function') {
    axCopyText(url, null);
  }
}

/* ── owner menu: edit / delete ── */
function axPostMenu(postId) {
  const p = _axFeedPosts.find(function (x) { return x.post_id === postId; });
  let menu = document.getElementById('axPostMenuSheet');
  if (menu) menu.remove();
  menu = document.createElement('div');
  menu.id = 'axPostMenuSheet';
  menu.className = 'ax-comments-overlay';
  menu.innerHTML =
    '<div class="ax-postmenu-box">' +
      '<button type="button" class="ax-postmenu-item" onclick="axEditPost(\'' + axEsc(postId) + '\')"><i class="fa-solid fa-pen"></i> Edit caption</button>' +
      '<button type="button" class="ax-postmenu-item ax-postmenu-danger" onclick="axDeletePost(\'' + axEsc(postId) + '\')"><i class="fa-solid fa-trash-can"></i> Delete post</button>' +
      '<button type="button" class="ax-postmenu-item" onclick="document.getElementById(\'axPostMenuSheet\').remove()">Cancel</button>' +
    '</div>';
  menu.addEventListener('click', function (e) { if (e.target === menu) menu.remove(); });
  document.body.appendChild(menu);
}

async function axEditPost(postId) {
  document.getElementById('axPostMenuSheet')?.remove();
  const p = _axFeedPosts.find(function (x) { return x.post_id === postId; }) || {};
  const text = prompt('Edit your caption:', p.description || '');
  if (text == null) return;
  const data = await mpApi('/feed/edit', { method: 'POST', body: JSON.stringify({ post_id: postId, description: text.trim() }) });
  if (data && data.success) {
    if (p) p.description = text.trim();
    axRenderFeed();
    axLoadMyPosts();
    showToast('Post updated', 'success');
  } else showToast((data && data.error) || 'Could not update', 'error');
}

async function axDeletePost(postId) {
  document.getElementById('axPostMenuSheet')?.remove();
  if (!confirm('Delete this post permanently?')) return;
  const data = await mpApi('/feed/delete', { method: 'POST', body: JSON.stringify({ post_id: postId }) });
  if (data && data.success) {
    _axFeedPosts = _axFeedPosts.filter(function (x) { return x.post_id !== postId; });
    axRenderFeed();
    axLoadMyPosts();
    showToast('Post deleted', 'success');
  } else showToast((data && data.error) || 'Could not delete', 'error');
}

/* ── composer ── */
let _axComposeMedia = null; // { b64, type }
function axOpenComposer(withMedia) {
  let modal = document.getElementById('axComposerModal');
  if (modal) modal.remove();
  _axComposeMedia = null;
  modal = document.createElement('div');
  modal.id = 'axComposerModal';
  modal.className = 'ax-comments-overlay';
  modal.innerHTML =
    '<div class="ax-composer-box">' +
      '<div class="ax-comments-head"><b>New Post</b>' +
        '<button type="button" class="ax-strip-icon-btn" onclick="document.getElementById(\'axComposerModal\').remove()" aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<textarea id="axComposeText" maxlength="1000" rows="3" placeholder="Write a description… (produce, prices, shop updates, delivery stories)"></textarea>' +
      '<div id="axComposePreview" class="ax-compose-preview" style="display:none"></div>' +
      '<div class="ax-composer-actions">' +
        '<label class="btn-sm-outline" style="cursor:pointer"><i class="fa-solid fa-image"></i> Photo/Video' +
          '<input type="file" id="axComposeFile" accept="image/*,video/mp4,video/webm" style="display:none" onchange="axComposeFilePicked(this)"></label>' +
        '<button type="button" class="btn-primary" id="axComposeSubmitBtn" onclick="axSubmitPost()"><i class="fa-solid fa-paper-plane"></i> Post</button>' +
      '</div>' +
      '<p class="ax-radius-note">Photo/video max 5MB. Your name and profile photo appear with the post — visible to every signed-in user.</p>' +
    '</div>';
  modal.addEventListener('click', function (e) { if (e.target === modal) modal.remove(); });
  document.body.appendChild(modal);
  if (withMedia) document.getElementById('axComposeFile').click();
  else document.getElementById('axComposeText').focus();
}

function axComposeFilePicked(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (f.size > 5 * 1024 * 1024) { showToast('Max 5MB — choose a smaller file', 'error'); input.value = ''; return; }
  const isVideo = /^video\//.test(f.type);
  const fr = new FileReader();
  fr.onload = function () {
    _axComposeMedia = { b64: fr.result, type: isVideo ? 'video' : 'image' };
    const prev = document.getElementById('axComposePreview');
    if (prev) {
      prev.style.display = '';
      prev.innerHTML = (isVideo
        ? '<video src="' + fr.result + '" controls playsinline></video>'
        : '<img src="' + fr.result + '" alt="">') +
        '<button type="button" class="ax-strip-icon-btn ax-compose-remove" onclick="axComposeRemoveMedia()" aria-label="Remove media"><i class="fa-solid fa-xmark"></i></button>';
    }
  };
  fr.readAsDataURL(f);
}
function axComposeRemoveMedia() {
  _axComposeMedia = null;
  const prev = document.getElementById('axComposePreview');
  if (prev) { prev.style.display = 'none'; prev.innerHTML = ''; }
  const input = document.getElementById('axComposeFile');
  if (input) input.value = '';
}

async function axSubmitPost() {
  const btn = document.getElementById('axComposeSubmitBtn');
  const text = (document.getElementById('axComposeText')?.value || '').trim();
  if (!text && !_axComposeMedia) { showToast('Add a photo/video or a description', 'error'); return; }
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Posting…'; }
  const data = await mpApi('/feed/post', {
    method: 'POST',
    body: JSON.stringify({ description: text, media_b64: _axComposeMedia ? _axComposeMedia.b64 : '' }),
  });
  if (data && data.success) {
    document.getElementById('axComposerModal')?.remove();
    showToast('Posted to the community feed!', 'success');
    if (data.post) { _axFeedPosts.unshift(data.post); axRenderFeed(); }
    else axLoadFeed(true);
    axLoadMyPosts();
  } else {
    showToast((data && data.error) || 'Could not post', 'error');
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Post'; }
  }
}

function axOpenMedia(url) {
  let overlay = document.getElementById('axMediaOverlay');
  if (overlay) overlay.remove();
  overlay = document.createElement('div');
  overlay.id = 'axMediaOverlay';
  overlay.className = 'ax-media-overlay';
  overlay.innerHTML = '<img src="' + axEsc(url) + '" alt="">';
  overlay.addEventListener('click', function () { overlay.remove(); });
  document.body.appendChild(overlay);
}

/* ══════════════════ MY POSTS (profile grid) ══════════════════ */
async function axLoadMyPosts() {
  const grid = document.getElementById('axMyPostsGrid');
  if (!grid) return;
  const data = await mpApi('/feed?mine=1&limit=50');
  const posts = (data && data.posts) || [];
  if (!posts.length) {
    grid.innerHTML = '<p style="grid-column:1/-1;color:var(--c-text3);font-size:13px;text-align:center;padding:16px 0">No posts yet — share your first one from the Home tab.</p>';
    return;
  }
  // Keep them available for the edit/delete menu even if the home feed
  // hasn't loaded these posts.
  posts.forEach(function (p) {
    if (!_axFeedPosts.some(function (x) { return x.post_id === p.post_id; })) _axFeedPosts.push(p);
  });
  grid.innerHTML = posts.map(function (p) {
    const tile = p.media_url
      ? (p.media_type === 'video'
        ? '<video src="' + axEsc(p.media_url) + '" preload="metadata" muted></video><i class="fa-solid fa-play ax-mypost-play"></i>'
        : '<img src="' + axEsc(p.media_url) + '" alt="" loading="lazy">')
      : '<span class="ax-mypost-textonly">' + axEsc((p.description || '').slice(0, 60)) + '</span>';
    return '<button type="button" class="ax-mypost-tile" onclick="axPostMenu(\'' + axEsc(p.post_id) + '\')">' +
      tile +
      '<span class="ax-mypost-stats"><span><i class="fa-solid fa-heart"></i> ' + axCount(p.like_count) + '</span>' +
      '<span><i class="fa-solid fa-comment"></i> ' + axCount(p.comment_count) + '</span></span>' +
    '</button>';
  }).join('');
}

/* ══════════════════ PROFILE COVER ══════════════════ */
function axApplyCover(url) {
  const cover = document.getElementById('axProfileCover');
  if (!cover) return;
  cover.style.backgroundImage = url ? 'url("' + url + '")' : '';
  cover.classList.toggle('has-cover', !!url);
}
async function axUploadCover(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (f.size > 5 * 1024 * 1024) { showToast('Max 5MB', 'error'); input.value = ''; return; }
  const fr = new FileReader();
  fr.onload = async function () {
    showToast('Uploading cover…', 'info');
    const data = await mpApi('/profile/cover', { method: 'POST', body: JSON.stringify({ image_b64: fr.result }) });
    if (data && data.success) {
      axApplyCover(data.cover_photo_url);
      showToast('Cover photo updated', 'success');
    } else showToast((data && data.error) || 'Upload failed', 'error');
  };
  fr.readAsDataURL(f);
  input.value = '';
}
function axLoadCoverFromProfile() {
  try {
    if (typeof userProfile !== 'undefined' && userProfile && userProfile.cover_photo_url) {
      axApplyCover(userProfile.cover_photo_url);
    }
  } catch (e) {}
}

/* ══════════════════ FAVOURITES — Products | Shops ══════════════════ */
function axSetFavTab(tab) {
  document.querySelectorAll('.ax-fav-tab').forEach(function (b) {
    b.classList.toggle('active', b.dataset.favTab === tab);
  });
  const shops = document.getElementById('axFavShopsList');
  const panel = document.getElementById('panel-favourites');
  const grid = document.getElementById('favouritesGrid');
  const search = panel && panel.querySelector('.catalogue-search-sticky');
  if (shops) shops.style.display = tab === 'shops' ? '' : 'none';
  if (grid) grid.style.display = tab === 'shops' ? 'none' : '';
  if (search) search.style.display = tab === 'shops' ? 'none' : '';
  if (tab === 'shops') axLoadFavShops();
}
async function axLoadFavShops() {
  const list = document.getElementById('axFavShopsList');
  if (!list) return;
  list.innerHTML = '<p class="ax-feed-loading"><i class="fa-solid fa-spinner fa-spin"></i> Loading your shops…</p>';
  const data = await mpApi('/shop/favourites');
  const shops = (data && data.shops) || [];
  if (!shops.length) {
    list.innerHTML = '<div class="ax-feed-empty"><i class="fa-regular fa-heart"></i><b>No favourite shops yet</b>' +
      '<p>Open any shop profile and tap the like button to save it here.</p></div>';
    return;
  }
  list.innerHTML = shops.map(function (s) {
    const initials = (s.shop_name || 'S').trim().split(/\s+/).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
    const meta = [s.shop_category, [s.address_city, s.address_state].filter(Boolean).join(', ')].filter(Boolean).join(' · ');
    return '<button type="button" class="ax-shop-row" onclick="ProductModal.openShopProfile(\'' + axEsc(s.shop_id) + '\')">' +
      '<span class="ax-shop-row-avatar">' + axEsc(initials) + '</span>' +
      '<span class="ax-shop-row-info"><b>' + axEsc(s.shop_name) + '</b><small>' + axEsc(meta || 'Verified seller') + '</small></span>' +
      '<span class="ax-shop-row-meta"><span><i class="fa-solid fa-star"></i> ' + (s.avg_rating || 0) + '</span>' +
      '<span><i class="fa-solid fa-heart" style="color:#E1435A"></i> ' + (s.like_count || 0) + '</span></span>' +
    '</button>';
  }).join('');
}

/* ══════════════════ NOTIFICATIONS — General | Feed tabs ══════════════════ */
let _axNotifTab = 'general';
function axSetNotifTab(tab) {
  _axNotifTab = tab;
  document.querySelectorAll('.ax-notif-tab').forEach(function (b) {
    b.classList.toggle('active', b.dataset.notifTab === tab);
  });
  axApplyNotifFilter();
}
function axApplyNotifFilter() {
  const list = document.getElementById('notificationsList');
  if (!list) return;
  let shown = 0;
  list.querySelectorAll('.notif-item').forEach(function (el) {
    const t = el.getAttribute('data-ntype') || '';
    const isFeed = t.indexOf('feed_') === 0;
    const show = _axNotifTab === 'feed' ? isFeed : !isFeed;
    el.style.display = show ? '' : 'none';
    if (show) shown++;
  });
  let emptyEl = document.getElementById('axNotifTabEmpty');
  if (!shown) {
    if (!emptyEl) {
      emptyEl = document.createElement('p');
      emptyEl.id = 'axNotifTabEmpty';
      emptyEl.style.cssText = 'padding:24px;color:var(--c-text3);text-align:center;font-size:13px';
      list.appendChild(emptyEl);
    }
    emptyEl.textContent = _axNotifTab === 'feed'
      ? 'No feed activity yet — likes and comments on your posts will appear here.'
      : 'No notifications here.';
    emptyEl.style.display = '';
  } else if (emptyEl) {
    emptyEl.style.display = 'none';
  }
}

/* ══════════════════ SETTINGS toggles ══════════════════ */
function axToggleSetting(row, key) {
  const cur = localStorage.getItem(key) !== 'off'; // default ON
  localStorage.setItem(key, cur ? 'off' : 'on');
  axSyncSettingPills();
  showToast(cur ? 'Turned off' : 'Turned on', 'info');
}
function axSyncSettingPills() {
  document.querySelectorAll('.ax-toggle-pill[data-setting]').forEach(function (pill) {
    const on = localStorage.getItem(pill.dataset.setting) !== 'off';
    pill.classList.toggle('on', on);
  });
}
function axClearCachedData() {
  try {
    if (typeof axCategoryImagesPromise !== 'undefined') axCategoryImagesPromise = null;
    if (typeof axShopsCache !== 'undefined') axShopsCache = null;
  } catch (e) {}
  if (typeof loadCatalogue === 'function') loadCatalogue();
  if (typeof loadTopShops === 'function') loadTopShops();
  showToast('Cached data cleared — everything refreshed', 'success');
}

/* ══════════════════ WIRE-UP ══════════════════ */
(function () {
  // Composer avatar mirrors the signed-in user.
  function syncComposerAvatar() {
    const slot = document.getElementById('axFeedComposerAvatar');
    if (!slot || typeof currentUser === 'undefined' || !currentUser) return;
    const photo = (typeof userProfile !== 'undefined' && userProfile && (userProfile.custom_photo_url || userProfile.photo_url)) || currentUser.picture || '';
    slot.innerHTML = axAvatarHtml(currentUser.name || currentUser.email, photo, 'ax-post-avatar');
  }

  // Panel hooks — extend switchPanel (wrappers already chain safely).
  const _origSwitch = typeof switchPanel === 'function' ? switchPanel : null;
  if (_origSwitch) {
    switchPanel = function (panelId) {
      const r = _origSwitch(panelId);
      if (panelId === 'dashboard') { axLoadFeed(true); syncComposerAvatar(); }
      if (panelId === 'profile') { axLoadMyPosts(); axLoadCoverFromProfile(); }
      if (panelId === 'notifications') { setTimeout(axApplyNotifFilter, 600); }
      return r;
    };
  }
  // mpLoadNotifications re-renders the list — reapply the active tab filter.
  if (typeof mpLoadNotifications === 'function') {
    const _origNotifs = mpLoadNotifications;
    mpLoadNotifications = async function () {
      const r = await _origNotifs();
      axApplyNotifFilter();
      return r;
    };
  }
  document.addEventListener('DOMContentLoaded', function () {
    axSyncSettingPills();
    // First feed load once signed-in state settles.
    setTimeout(function () {
      if (document.body.classList.contains('is-signed-in')) {
        axLoadFeed(true);
        syncComposerAvatar();
      }
    }, 900);
  });
})();
