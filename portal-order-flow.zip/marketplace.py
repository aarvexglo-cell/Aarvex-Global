"""
Aarvex Global — Seller Marketplace, Portal, KYC, Reviews, Notifications.
Imported by advanced_features.py; routes wired in lambda_handler.py.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import traceback
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.parse import parse_qs, urlparse

import boto3
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError

logger = logging.getLogger()

DYNAMODB_TABLE = os.environ.get("DYNAMODB_TABLE_NAME") or os.environ.get("DYNAMODB_TABLE", "aarvex-social-bot-state")
S3_BUCKET = os.environ.get("S3_BUCKET_FOR_INVOICES") or os.environ.get("S3_BUCKET_FOR_CATALOGUE_MEDIA") or "aarvex-invoices-prod"
CLOUDFRONT_BASE = os.environ.get("CLOUDFRONT_BASE_URL", "https://dskm35im55r5u.cloudfront.net")
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "357965071326-2q1lss2e83ckuainhgrd0878p9i0oa3v.apps.googleusercontent.com")
ADMIN_TOTP_SECRET = os.environ.get("ADMIN_TOTP_SECRET", "")
if not ADMIN_TOTP_SECRET:
    logger.critical(
        "[SECURITY] ADMIN_TOTP_SECRET is not set — admin endpoints will DENY ALL requests "
        "until this env var is configured. This is intentional (fail-closed)."
    )

_db = boto3.resource("dynamodb")
table = _db.Table(DYNAMODB_TABLE)
s3 = boto3.client("s3")

AADHAAR_RE = re.compile(r"^\d{12}$")
PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$", re.I)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
try:
    from platform_utils import (
        ARN_RE,
        IFSC_RE,
        arn_valid,
        calc_payment_breakdown,
        create_payout_entries,
        decrypt_bank_field,
        encrypt_bank_field,
        generate_arn,
        get_bank_details_for_payout,
        get_platform_settings,
        list_payouts,
        mark_lot_sold,
        mark_payout_paid,
        mask_bank_account,
        normalize_arn,
        reverse_product_reservation,
        verify_recaptcha,
    )
    PLATFORM_UTILS_OK = True
except ImportError:
    PLATFORM_UTILS_OK = False
    ARN_RE = re.compile(r"^(AX\d{6}\d{6}|ARN-\d{4}-\d{6})$", re.I)
    IFSC_RE = re.compile(r"^[A-Z]{4}0[A-Z0-9]{6}$", re.I)

    def verify_recaptcha(token: str) -> bool:
        return bool(token and str(token).strip())

try:
    import delivery as _delivery_mod
except Exception as _del_err:
    _delivery_mod = None
    logger.warning("[DELIVERY] module not loaded: %s", _del_err)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ttl(days: int) -> int:
    import time
    return int(time.time()) + days * 86400


def _decimal(value: Any, default: Decimal = Decimal("0")) -> Decimal:
    try:
        return Decimal(str(value).strip())
    except (InvalidOperation, AttributeError, TypeError):
        return default


def _json_num(value: Any) -> int | float:
    d = _decimal(value)
    return int(d) if d == d.to_integral_value() else float(d)


def _json_response(status: int, body: Any) -> dict:
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Admin-Session",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
            # Without this, GET responses (e.g. /track, polled every 12s for
            # live delivery location) can get cached by the browser, a CDN,
            # or a mobile carrier's transparent proxy — the client then
            # silently keeps replaying the first response, so the map looks
            # frozen at one point even though the driver is actually moving
            # and the server has fresh coordinates on every request.
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
        },
        "body": json.dumps(body, default=str),
    }


def _event_body(event: dict) -> dict:
    body = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        body = base64.b64decode(body).decode("utf-8")
    return json.loads(body or "{}")


def _scan_by_pk_prefix(prefix: str) -> list[dict]:
    items = []
    kwargs = {"FilterExpression": Attr("pk").begins_with(prefix)}
    while True:
        resp = table.scan(**kwargs)
        items.extend(resp.get("Items", []))
        if "LastEvaluatedKey" not in resp:
            break
        kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    return items


def _first_name(name: str) -> str:
    return (name or "Customer").strip().split()[0]


def _admin_session_token() -> str:
    import hashlib
    import hmac
    seed = f"{ADMIN_TOTP_SECRET}:{datetime.utcnow().strftime('%Y%m%d%H')}"
    return hmac.new(seed.encode(), b"aarvex-admin", hashlib.sha256).hexdigest()


def _admin_authorized(event: dict) -> bool:
    import hashlib
    import hmac
    # SECURITY (fail-closed): if the secret was never configured, the
    # token above becomes predictable (empty-secret + guessable hour).
    # Deny everyone rather than silently accept a guessable token.
    if not ADMIN_TOTP_SECRET:
        logger.error("[SECURITY] Admin request denied — ADMIN_TOTP_SECRET not configured.")
        return False
    headers = event.get("headers") or {}
    token = (
        headers.get("X-Admin-Session")
        or headers.get("x-admin-session")
        or headers.get("Authorization", "").replace("Bearer ", "")
    )
    return bool(token and hmac.compare_digest(token, _admin_session_token()))


def _get_bearer_token(event: dict) -> str:
    headers = event.get("headers") or {}
    auth = headers.get("Authorization") or headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return ""


def verify_google_token(token: str) -> dict | None:
    """Verify Google ID token via tokeninfo endpoint."""
    if not token:
        return None
    import urllib.parse
    import urllib.request
    try:
        url = f"https://oauth2.googleapis.com/tokeninfo?id_token={urllib.parse.quote(token)}"
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
        if data.get("aud") and data["aud"] != GOOGLE_CLIENT_ID:
            logger.warning("[AUTH] Token aud mismatch: %s", data.get("aud"))
        if data.get("email_verified") == "false":
            return None
        return {
            "sub": data.get("sub", ""),
            "email": data.get("email", ""),
            "name": data.get("name", ""),
            "picture": data.get("picture", ""),
        }
    except Exception as e:
        logger.error("[AUTH] Google token verify failed: %s", e)
        return None


def _auth_user(event: dict) -> dict | None:
    token = _get_bearer_token(event)
    if not token:
        logger.warning("[AUTH] No Bearer token in request")
        return None
    user = verify_google_token(token)
    if not user or not user.get("sub"):
        logger.warning("[AUTH] Token verification failed — invalid or expired token")
        return None
    logger.info(f"[AUTH] OK — sub={user.get('sub','')[:12]}... email={user.get('email','')}")
    body = {}
    try:
        body = _event_body(event)
    except Exception:
        pass
    if body.get("user_sub") and body["user_sub"].startswith("email_"):
        return {
            "sub": body["user_sub"],
            "email": body.get("user_email") or user.get("email", ""),
            "name": body.get("user_name") or user.get("name", ""),
            "picture": user.get("picture", ""),
            "provider": "email",
        }
    return user


def _require_auth(event: dict) -> tuple[dict | None, dict | None]:
    user = _auth_user(event)
    if not user:
        return None, _json_response(401, {"error": "Unauthorized — valid Google token required"})
    profile = get_profile(user["sub"])
    if profile.get("account_status") == "blocked":
        return None, _json_response(403, {"error": "Account blocked"})
    return user, None


def get_profile(user_sub: str) -> dict:
    return table.get_item(Key={"pk": f"PROFILE#USER#{user_sub}"}).get("Item") or {}


def upsert_profile(user_sub: str, data: dict) -> None:
    item = get_profile(user_sub)
    item.update(data)
    item["pk"] = f"PROFILE#USER#{user_sub}"
    item["user_sub"] = user_sub
    item.setdefault("created_at", _now())
    item["updated_at"] = _now()
    table.put_item(Item=item)


def register_portal_user(user: dict) -> None:
    existing = get_profile(user["sub"])
    if existing:
        upsert_profile(user["sub"], {
            "user_name": user.get("name") or existing.get("user_name", ""),
            "user_email": user.get("email") or existing.get("user_email", ""),
            "picture": user.get("picture") or existing.get("picture", ""),
            "last_login": _now(),
        })
        return
    upsert_profile(user["sub"], {
        "user_name": user.get("name", ""),
        "user_email": user.get("email", ""),
        "user_email_verified": True,
        "picture": user.get("picture", ""),
        "account_status": "active",
        "joined_at": _now(),
        "last_login": _now(),
        "saved_addresses": [],
    })


def get_kyc(user_sub: str) -> dict:
    return table.get_item(Key={"pk": f"KYC#USER#{user_sub}"}).get("Item") or {}


def get_delivery_partner_contact(user_sub: str) -> dict:
    """Public-safe name + phone for a delivery partner who has claimed an
    order — shown to the buyer on the live tracking map (call button),
    the way Zomato/Swiggy show the rider's number. Only ever call this
    for a delivery partner who has actually claimed the specific order;
    never expose this for an unrelated user_sub."""
    if not user_sub:
        return {}
    profile = get_profile(user_sub)
    kyc = get_kyc(user_sub)
    return {
        "name": profile.get("user_name") or kyc.get("user_name") or "Delivery Partner",
        "phone": profile.get("mobile") or profile.get("phone", ""),
    }


def list_approved_delivery_partners() -> list[dict]:
    """All KYC-approved delivery partners (role delivery_partner or both),
    excluding anyone auto-suspended for repeated order rejection. Used to
    broadcast newly-placed orders to the delivery partner pool."""
    out = []
    for item in _scan_by_pk_prefix("KYC#USER#"):
        if item.get("status") != "approved":
            continue
        if item.get("kyc_role") not in ("delivery_partner", "both"):
            continue
        if item.get("delivery_suspended"):
            continue
        user_sub = item.get("user_sub", "")
        if not user_sub:
            continue
        prof = get_profile(user_sub)
        out.append({
            "user_sub": user_sub,
            "name": prof.get("user_name") or item.get("user_name") or "Delivery Partner",
            "phone": prof.get("mobile") or prof.get("phone", ""),
        })
    return out


def suspend_delivery_partner(user_sub: str, reason: str = "Repeated order rejection") -> None:
    """Auto-suspend a delivery partner's ability to receive/claim delivery
    orders (fraud-prevention: too many consecutive rejects). Their KYC
    record is kept for admin review — only the delivery capability is
    switched off, not the whole account."""
    if not user_sub:
        return
    table.update_item(
        Key={"pk": f"KYC#USER#{user_sub}"},
        UpdateExpression="SET delivery_suspended = :t, delivery_suspended_reason = :r, delivery_suspended_at = :d",
        ExpressionAttributeValues={":t": True, ":r": reason, ":d": _now()},
    )
    try:
        create_notification(
            user_sub, "kyc_update", "Delivery access suspended",
            f"Your delivery partner access has been suspended: {reason}. Contact support if you believe this is a mistake.",
        )
    except Exception as e:
        logger.warning("[DELIVERY] suspend notification failed: %s", e)


def get_shop(shop_id: str) -> dict:
    return table.get_item(Key={"pk": f"SHOP#{shop_id}"}).get("Item") or {}


def get_shop_by_user(user_sub: str) -> dict:
    kyc = get_kyc(user_sub)
    shop_id = kyc.get("shop_id", "")
    if shop_id:
        return get_shop(shop_id)
    for item in _scan_by_pk_prefix("SHOP#"):
        if item.get("user_sub") == user_sub:
            return item
    return {}


def _next_shop_id() -> str:
    try:
        resp = table.update_item(
            Key={"pk": "SHOP_SEQ#COUNTER"},
            UpdateExpression="SET seq = if_not_exists(seq, :zero) + :inc",
            ExpressionAttributeValues={":inc": 1, ":zero": 0},
            ReturnValues="UPDATED_NEW",
        )
        seq = int(resp["Attributes"]["seq"])
    except ClientError:
        seq = int(uuid.uuid4().int % 90000) + 10000
    return f"SHOP-AX-{seq:05d}"


def _upload_b64_to_s3(b64_data: str, key_prefix: str, filename: str) -> str:
    if not b64_data:
        return ""
    ext = "jpg"
    data = b64_data
    if "," in b64_data:
        header, data = b64_data.split(",", 1)
        for candidate in ("png", "gif", "webm", "mp4", "jpeg", "jpg"):
            if candidate in header.lower():
                ext = candidate
                break
    try:
        raw = base64.b64decode(data)
        key = f"{key_prefix}/{filename}.{ext}"
        content_types = {"png": "image/png", "gif": "image/gif", "webm": "video/webm", "mp4": "video/mp4", "jpeg": "image/jpeg", "jpg": "image/jpeg"}
        ct = content_types.get(ext, "application/octet-stream")
        s3.put_object(Bucket=S3_BUCKET, Key=key, Body=raw, ContentType=ct)
        return key
    except Exception as e:
        logger.error("[S3] Upload failed %s: %s", key_prefix, e)
        return ""


def _presigned_get(key: str, expires: int = 3600) -> str:
    if not key:
        return ""
    try:
        return s3.generate_presigned_url("get_object", Params={"Bucket": S3_BUCKET, "Key": key}, ExpiresIn=expires)
    except Exception:
        return ""


def _public_s3_url(key: str) -> str:
    if not key:
        return ""
    if key.startswith("http"):
        return key
    # Use CloudFront CDN URL instead of direct S3 URL (S3 bucket has public access blocked)
    base = CLOUDFRONT_BASE.rstrip("/")
    return f"{base}/{key}"


def create_notification(user_sub: str, ntype: str, title: str, body: str, **extra: Any) -> str:
    nid = str(uuid.uuid4())
    item = {
        "pk": f"NOTIFICATION#USER#{user_sub}#{nid}",
        "user_sub": user_sub,
        "notification_id": nid,
        "type": ntype,
        "title": title,
        "body": body,
        "is_read": False,
        "created_at": _now(),
        "ttl": _ttl(90),
    }
    item.update(extra)
    table.put_item(Item=item)
    return nid


def notify_seller_lead(product: dict, buyer_name: str, order_type: str, qty: Any) -> None:
    seller_sub = product.get("seller_user_sub") or product.get("shop_owner_sub")
    if not seller_sub:
        shop_id = product.get("shop_id", "")
        shop = get_shop(shop_id) if shop_id else {}
        seller_sub = shop.get("user_sub", "")
    if not seller_sub:
        return
    pname = product.get("product_name", "Product")
    create_notification(
        seller_sub,
        "new_lead",
        f"New lead on {pname}",
        f"Someone is interested in your {pname} — Qty: {qty} kg ({order_type})",
    )


def _shop_status_ok(shop_id: str) -> bool:
    if not shop_id:
        return True
    shop = get_shop(shop_id)
    return shop.get("status", "active") == "active"


def filter_catalogue_item(item: dict) -> bool:
    if not item.get("is_active", True):
        return False
    if item.get("lot_status") == "sold":
        return False
    if item.get("is_paused"):
        return False
    shop_id = item.get("shop_id", "")
    if shop_id and not _shop_status_ok(shop_id):
        return False
    if item.get("is_seller_product"):
        owner = item.get("seller_user_sub", "")
        if owner:
            prof = get_profile(owner)
            if prof.get("account_status") in ("blocked", "frozen"):
                return False
    return True


def serialize_product(item: dict, include_paused: bool = False) -> dict | None:
    if not include_paused and not filter_catalogue_item(item):
        if not (include_paused and item.get("is_active", True)):
            return None
    is_paused = bool(item.get("is_paused"))
    shop_id = item.get("shop_id", "")
    shop_blocked = shop_id and not _shop_status_ok(shop_id)
    lot_size = _decimal(item.get("lot_size_kg", 0))
    price_kg = _decimal(item.get("price_per_kg", 0))
    lot_price = _decimal(item.get("lot_price", 0))
    if lot_size > 0 and lot_price <= 0 and price_kg > 0:
        lot_price = lot_size * price_kg
    # ── MRP / discount (optional, fully backward-compatible) ──
    # Sellers may optionally set an "original" comparison price per kg.
    # discount_percent is 0 (and mrp fields are None) whenever no MRP is
    # set or the MRP isn't actually higher than the selling price — the
    # frontend hides the discount badge entirely in that case rather than
    # showing "0% OFF".
    mrp_kg = _decimal(item.get("mrp_price_per_kg", 0))
    discount_percent = 0
    mrp_lot_price = None
    if mrp_kg > 0 and price_kg > 0 and mrp_kg > price_kg:
        discount_percent = int(((mrp_kg - price_kg) / mrp_kg * 100).to_integral_value())
        if lot_size > 0:
            mrp_lot_price = lot_size * mrp_kg
    else:
        mrp_kg = Decimal("0")
    # available_stock_kg tracks REMAINING stock (starts == lot_size_kg at
    # creation, decremented atomically on every confirmed order). Older
    # listings created before this field existed fall back to lot_size.
    stock_kg = item.get("available_stock_kg")
    stock_kg = lot_size if stock_kg is None else _decimal(stock_kg)
    return {
        "product_id": item.get("product_id", ""),
        "product_name": item.get("product_name", ""),
        "category_id": item.get("category_id", ""),
        "category_name": item.get("category_name", ""),
        "description": item.get("description", ""),
        "price_per_kg": _json_num(price_kg),
        "mrp_price_per_kg": _json_num(mrp_kg) if mrp_kg > 0 else None,
        "discount_percent": discount_percent,
        "lot_size_kg": _json_num(lot_size) if lot_size > 0 else None,
        "lot_price": _json_num(lot_price) if lot_size > 0 else None,
        "mrp_lot_price": _json_num(mrp_lot_price) if mrp_lot_price is not None else None,
        "lot_status": item.get("lot_status", "available"),
        "min_order_kg": _json_num(item.get("min_order_kg", 0)),
        "available_stock_kg": _json_num(stock_kg),
        "available_stock": item.get("available_stock", "In Stock"),
        "image_url": item.get("image_url", ""),
        "image_urls": item.get("image_urls") or ([item.get("image_url")] if item.get("image_url") else []),
        "shop_id": shop_id,
        "shop_name": item.get("shop_name", ""),
        "avg_rating": _json_num(item.get("avg_rating", 0)),
        "total_reviews": int(_decimal(item.get("total_reviews", 0))),
        "is_seller_product": bool(item.get("is_seller_product")),
        "is_paused": is_paused or shop_blocked,
        "pk": item.get("pk", ""),
    }


def get_public_catalogue_enriched(include_paused: bool = True) -> dict:
    try:
        items = [i for i in _scan_by_pk_prefix("CATALOGUE#CATEGORY#") if i.get("is_active", True)]
        products = []
        for item in items:
            ser = serialize_product(item, include_paused=include_paused)
            if ser:
                products.append(ser)
        products.sort(key=lambda p: (p["category_name"], p["product_name"]))
        categories = sorted({p["category_name"] for p in products if p.get("category_name")})
        return {"products": products, "total": len(products), "categories": categories}
    except Exception as e:
        logger.error("[CATALOGUE] enriched failed: %s", e, exc_info=True)
        return {"products": [], "total": 0, "categories": []}


def handle_track_order(event: dict) -> dict:
    method = event.get("requestContext", {}).get("http", {}).get("method") or event.get("httpMethod", "GET")
    if method == "OPTIONS":
        return _json_response(200, {})
    if _delivery_mod:
        return _delivery_mod.handle_track_enriched(event)
    params = event.get("queryStringParameters") or {}
    arn = normalize_arn(params.get("arn") or "")
    if not arn_valid(arn):
        return _json_response(400, {"error": "Invalid Order ID format"})
    item = table.get_item(Key={"pk": f"ORDER#{arn}"}).get("Item") or {}
    if not item:
        return _json_response(404, {"error": "Order not found"})
    return _json_response(200, {"order": item, "arn": arn})


def handle_order_cancel(event: dict) -> dict:
    """Self-service order cancellation (new in the claim-time stock
    reservation phase — this endpoint did not exist before).

    Cancellable window:
      - status == "PENDING_DELIVERY" (nothing claimed yet): nothing was
        ever reserved, so this is a pure status-only cancellation — no
        stock effect.
      - status == "DELIVERY_ASSIGNED" (claimed, journey not yet started):
        a claim-time stock reservation exists (see
        delivery.handle_delivery_claim / platform_utils.reserve_product_stock)
        and must be reversed so available stock / public catalogue
        visibility goes back to exactly what it was before the claim —
        automatically, no admin action required.
    Once status is "IN_TRANSIT"/"NEAR_DESTINATION"/"COMPLETED" (or anything
    else), this self-service endpoint rejects the cancellation with 409.
    ASSUMPTION (flag for the owner to confirm or adjust): the cutoff is set
    at journey-start because cash/the delivery run has already begun by
    then, so cancelling past that point needs a support conversation
    instead of a one-tap self-service button.
    """
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    arn = normalize_arn(body.get("arn", ""))
    if not arn_valid(arn):
        return _json_response(400, {"error": "Invalid ARN"})
    if not _delivery_mod:
        return _json_response(503, {"error": "Delivery service unavailable"})

    rec = _delivery_mod._get_delivery_record(arn)
    if not rec:
        return _json_response(404, {"error": "Order not found"})
    if rec.get("importer_sub") != user["sub"]:
        return _json_response(403, {"error": "You can only cancel your own orders"})

    status = rec.get("status", "")
    if status not in ("PENDING_DELIVERY", "DELIVERY_ASSIGNED"):
        return _json_response(409, {"error": "Delivery already in progress — contact support to cancel"})

    # ── Reverse the claim-time reservation, if any. A legacy delivery
    # record (created before this phase) or one cancelled before ever
    # being claimed simply has no product_pk/reserved_kg to reverse —
    # reverse_product_reservation() logs a warning and no-ops rather than
    # raising, so cancellation still proceeds either way. ──
    product_pk = rec.get("product_pk", "")
    reserved_kg = rec.get("reserved_kg", 0)
    reversed_stock = False
    if status == "DELIVERY_ASSIGNED":
        try:
            reversed_stock = bool(reverse_product_reservation(product_pk, reserved_kg, arn))
        except Exception as e:
            logger.error("[ORDER][CANCEL] stock reversal failed for %s: %s", arn, e, exc_info=True)

    try:
        table.update_item(
            Key={"pk": f"DELIVERY#ARN#{arn}"},
            UpdateExpression="SET #s = :s, cancelled_at = :t, cancelled_by = :who",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": "CANCELLED", ":t": _now(), ":who": "buyer"},
        )
    except Exception as e:
        logger.error("[ORDER][CANCEL] delivery record update failed for %s: %s", arn, e)
    try:
        table.update_item(
            Key={"pk": f"ORDER#{arn}"},
            UpdateExpression="SET current_status = :s, last_updated = :u",
            ExpressionAttributeValues={":s": "Cancelled", ":u": _now()},
        )
    except Exception as e:
        logger.warning("[ORDER][CANCEL] order record update failed for %s: %s", arn, e)

    seller_sub = rec.get("seller_sub", "")
    if seller_sub:
        try:
            create_notification(
                seller_sub, "shop_status", "Order cancelled",
                f"Order {arn} for {rec.get('product_name', 'your product')} was cancelled by the buyer."
                + (" Stock has been restored." if reversed_stock else ""),
                arn=arn,
            )
        except Exception as e:
            logger.warning("[ORDER][CANCEL] seller notification failed: %s", e)

    claimed_by = rec.get("claimed_by", "")
    if status == "DELIVERY_ASSIGNED" and claimed_by:
        try:
            create_notification(
                claimed_by, "shop_status", "Order cancelled",
                f"The buyer cancelled order {arn} — no action needed on your end.",
                arn=arn,
            )
        except Exception as e:
            logger.warning("[ORDER][CANCEL] delivery partner notification failed: %s", e)
        try:
            partner_contact = get_delivery_partner_contact(claimed_by)
            if partner_contact.get("phone"):
                from advanced_features import send_whatsapp_text
                send_whatsapp_text(
                    partner_contact["phone"],
                    f"❌ Order {arn} was cancelled by the buyer before the journey started. No action needed.",
                )
        except Exception as e:
            logger.warning("[ORDER][CANCEL] WhatsApp to delivery partner failed: %s", e)

    return _json_response(200, {"success": True, "arn": arn, "stock_restored": reversed_stock})


def _validate_bank_details(body: dict) -> str | None:
    holder = (body.get("bank_account_holder") or body.get("bank_holder") or "").strip()
    bank_name = (body.get("bank_name") or "").strip()
    acct = re.sub(r"\D", "", body.get("bank_account_number") or body.get("bank_account") or "")
    ifsc = (body.get("bank_ifsc") or body.get("ifsc") or "").strip().upper()
    if not holder or not bank_name or not acct or not ifsc:
        return "Bank account holder, bank name, account number and IFSC are required"
    if not (9 <= len(acct) <= 18):
        return "Account number must be 9-18 digits"
    if not IFSC_RE.match(ifsc):
        return "Invalid IFSC code format"
    return None


def _encrypt_bank_field(value: str) -> str:
    """Reversible encryption (was a one-way HMAC hash before — that made
    the account number permanently unrecoverable, so payouts could never
    actually be sent). See platform_utils.encrypt_bank_field / BANK_ENCRYPTION_KEY."""
    if not PLATFORM_UTILS_OK:
        raise RuntimeError("platform_utils not available — cannot safely store bank details")
    return encrypt_bank_field(value)


def get_shop_subscription(user_sub: str) -> dict:
    return table.get_item(Key={"pk": f"SUBSCRIPTION#USER#{user_sub}"}).get("Item") or {}


def is_subscription_active(user_sub: str) -> bool:
    sub = get_shop_subscription(user_sub)
    if sub.get("status") != "active":
        return False
    expires = int(sub.get("expires_at_ts") or 0)
    if expires and expires < int(__import__("time").time()):
        return False
    return True


def handle_kyc_submit(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    aadhaar = re.sub(r"\D", "", body.get("aadhaar_number", ""))
    pan = (body.get("pan_number") or "").strip().upper()
    kyc_role = (body.get("kyc_role") or "shop_owner").strip().lower()
    if kyc_role not in ("shop_owner", "delivery_partner", "both"):
        kyc_role = "shop_owner"
    bank_err = _validate_bank_details(body)
    if bank_err:
        return _json_response(400, {"error": bank_err})
    if not AADHAAR_RE.match(aadhaar):
        return _json_response(400, {"error": "Invalid Aadhaar number (12 digits required)"})
    if pan and not PAN_RE.match(pan):
        return _json_response(400, {"error": "Invalid PAN format"})
    if not body.get("declaration_accepted"):
        return _json_response(400, {"error": "Declaration must be accepted"})
    recaptcha_token = (body.get("recaptcha_token") or "").strip()
    if not verify_recaptcha(recaptcha_token):
        return _json_response(400, {"error": "Captcha verification failed. Please try again."})

    register_portal_user(user)
    user_sub = user["sub"]
    prefix = f"kyc/{user_sub}"
    front_key = _upload_b64_to_s3(body.get("aadhaar_front_b64", ""), prefix, "aadhaar_front")
    back_key = _upload_b64_to_s3(body.get("aadhaar_back_b64", ""), prefix, "aadhaar_back")
    sig_key = _upload_b64_to_s3(body.get("signature_b64", ""), prefix, "signature")
    if not front_key or not back_key or not sig_key:
        return _json_response(400, {"error": "All KYC document uploads are required (front, back, signature)"})

    acct = re.sub(r"\D", "", body.get("bank_account_number") or body.get("bank_account") or "")
    item = {
        "pk": f"KYC#USER#{user_sub}",
        "user_sub": user_sub,
        "user_name": body.get("full_name") or user.get("name", ""),
        "user_email": user.get("email", ""),
        "aadhaar_last4": aadhaar[-4:],
        "aadhaar_front_s3_key": front_key,
        "aadhaar_back_s3_key": back_key,
        "signature_s3_key": sig_key,
        "pan_number": pan,
        "kyc_role": kyc_role,
        "bank_account_holder": body.get("bank_account_holder") or body.get("bank_holder", ""),
        "bank_name": body.get("bank_name", ""),
        "bank_account_enc": _encrypt_bank_field(acct),
        "bank_account_masked": mask_bank_account(acct) if PLATFORM_UTILS_OK else "",
        "bank_ifsc": (body.get("bank_ifsc") or "").strip().upper(),
        "bank_branch": body.get("bank_branch", ""),
        "status": "pending",
        "submitted_at": _now(),
        "reviewed_at": "",
        "rejection_reason": "",
        "shop_id": "",
    }
    table.put_item(Item=item)
    create_notification(user_sub, "kyc_update", "KYC Submitted", "Your KYC has been submitted and is under review.")
    return _json_response(200, {"success": True, "status": "pending"})


def handle_kyc_status(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    register_portal_user(user)
    kyc = get_kyc(user["sub"])
    shop = get_shop_by_user(user["sub"])
    prof = get_profile(user["sub"])
    sub = get_shop_subscription(user["sub"])
    return _json_response(200, {
        "kyc": {
            "status": kyc.get("status", "none"),
            "kyc_role": kyc.get("kyc_role", "shop_owner"),
            "submitted_at": kyc.get("submitted_at", ""),
            "rejection_reason": kyc.get("rejection_reason", ""),
            "shop_id": kyc.get("shop_id", ""),
            "delivery_suspended": bool(kyc.get("delivery_suspended", False)),
        },
        "subscription": {
            "status": sub.get("status", "none"),
            "active": is_subscription_active(user["sub"]),
            "expires_at": sub.get("expires_at", ""),
        },
        "shop": {
            "shop_id": shop.get("shop_id", ""),
            # Backward-compat: shops created before the custom shop-name field
            # existed have no "shop_name" attribute at all -- fall back to
            # their system-generated shop_id so nothing renders blank.
            "shop_name": shop.get("shop_name") or shop.get("shop_id", ""),
            "status": shop.get("status", ""),
            "product_count": int(_decimal(shop.get("product_count", 0))),
        } if shop else None,
        "profile": {
            "account_status": prof.get("account_status", "active"),
            "phone": prof.get("phone", ""),
        },
    })


def handle_shop_create(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    kyc = get_kyc(user["sub"])
    if kyc.get("status") != "approved":
        return _json_response(403, {"error": "KYC must be approved before creating a shop"})
    if kyc.get("kyc_role") not in ("shop_owner", "both"):
        return _json_response(403, {"error": "Shop owner role required in KYC"})
    if not is_subscription_active(user["sub"]):
        return _json_response(402, {"error": "Active shop subscription required (₹200/month). Please subscribe first.", "needs_subscription": True})
    if get_shop_by_user(user["sub"]):
        return _json_response(400, {"error": "Shop already exists"})
    if not body.get("terms_accepted"):
        return _json_response(400, {"error": "Terms must be accepted"})

    shop_name = (body.get("shop_name") or "").strip()
    if not shop_name:
        return _json_response(400, {"error": "Shop name is required"})
    if len(shop_name) > 60:
        return _json_response(400, {"error": "Shop name must be 60 characters or fewer"})
    # Publicly displayed field -- keep it to plain alphanumerics + common
    # punctuation so nothing that looks like markup/script can be stored.
    if not re.match(r"^[A-Za-z0-9À-ÿ .,&\x27\-]+$", shop_name):
        return _json_response(400, {"error": "Shop name contains invalid characters"})

    shop_id = _next_shop_id()
    shop = {
        "pk": f"SHOP#{shop_id}",
        "shop_id": shop_id,
        "shop_name": shop_name,
        "user_sub": user["sub"],
        "user_name": user.get("name", ""),
        "user_email": user.get("email", ""),
        "shop_description": (body.get("shop_description") or "")[:200],
        "shop_category": body.get("shop_category", "Other"),
        "address_city": body.get("address_city", ""),
        "address_state": body.get("address_state", ""),
        "address_pincode": body.get("address_pincode", ""),
        "gst_number": body.get("gst_number", ""),
        "status": "active",
        "created_at": _now(),
        "kyc_verified": True,
        "product_count": 0,
        "avg_rating": Decimal("0"),
        "total_reviews": 0,
        "like_count": 0,
    }
    table.put_item(Item=shop)
    table.update_item(
        Key={"pk": f"KYC#USER#{user['sub']}"},
        UpdateExpression="SET shop_id = :s",
        ExpressionAttributeValues={":s": shop_id},
    )
    create_notification(user["sub"], "kyc_update", "Shop Created", f"Your shop '{shop_name}' has been created!")
    return _json_response(200, {"success": True, "shop_id": shop_id, "shop_name": shop_name})


def handle_shop_info(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    shop = get_shop_by_user(user["sub"])
    if not shop:
        return _json_response(404, {"error": "No shop found"})
    out = dict(shop)
    out["shop_name"] = shop.get("shop_name") or shop.get("shop_id", "")
    out["avg_rating"] = _json_num(out.get("avg_rating", 0))
    out["product_count"] = int(_decimal(out.get("product_count", 0)))
    return _json_response(200, {"shop": out})


def handle_shop_toggle(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    shop = get_shop_by_user(user["sub"])
    if not shop:
        return _json_response(404, {"error": "No shop found"})
    new_status = "paused" if shop.get("status") == "active" else "active"
    table.update_item(
        Key={"pk": f"SHOP#{shop['shop_id']}"},
        UpdateExpression="SET #s = :s, updated_at = :u",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": new_status, ":u": _now()},
    )
    create_notification(user["sub"], "shop_status", "Shop Status Updated", f"Your shop is now {new_status}.")
    return _json_response(200, {"success": True, "status": new_status})


def _safe_product_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", value or "")[:80]


def _get_seller_product(user_sub: str, product_id: str, category_id: str = "") -> dict:
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if item.get("seller_user_sub") != user_sub:
            continue
        pid = item.get("product_id", "")
        if pid == product_id and (not category_id or item.get("category_id") == category_id):
            return item
    return {}


def _get_claimed_orders_by_product() -> dict:
    """Seller-side "claimed order" visibility (claim-time reservation
    phase): maps product_pk -> list of active claimed-order entries, so a
    seller can see who claimed their reserved/partially-sold stock without
    a full order-management redesign. Covers both the full-lot case
    (product is hidden from the public catalogue, lot_status="reserved")
    and the partial case (product stays listed with reduced
    available_stock_kg) — either way, any DELIVERY#ARN#{arn} record whose
    product_pk matches and whose status is still "in flight" (claimed but
    not yet completed) is surfaced here. Completed orders are finalized
    (and, for full lots, deleted) by then, so they no longer need this."""
    out: dict[str, list] = {}
    if not _delivery_mod:
        return out
    active_statuses = ("DELIVERY_ASSIGNED", "IN_TRANSIT", "NEAR_DESTINATION")
    for item in _delivery_mod._scan_prefix("DELIVERY#ARN#"):
        product_pk = item.get("product_pk", "")
        if not product_pk or item.get("status") not in active_statuses:
            continue
        claimed_by = item.get("claimed_by", "")
        partner_contact = get_delivery_partner_contact(claimed_by) if claimed_by else {}
        out.setdefault(product_pk, []).append({
            "arn": item.get("arn", ""),
            "buyer_name": item.get("buyer_name", ""),
            "buyer_mobile": item.get("buyer_mobile", ""),
            "delivery_partner_name": partner_contact.get("name", ""),
            "delivery_partner_mobile": partner_contact.get("phone", ""),
            "status": item.get("status", ""),
            "reserved_kg": _json_num(item.get("reserved_kg", 0)),
        })
    return out


def handle_shop_products_list(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    shop = get_shop_by_user(user["sub"])
    claimed_by_product = _get_claimed_orders_by_product()
    products = []
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if item.get("seller_user_sub") == user["sub"]:
            ser = serialize_product(item, include_paused=True)
            if ser:
                claims = claimed_by_product.get(ser.get("pk", ""), [])
                if claims:
                    ser["claimed_orders"] = claims
                products.append(ser)
    return _json_response(200, {"products": products, "shop": shop.get("shop_id", "")})


def handle_shop_product_add(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    shop = get_shop_by_user(user["sub"])
    if not shop or shop.get("status") == "blocked":
        return _json_response(403, {"error": "Active shop required"})
    kyc = get_kyc(user["sub"])
    if kyc.get("status") != "approved":
        return _json_response(403, {"error": "KYC not approved"})

    category_id = (body.get("category_id") or body.get("category_name") or "other").strip().lower().replace(" ", "_")
    category_name = (body.get("category_name") or category_id.replace("_", " ").title()).strip()
    product_name = (body.get("product_name") or "").strip()
    if not product_name:
        return _json_response(400, {"error": "product_name required"})
    product_id = (body.get("product_id") or "").strip() or _safe_product_id(product_name.lower().replace(" ", "_"))[:40]

    lot_size = _decimal(body.get("lot_size_kg"), Decimal("0"))
    price_kg = _decimal(body.get("price_per_kg") or 0)
    if lot_size <= 0:
        return _json_response(400, {"error": "lot_size_kg is required (fixed lot listing)"})
    lot_price = lot_size * price_kg if price_kg > 0 else _decimal(body.get("lot_price"), Decimal("0"))
    # Optional "original"/comparison price the seller can set to show a
    # strikethrough MRP + discount badge on the storefront. Left at 0 when
    # not provided — serialize_product() then omits the discount entirely.
    mrp_kg = _decimal(body.get("mrp_price_per_kg") or 0)

    image_urls = []
    for i, b64 in enumerate(body.get("images_b64") or []):
        if b64:
            key = _upload_b64_to_s3(b64, f"products/{shop['shop_id']}", f"{product_id}_{i}")
            if key:
                image_urls.append(_public_s3_url(key))
    if body.get("image_url"):
        image_urls.append(body["image_url"])

    pk = f"CATALOGUE#CATEGORY#{category_id}#{product_id}"
    item = {
        "pk": pk,
        "category_id": category_id,
        "category_name": category_name,
        "product_id": product_id,
        "product_name": product_name,
        "description": (body.get("description") or "")[:500],
        "price_per_kg": price_kg,
        "mrp_price_per_kg": mrp_kg,
        "lot_size_kg": lot_size,
        "available_stock_kg": lot_size,
        "lot_price": lot_price,
        "lot_status": "available",
        "min_order_kg": lot_size,
        "available_stock": f"1 lot ({int(lot_size)} kg)",
        "image_url": image_urls[0] if image_urls else "",
        "image_urls": image_urls,
        "is_active": True,
        "is_paused": False,
        "is_seller_product": True,
        "seller_user_sub": user["sub"],
        "shop_id": shop["shop_id"],
        "shop_name": shop.get("shop_name") or shop["shop_id"],
        "avg_rating": Decimal("0"),
        "total_reviews": 0,
        "updated_at": _now(),
    }
    table.put_item(Item=item)
    table.update_item(
        Key={"pk": f"SHOP#{shop['shop_id']}"},
        UpdateExpression="SET product_count = if_not_exists(product_count, :z) + :one",
        ExpressionAttributeValues={":z": 0, ":one": 1},
    )
    return _json_response(200, {"success": True, "product_id": product_id, "pk": pk})


def handle_shop_product_edit(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    product_id = body.get("product_id", "")
    category_id = body.get("category_id", "")
    existing = _get_seller_product(user["sub"], product_id, category_id)
    if not existing:
        return _json_response(404, {"error": "Product not found"})

    updates = {}
    for field, key in (
        ("product_name", "product_name"), ("description", "description"),
        ("available_stock", "available_stock"), ("category_name", "category_name"),
    ):
        if body.get(field) is not None:
            updates[key] = body[field]
    if body.get("lot_size_kg") is not None:
        ls = _decimal(body["lot_size_kg"])
        updates["lot_size_kg"] = ls
        # Editing lot_size_kg means the seller is re-stocking — reset the
        # remaining/available counter to match, and re-activate the listing
        # in case it had been auto-deleted/deactivated by a previous sellout.
        updates["available_stock_kg"] = ls
        updates["is_active"] = True
        updates["lot_status"] = "available"
        pk = _decimal(body.get("price_per_kg") or existing.get("price_per_kg", 0))
        updates["lot_price"] = ls * pk
        updates["min_order_kg"] = ls
        updates["available_stock"] = f"1 lot ({int(ls)} kg)"
    if body.get("price_per_kg") is not None:
        updates["price_per_kg"] = Decimal(str(body["price_per_kg"]))
        ls = _decimal(existing.get("lot_size_kg", 0))
        if ls > 0:
            updates["lot_price"] = ls * updates["price_per_kg"]
    if body.get("mrp_price_per_kg") is not None:
        # Optional — sending an empty string / 0 clears the MRP (no discount shown).
        updates["mrp_price_per_kg"] = _decimal(body.get("mrp_price_per_kg") or 0)
    if body.get("min_order_kg") is not None and not body.get("lot_size_kg"):
        updates["min_order_kg"] = Decimal(str(body["min_order_kg"]))
    if body.get("images_b64"):
        urls = list(existing.get("image_urls") or [])
        for i, b64 in enumerate(body["images_b64"]):
            if b64:
                key = _upload_b64_to_s3(b64, f"products/{existing.get('shop_id')}", f"{product_id}_e{i}")
                if key:
                    urls.append(_public_s3_url(key))
        if urls:
            updates["image_urls"] = urls
            updates["image_url"] = urls[0]
    updates["updated_at"] = _now()

    names = {f"#k{i}": k for i, k in enumerate(updates)}
    values = {f":v{i}": v for i, v in enumerate(updates.values())}
    expr = "SET " + ", ".join(f"{n} = {v}" for n, v in zip(names, values))
    table.update_item(
        Key={"pk": existing["pk"]},
        UpdateExpression=expr,
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
    )
    return _json_response(200, {"success": True})


def handle_shop_product_delete(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    existing = _get_seller_product(user["sub"], body.get("product_id", ""), body.get("category_id", ""))
    if not existing:
        return _json_response(404, {"error": "Product not found"})
    table.delete_item(Key={"pk": existing["pk"]})
    shop_id = existing.get("shop_id", "")
    if shop_id:
        try:
            table.update_item(
                Key={"pk": f"SHOP#{shop_id}"},
                UpdateExpression="SET product_count = product_count - :one",
                ExpressionAttributeValues={":one": 1},
            )
        except Exception:
            pass
    return _json_response(200, {"success": True})


def handle_shop_product_pause(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    existing = _get_seller_product(user["sub"], body.get("product_id", ""), body.get("category_id", ""))
    if not existing:
        return _json_response(404, {"error": "Product not found"})
    paused = body.get("is_paused")
    if paused is None:
        paused = not existing.get("is_paused", False)
    table.update_item(
        Key={"pk": existing["pk"]},
        UpdateExpression="SET is_paused = :p, updated_at = :u",
        ExpressionAttributeValues={":p": bool(paused), ":u": _now()},
    )
    return _json_response(200, {"success": True, "is_paused": bool(paused)})


def handle_review_submit(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    product_id = body.get("product_id", "")
    category_id = body.get("category_id", "")
    rating = int(body.get("rating") or 0)
    comment = (body.get("comment") or "")[:300]
    if rating < 1 or rating > 5:
        return _json_response(400, {"error": "Rating must be 1-5"})
    if not product_id:
        return _json_response(400, {"error": "product_id required"})

    dup_pk = f"REVIEW#USER#{user['sub']}#{product_id}"
    if table.get_item(Key={"pk": dup_pk}).get("Item"):
        return _json_response(400, {"error": "You already reviewed this product"})

    product = None
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if item.get("product_id") == product_id and (not category_id or item.get("category_id") == category_id):
            product = item
            break
    if not product:
        return _json_response(404, {"error": "Product not found"})

    rid = str(uuid.uuid4())
    table.put_item(Item={
        "pk": f"REVIEW#{product_id}#{rid}",
        "sk": "METADATA",
        "review_id": rid,
        "product_id": product_id,
        "category_id": product.get("category_id", ""),
        "shop_id": product.get("shop_id", ""),
        "reviewer_sub": user["sub"],
        "reviewer_name": _first_name(user.get("name", "")),
        "rating": rating,
        "comment": comment,
        "created_at": _now(),
    })
    table.put_item(Item={"pk": dup_pk, "review_id": rid, "created_at": _now()})

    total = int(_decimal(product.get("total_reviews", 0))) + 1
    old_avg = _decimal(product.get("avg_rating", 0))
    new_avg = ((old_avg * (total - 1)) + Decimal(rating)) / Decimal(total)
    table.update_item(
        Key={"pk": product["pk"]},
        UpdateExpression="SET avg_rating = :a, total_reviews = :t",
        ExpressionAttributeValues={":a": new_avg.quantize(Decimal("0.1")), ":t": total},
    )
    shop_id = product.get("shop_id", "")
    if shop_id:
        shop = get_shop(shop_id)
        owner = shop.get("user_sub", "")
        if owner:
            stars = "★" * rating + "☆" * (5 - rating)
            create_notification(
                owner, "new_review",
                f"New review on {product.get('product_name', 'product')}",
                f"Someone left a {stars} review on your {product.get('product_name', 'product')}",
            )
    return _json_response(200, {"success": True})


def handle_reviews_list(event: dict) -> dict:
    params = event.get("queryStringParameters") or {}
    product_id = params.get("product_id", "")
    if not product_id:
        return _json_response(400, {"error": "product_id required"})
    reviews = []
    for item in _scan_by_pk_prefix(f"REVIEW#{product_id}#"):
        if item.get("sk") == "METADATA" or "rating" in item:
            reviews.append({
                "reviewer_name": item.get("reviewer_name", "Customer"),
                "rating": int(item.get("rating", 0)),
                "comment": item.get("comment", ""),
                "created_at": item.get("created_at", ""),
            })
    reviews.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return _json_response(200, {"reviews": reviews[:50]})


def handle_notifications_list(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    prefix = f"NOTIFICATION#USER#{user['sub']}#"
    items = _scan_by_pk_prefix(prefix)
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    unread = sum(1 for i in items if not i.get("is_read"))
    out = [{
        "notification_id": i.get("notification_id", i["pk"].split("#")[-1]),
        "type": i.get("type", ""),
        "title": i.get("title", ""),
        "body": i.get("body", ""),
        "is_read": bool(i.get("is_read")),
        "created_at": i.get("created_at", ""),
        "ticket_id": i.get("ticket_id", ""),
        "reference_id": i.get("reference_id", ""),
        "listing_crop": i.get("listing_crop", ""),
    } for i in items[:100]]
    return _json_response(200, {"notifications": out, "unread": unread})


def handle_notifications_read(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    mark_all = body.get("mark_all")
    nid = body.get("notification_id", "")
    prefix = f"NOTIFICATION#USER#{user['sub']}#"
    if mark_all:
        for item in _scan_by_pk_prefix(prefix):
            if not item.get("is_read"):
                table.update_item(
                    Key={"pk": item["pk"]},
                    UpdateExpression="SET is_read = :r",
                    ExpressionAttributeValues={":r": True},
                )
        return _json_response(200, {"success": True})
    if nid:
        pk = f"{prefix}{nid}" if not nid.startswith("NOTIFICATION#") else nid
        table.update_item(
            Key={"pk": pk},
            UpdateExpression="SET is_read = :r",
            ExpressionAttributeValues={":r": True},
        )
    return _json_response(200, {"success": True})


def handle_notifications_delete(event: dict) -> dict:
    """Permanently remove one of the caller's own notifications (or all
    already-read ones with delete_all_read) — the pk-prefix guard makes it
    impossible to delete another user's records no matter what id is sent."""
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    prefix = f"NOTIFICATION#USER#{user['sub']}#"
    if body.get("delete_all_read"):
        deleted = 0
        for item in _scan_by_pk_prefix(prefix):
            if item.get("is_read"):
                try:
                    table.delete_item(Key={"pk": item["pk"]})
                    deleted += 1
                except Exception:
                    logger.exception("[NOTIFICATIONS] bulk delete failed for %s", item.get("pk"))
        return _json_response(200, {"success": True, "deleted": deleted})
    nid = str(body.get("notification_id") or "").strip()
    if not nid:
        return _json_response(400, {"error": "notification_id is required"})
    pk = f"{prefix}{nid}" if not nid.startswith("NOTIFICATION#") else nid
    if not pk.startswith(prefix):
        return _json_response(403, {"error": "Not your notification"})
    try:
        table.delete_item(Key={"pk": pk})
    except Exception:
        logger.exception("[NOTIFICATIONS] delete failed")
        return _json_response(500, {"error": "Could not delete notification"})
    return _json_response(200, {"success": True})


def handle_profile_update(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    register_portal_user(user)
    allowed = {}
    # NOTE: "mobile" added so a delivery partner's contact number is
    # reliably persisted server-side (previously silently dropped here) —
    # needed to show a "call delivery partner" number on the buyer's
    # live tracking map.
    #
    # NOTE (profile-persistence fix): the portal's "Complete your profile"
    # form (saveProfile() in portal.html) sends name/email/address/city/
    # state/pincode/country/gst/farm_location/lat/lng too, but this
    # whitelist used to silently drop all of them — only mobile/phone/dob/
    # gender/account_status ever reached DynamoDB. That's why the profile
    # looked "saved" (localStorage) on the same browser but came back
    # empty on any other device/browser: there was nothing to restore.
    # Expanded the whitelist to cover every field the form actually saves.
    for k in (
        "name", "phone", "mobile", "email", "company_name", "address", "city", "state",
        "pincode", "country", "gst_number", "farm_location", "address_lat", "address_lng",
        "dob", "gender", "saved_addresses", "account_status",
    ):
        if k in body:
            allowed[k] = body[k]
    if allowed:
        upsert_profile(user["sub"], allowed)
    prof = get_profile(user["sub"])
    return _json_response(200, {"success": True, "profile": prof})


def handle_profile_get(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    register_portal_user(user)
    prof = get_profile(user["sub"])
    kyc = get_kyc(user["sub"])
    shop = get_shop_by_user(user["sub"])
    return _json_response(200, {"profile": prof, "kyc_status": kyc.get("status", "none"), "shop_id": shop.get("shop_id", "")})


def _ad_placement(event: dict, body: dict | None = None) -> str:
    params = event.get("queryStringParameters") or {}
    placement = (body or {}).get("placement") or params.get("placement") or "dashboard"
    return placement if placement in {"dashboard", "trade"} else "dashboard"


def _ad_key(placement: str) -> str:
    return f"AD#ACTIVE#{placement.upper()}"


def handle_ad_active(event: dict) -> dict:
    placement = _ad_placement(event)
    item = table.get_item(Key={"pk": _ad_key(placement)}).get("Item") or {}
    if placement == "dashboard" and not item.get("image_url"):
        item = table.get_item(Key={"pk": "AD#ACTIVE"}).get("Item") or {}
    if not item.get("image_url"):
        return _json_response(200, {"ad": None})
    return _json_response(200, {"ad": {
        "image_url": item.get("image_url", ""),
        "link_url": item.get("link_url", ""),
        "alt_text": item.get("alt_text", ""),
        "media_type": item.get("media_type", "image"),
        "placement": placement,
    }})


def handle_ad_upload(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    placement = _ad_placement(event, body)
    media_type = body.get("media_type", "image")
    if media_type not in {"image", "gif", "video"}:
        return _json_response(400, {"error": "Invalid media type"})
    b64 = body.get("image_b64", "")
    link_url = body.get("link_url", "")
    alt_text = body.get("alt_text", "Aarvex Global")
    key = _upload_b64_to_s3(b64, f"banner-media/{placement}", "active_banner")
    if not key:
        url = body.get("image_url", "")
    else:
        url = _public_s3_url(key)
    if not url:
        return _json_response(400, {"error": "Media file required"})
    table.put_item(Item={
        "pk": _ad_key(placement),
        "image_url": url,
        "link_url": link_url,
        "alt_text": alt_text,
        "media_type": media_type,
        "placement": placement,
        "created_at": _now(),
        "created_by": "admin",
    })
    return _json_response(200, {"success": True, "image_url": url, "placement": placement, "media_type": media_type})


def handle_ad_remove(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    placement = _ad_placement(event, _event_body(event))
    try:
        table.delete_item(Key={"pk": _ad_key(placement)})
    except Exception:
        pass
    return _json_response(200, {"success": True})


def _category_image_key(category_name: str) -> str:
    return f"CATEGORY_IMAGE#{category_name.strip().lower()}"


def handle_category_images_list(event: dict) -> dict:
    """Public, unauthenticated — the portal's category quick-grid fetches
    this to show an admin-uploaded photo instead of the generic FontAwesome
    icon for any category that has one configured."""
    items = _scan_by_pk_prefix("CATEGORY_IMAGE#")
    images = {
        item.get("category_name", ""): item.get("image_url", "")
        for item in items
        if item.get("category_name") and item.get("image_url")
    }
    return _json_response(200, {"images": images})


def handle_category_image_upload(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    category_name = (body.get("category_name") or "").strip()
    if not category_name:
        return _json_response(400, {"error": "Category name is required"})
    if len(category_name) > 40:
        return _json_response(400, {"error": "Category name is too long"})
    b64 = body.get("image_b64", "")
    slug = re.sub(r"[^a-z0-9]+", "-", category_name.lower()).strip("-") or "category"
    key = _upload_b64_to_s3(b64, "category-images", slug)
    if not key:
        return _json_response(400, {"error": "Image file required"})
    url = _public_s3_url(key)
    table.put_item(Item={
        "pk": _category_image_key(category_name),
        "category_name": category_name,
        "image_url": url,
        "created_at": _now(),
        "created_by": "admin",
    })
    return _json_response(200, {"success": True, "category_name": category_name, "image_url": url})


def handle_category_image_remove(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    category_name = (body.get("category_name") or "").strip()
    if not category_name:
        return _json_response(400, {"error": "Category name is required"})
    try:
        table.delete_item(Key={"pk": _category_image_key(category_name)})
    except Exception:
        pass
    return _json_response(200, {"success": True})


# ── Full category manager (admin) ──
# The Category Images card used to only know about categories that had an
# image uploaded. These three endpoints give the admin the same view the
# portal's category grid has (every category that exists on any product OR
# has an image), plus rename and delete-with-product-reassignment.

def _all_product_categories() -> dict:
    """category_name (original casing) -> active product count, across the
    whole catalogue. Lowercase-deduped, first-seen casing wins."""
    counts: dict = {}
    casing: dict = {}
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        name = (item.get("category_name") or "Other").strip() or "Other"
        key = name.lower()
        if key not in casing:
            casing[key] = name
        counts[key] = counts.get(key, 0) + (1 if item.get("is_active", True) else 0)
    return {casing[k]: v for k, v in counts.items()}


def handle_category_list(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    product_cats = _all_product_categories()
    images: dict = {}
    for item in _scan_by_pk_prefix("CATEGORY_IMAGE#"):
        if item.get("category_name"):
            images[item["category_name"]] = item.get("image_url", "")
    # Union: categories with products + categories that only have an image.
    names = {n.lower(): n for n in product_cats}
    for n in images:
        names.setdefault(n.lower(), n)
    out = []
    for name in sorted(names.values(), key=str.lower):
        img = next((u for k, u in images.items() if k.lower() == name.lower()), "")
        out.append({
            "category_name": name,
            "product_count": product_cats.get(name, 0),
            "image_url": img,
        })
    return _json_response(200, {"categories": out})


def handle_category_rename(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    old_name = (body.get("old_name") or "").strip()
    new_name = (body.get("new_name") or "").strip()
    if not old_name or not new_name:
        return _json_response(400, {"error": "old_name and new_name are required"})
    if len(new_name) > 40:
        return _json_response(400, {"error": "Category name is too long"})
    updated = 0
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if (item.get("category_name") or "").strip().lower() == old_name.lower():
            try:
                table.update_item(
                    Key={"pk": item["pk"]},
                    UpdateExpression="SET category_name = :n",
                    ExpressionAttributeValues={":n": new_name},
                )
                updated += 1
            except Exception as e:
                logger.error("[CATEGORY][RENAME] product update failed for %s: %s", item.get("pk"), e)
    # Move the image mapping (if any) to the new name.
    try:
        img = table.get_item(Key={"pk": _category_image_key(old_name)}).get("Item")
        if img:
            table.put_item(Item={
                "pk": _category_image_key(new_name),
                "category_name": new_name,
                "image_url": img.get("image_url", ""),
                "created_at": _now(),
                "created_by": "admin",
            })
            table.delete_item(Key={"pk": _category_image_key(old_name)})
    except Exception as e:
        logger.warning("[CATEGORY][RENAME] image move failed: %s", e)
    return _json_response(200, {"success": True, "updated_products": updated, "new_name": new_name})


def handle_category_delete(event: dict) -> dict:
    """Delete a category: its image mapping is removed and every product
    still under it is automatically moved to the fallback "Other" category
    (per owner's spec) — products are never deleted or hidden by this."""
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    category_name = (body.get("category_name") or "").strip()
    if not category_name:
        return _json_response(400, {"error": "Category name is required"})
    if category_name.lower() == "other":
        return _json_response(400, {"error": '"Other" is the fallback category and cannot be deleted'})
    moved = 0
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if (item.get("category_name") or "").strip().lower() == category_name.lower():
            try:
                table.update_item(
                    Key={"pk": item["pk"]},
                    UpdateExpression="SET category_name = :n",
                    ExpressionAttributeValues={":n": "Other"},
                )
                moved += 1
            except Exception as e:
                logger.error("[CATEGORY][DELETE] product move failed for %s: %s", item.get("pk"), e)
    try:
        table.delete_item(Key={"pk": _category_image_key(category_name)})
    except Exception:
        pass
    return _json_response(200, {"success": True, "moved_to_other": moved})


# ══════════════════════════════════════════════════════════════
# COMMUNITY FEED — every signed-in user can post a photo/video with a
# description; everyone signed in sees the shared public feed with
# like / comment / view / share counts. Post owner can edit the
# description or delete the post; likes/comments notify the owner
# (type feed_like / feed_comment → the Feed tab of Notifications).
# Keys:
#   FEEDPOST#<millis>-<uuid8>          (lexicographic pk == chronology)
#   FEEDLIKE#<user_sub>#<post_id>      (one user's likes, prefix-scannable)
#   FEEDCOMMENT#<post_id>#<millis>-<uuid6>
# ══════════════════════════════════════════════════════════════

_FEED_MEDIA_MAX_B64 = 5 * 1024 * 1024 * 4 // 3  # ≈5MB binary as base64


def _feed_author(user: dict) -> dict:
    prof = get_profile(user["sub"])
    return {
        "user_name": prof.get("user_name") or user.get("name") or "Aarvex user",
        "user_photo": prof.get("custom_photo_url") or prof.get("photo_url") or user.get("picture", ""),
    }


def handle_feed_create(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    description = str(body.get("description") or "").strip()[:1000]
    media_b64 = body.get("media_b64") or ""
    if not description and not media_b64:
        return _json_response(400, {"error": "Add a photo/video or a description"})
    if media_b64 and len(media_b64) > _FEED_MEDIA_MAX_B64:
        return _json_response(400, {"error": "Media too large — max 5MB"})
    import time as _time
    post_id = f"{int(_time.time() * 1000)}-{uuid.uuid4().hex[:8]}"
    media_url = ""
    media_type = ""
    if media_b64:
        key = _upload_b64_to_s3(media_b64, f"feed/{user['sub'][:24]}", post_id)
        if not key:
            return _json_response(400, {"error": "Media upload failed"})
        media_url = _public_s3_url(key)
        media_type = "video" if key.rsplit(".", 1)[-1] in ("mp4", "webm") else "image"
    author = _feed_author(user)
    item = {
        "pk": f"FEEDPOST#{post_id}",
        "post_id": post_id,
        "user_sub": user["sub"],
        "user_name": author["user_name"],
        "user_photo": author["user_photo"],
        "description": description,
        "media_url": media_url,
        "media_type": media_type,
        "like_count": 0,
        "comment_count": 0,
        "view_count": 0,
        "share_count": 0,
        "created_at": _now(),
        "ttl": _ttl(365),
    }
    table.put_item(Item=item)
    return _json_response(200, {"success": True, "post": _feed_public(item, set())})


def _feed_public(item: dict, my_liked: set) -> dict:
    return {
        "post_id": item.get("post_id", ""),
        "user_sub": item.get("user_sub", ""),
        "user_name": item.get("user_name", "Aarvex user"),
        "user_photo": item.get("user_photo", ""),
        "description": item.get("description", ""),
        "media_url": item.get("media_url", ""),
        "media_type": item.get("media_type", ""),
        "like_count": int(_decimal(item.get("like_count", 0))),
        "comment_count": int(_decimal(item.get("comment_count", 0))),
        "view_count": int(_decimal(item.get("view_count", 0))),
        "share_count": int(_decimal(item.get("share_count", 0))),
        "created_at": item.get("created_at", ""),
        "liked_by_me": item.get("post_id", "") in my_liked,
    }


def _feed_my_likes(user_sub: str) -> set:
    out = set()
    for it in _scan_by_pk_prefix(f"FEEDLIKE#{user_sub}#"):
        out.add(it.get("post_id", ""))
    return out


def handle_feed_list(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    params = event.get("queryStringParameters") or {}
    try:
        limit = min(max(int(params.get("limit", 20)), 1), 50)
    except (TypeError, ValueError):
        limit = 20
    try:
        offset = max(int(params.get("offset", 0)), 0)
    except (TypeError, ValueError):
        offset = 0
    mine_only = params.get("mine") == "1"
    posts = []
    for it in _scan_by_pk_prefix("FEEDPOST#"):
        if mine_only and it.get("user_sub") != user["sub"]:
            continue
        posts.append(it)
    posts.sort(key=lambda p: p.get("pk", ""), reverse=True)  # newest first
    total = len(posts)
    page = posts[offset:offset + limit]
    my_liked = _feed_my_likes(user["sub"])
    return _json_response(200, {
        "posts": [_feed_public(p, my_liked) for p in page],
        "total": total,
        "next_offset": offset + limit if offset + limit < total else None,
    })


def _get_feed_post(post_id: str) -> dict:
    if not post_id or "#" in post_id:
        return {}
    return table.get_item(Key={"pk": f"FEEDPOST#{post_id}"}).get("Item") or {}


def handle_feed_edit(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    post = _get_feed_post(str(body.get("post_id") or ""))
    if not post:
        return _json_response(404, {"error": "Post not found"})
    if post.get("user_sub") != user["sub"]:
        return _json_response(403, {"error": "You can only edit your own posts"})
    description = str(body.get("description") or "").strip()[:1000]
    table.update_item(
        Key={"pk": post["pk"]},
        UpdateExpression="SET description = :d, edited_at = :t",
        ExpressionAttributeValues={":d": description, ":t": _now()},
    )
    return _json_response(200, {"success": True})


def handle_feed_delete(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    post = _get_feed_post(str(body.get("post_id") or ""))
    if not post:
        return _json_response(404, {"error": "Post not found"})
    if post.get("user_sub") != user["sub"]:
        return _json_response(403, {"error": "You can only delete your own posts"})
    table.delete_item(Key={"pk": post["pk"]})
    # Comments/likes are left to expire via their TTLs — the post itself is
    # gone so nothing references them anymore.
    return _json_response(200, {"success": True})


def handle_feed_like(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    post_id = str(body.get("post_id") or "")
    post = _get_feed_post(post_id)
    if not post:
        return _json_response(404, {"error": "Post not found"})
    like_pk = f"FEEDLIKE#{user['sub']}#{post_id}"
    existing = table.get_item(Key={"pk": like_pk}).get("Item")
    delta = -1 if existing else 1
    if existing:
        table.delete_item(Key={"pk": like_pk})
    else:
        table.put_item(Item={
            "pk": like_pk, "user_sub": user["sub"], "post_id": post_id,
            "created_at": _now(), "ttl": _ttl(365),
        })
    try:
        resp = table.update_item(
            Key={"pk": post["pk"]},
            UpdateExpression="SET like_count = if_not_exists(like_count, :z) + :d",
            ExpressionAttributeValues={":z": 0, ":d": delta},
            ReturnValues="UPDATED_NEW",
        )
        like_count = max(0, int(_decimal(resp["Attributes"].get("like_count", 0))))
    except ClientError:
        like_count = max(0, int(_decimal(post.get("like_count", 0))) + delta)
    if delta > 0 and post.get("user_sub") and post["user_sub"] != user["sub"]:
        liker = _feed_author(user)
        create_notification(
            post["user_sub"], "feed_like", "New like on your post",
            f"{liker['user_name']} liked your post" + (f': "{post.get("description", "")[:60]}"' if post.get("description") else "."),
            post_id=post_id,
        )
    return _json_response(200, {"success": True, "liked": delta > 0, "like_count": like_count})


def handle_feed_comment(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    post_id = str(body.get("post_id") or "")
    text = str(body.get("text") or "").strip()[:300]
    if not text:
        return _json_response(400, {"error": "Comment text required"})
    post = _get_feed_post(post_id)
    if not post:
        return _json_response(404, {"error": "Post not found"})
    import time as _time
    author = _feed_author(user)
    comment_id = f"{int(_time.time() * 1000)}-{uuid.uuid4().hex[:6]}"
    table.put_item(Item={
        "pk": f"FEEDCOMMENT#{post_id}#{comment_id}",
        "post_id": post_id,
        "comment_id": comment_id,
        "user_sub": user["sub"],
        "user_name": author["user_name"],
        "user_photo": author["user_photo"],
        "text": text,
        "created_at": _now(),
        "ttl": _ttl(365),
    })
    try:
        table.update_item(
            Key={"pk": post["pk"]},
            UpdateExpression="SET comment_count = if_not_exists(comment_count, :z) + :o",
            ExpressionAttributeValues={":z": 0, ":o": 1},
        )
    except ClientError:
        pass
    if post.get("user_sub") and post["user_sub"] != user["sub"]:
        create_notification(
            post["user_sub"], "feed_comment", "New comment on your post",
            f"{author['user_name']}: \"{text[:80]}\"",
            post_id=post_id,
        )
    return _json_response(200, {"success": True, "comment_id": comment_id})


def handle_feed_comments(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    params = event.get("queryStringParameters") or {}
    post_id = str(params.get("post_id") or "")
    if not post_id:
        return _json_response(400, {"error": "post_id required"})
    comments = list(_scan_by_pk_prefix(f"FEEDCOMMENT#{post_id}#"))
    comments.sort(key=lambda c: c.get("pk", ""))
    return _json_response(200, {"comments": [{
        "comment_id": c.get("comment_id", ""),
        "user_sub": c.get("user_sub", ""),
        "user_name": c.get("user_name", "Aarvex user"),
        "user_photo": c.get("user_photo", ""),
        "text": c.get("text", ""),
        "created_at": c.get("created_at", ""),
    } for c in comments]})


def handle_feed_view(event: dict) -> dict:
    """Batched, best-effort view counting — the frontend sends the ids of
    posts that actually scrolled into view (IntersectionObserver)."""
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    post_ids = body.get("post_ids") or []
    if not isinstance(post_ids, list):
        return _json_response(400, {"error": "post_ids must be a list"})
    counted = 0
    for pid in post_ids[:25]:
        pid = str(pid)
        if "#" in pid:
            continue
        try:
            table.update_item(
                Key={"pk": f"FEEDPOST#{pid}"},
                UpdateExpression="SET view_count = if_not_exists(view_count, :z) + :o",
                ConditionExpression="attribute_exists(pk)",
                ExpressionAttributeValues={":z": 0, ":o": 1},
            )
            counted += 1
        except Exception:
            pass
    return _json_response(200, {"success": True, "counted": counted})


def handle_feed_share(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    post = _get_feed_post(str(body.get("post_id") or ""))
    if not post:
        return _json_response(404, {"error": "Post not found"})
    try:
        table.update_item(
            Key={"pk": post["pk"]},
            UpdateExpression="SET share_count = if_not_exists(share_count, :z) + :o",
            ExpressionAttributeValues={":z": 0, ":o": 1},
        )
    except ClientError:
        pass
    return _json_response(200, {"success": True})


def handle_profile_cover(event: dict) -> dict:
    """Set / replace the profile COVER photo (shown behind the avatar on
    My Profile, like a social profile header)."""
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    b64 = body.get("image_b64") or ""
    if not b64:
        upsert_profile(user["sub"], {"cover_photo_url": ""})
        return _json_response(200, {"success": True, "cover_photo_url": ""})
    if len(b64) > _FEED_MEDIA_MAX_B64:
        return _json_response(400, {"error": "Image too large — max 5MB"})
    key = _upload_b64_to_s3(b64, f"covers/{user['sub'][:24]}", "cover")
    if not key:
        return _json_response(400, {"error": "Upload failed"})
    url = _public_s3_url(key)
    upsert_profile(user["sub"], {"cover_photo_url": url})
    return _json_response(200, {"success": True, "cover_photo_url": url})


def handle_shop_favourites(event: dict) -> dict:
    """Shops this user has liked/favourited — powers the Favourites tab's
    new "Shops" sub-tab. Reuses the SHOPLIKE records handle_shop_like
    already writes."""
    user, err = _require_auth(event)
    if err:
        return err
    shops = []
    for it in _scan_by_pk_prefix(f"SHOPLIKE#{user['sub']}#"):
        shop_id = it.get("shop_id", "")
        if not shop_id:
            continue
        shop = get_shop(shop_id)
        if not shop or shop.get("status") not in ("active", None, ""):
            # Still list paused shops (they may come back) — only drop
            # records whose shop no longer exists at all.
            if not shop:
                continue
        shops.append({
            "shop_id": shop_id,
            "shop_name": shop.get("shop_name") or shop_id,
            "shop_category": shop.get("shop_category", ""),
            "address_city": shop.get("address_city", ""),
            "address_state": shop.get("address_state", ""),
            "avg_rating": _json_num(shop.get("avg_rating", 0)),
            "like_count": int(_decimal(shop.get("like_count", 0))),
            "liked_at": it.get("liked_at", ""),
        })
    shops.sort(key=lambda s: s.get("liked_at", ""), reverse=True)
    return _json_response(200, {"shops": shops})


def handle_favourites_get(event: dict) -> dict:
    user, error = _require_auth(event)
    if error:
        return error
    item = table.get_item(Key={"pk": f"FAVOURITE#USER#{user['sub']}"}).get("Item") or {}
    return _json_response(200, {"liked_keys": sorted(item.get("liked_keys") or [])})


def handle_favourites_toggle(event: dict) -> dict:
    user, error = _require_auth(event)
    if error:
        return error
    body = _event_body(event)
    key = str(body.get("key") or "").strip()
    liked = body.get("liked")
    if not key or "::" not in key or not isinstance(liked, bool):
        return _json_response(400, {"error": "A valid favourite key and liked state are required"})
    favourite_pk = f"FAVOURITE#USER#{user['sub']}"
    try:
        action = "ADD" if liked else "DELETE"
        table.update_item(Key={"pk": favourite_pk}, UpdateExpression=f"SET updated_at = :now {action} liked_keys :keyset", ExpressionAttributeValues={":keyset": {key}, ":now": _now()})
    except ClientError:
        logger.exception("[FAVOURITES] Toggle failed")
        return _json_response(500, {"error": "Could not update favourites"})
    return _json_response(200, {"success": True, "key": key, "liked": liked})


def admin_list_users(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    profiles = _scan_by_pk_prefix("PROFILE#USER#")
    kyc_map = {k.get("user_sub"): k for k in _scan_by_pk_prefix("KYC#USER#")}
    shops = {s.get("user_sub"): s for s in _scan_by_pk_prefix("SHOP#")}
    users = []
    for p in profiles:
        sub = p.get("user_sub", p["pk"].replace("PROFILE#USER#", ""))
        kyc = kyc_map.get(sub, {})
        shop = shops.get(sub, {})
        users.append({
            "user_sub": sub,
            "name": p.get("user_name", ""),
            "email": p.get("user_email", ""),
            "joined_at": p.get("joined_at", p.get("created_at", "")),
            "account_status": p.get("account_status", "active"),
            "kyc_status": kyc.get("status", "none"),
            "shop_id": shop.get("shop_id", kyc.get("shop_id", "")),
            "shop_status": shop.get("status", ""),
        })
    users.sort(key=lambda u: u.get("joined_at", ""), reverse=True)
    return _json_response(200, {"users": users, "total": len(users)})


def admin_user_block(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    user_sub = body.get("user_sub", "")
    blocked = body.get("blocked", True)
    status = "blocked" if blocked else "active"
    upsert_profile(user_sub, {"account_status": status})
    shop = get_shop_by_user(user_sub)
    if shop and blocked:
        table.update_item(
            Key={"pk": f"SHOP#{shop['shop_id']}"},
            UpdateExpression="SET #s = :s",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": "blocked"},
        )
    create_notification(user_sub, "admin_message", "Account Status", f"Your account has been {status} by admin.")
    return _json_response(200, {"success": True})


def admin_user_delete(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    user_sub = body.get("user_sub", "")
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if item.get("seller_user_sub") == user_sub:
            table.delete_item(Key={"pk": item["pk"]})
    shop = get_shop_by_user(user_sub)
    if shop:
        table.delete_item(Key={"pk": f"SHOP#{shop['shop_id']}"})
    try:
        table.delete_item(Key={"pk": f"KYC#USER#{user_sub}"})
        table.delete_item(Key={"pk": f"PROFILE#USER#{user_sub}"})
    except Exception:
        pass
    return _json_response(200, {"success": True})


def admin_user_notify(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    user_sub = body.get("user_sub", "")
    title = body.get("title") or body.get("subject") or "Message from Aarvex Global Admin"
    message = body.get("message") or body.get("body") or ""
    create_notification(user_sub, "admin_message", title, message)
    return _json_response(200, {"success": True})


def admin_kyc_list(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    status_filter = (event.get("queryStringParameters") or {}).get("status", "pending")
    items = _scan_by_pk_prefix("KYC#USER#")
    if status_filter != "all":
        items = [i for i in items if i.get("status") == status_filter]
    out = []
    for k in items:
        out.append({
            "user_sub": k.get("user_sub", ""),
            "user_name": k.get("user_name", ""),
            "user_email": k.get("user_email", ""),
            "aadhaar_last4": k.get("aadhaar_last4", ""),
            "pan_number": k.get("pan_number", ""),
            "kyc_role": k.get("kyc_role", "shop_owner"),
            "status": k.get("status", ""),
            "submitted_at": k.get("submitted_at", ""),
            "aadhaar_front_url": _presigned_get(k.get("aadhaar_front_s3_key", "")),
            "aadhaar_back_url": _presigned_get(k.get("aadhaar_back_s3_key", "")),
            "signature_url": _presigned_get(k.get("signature_s3_key", "")),
        })
    out.sort(key=lambda x: x.get("submitted_at", ""), reverse=True)
    return _json_response(200, {"kyc_list": out})


_VALID_KYC_ROLES = ("shop_owner", "delivery_partner", "both")


def _normalize_kyc_role(raw) -> str | None:
    """Returns a valid kyc_role string, or None if not supplied/invalid.
    Kept permissive on None/missing so approve/reject can omit it entirely
    and leave the existing kyc_role untouched (back-compatible default)."""
    if raw is None:
        return None
    role = str(raw).strip().lower()
    return role if role in _VALID_KYC_ROLES else None


def admin_kyc_review(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    user_sub = body.get("user_sub", "")
    action = body.get("action", "")
    reason = body.get("rejection_reason", "")
    # Optional role correction, usable alongside approve/reject, or alone
    # via action="update_role". See _normalize_kyc_role for validation.
    new_role = _normalize_kyc_role(body.get("kyc_role"))
    kyc = get_kyc(user_sub)
    if not kyc:
        return _json_response(404, {"error": "KYC not found"})
    if action == "approve":
        names = {"#s": "status"}
        values = {":s": "approved", ":u": _now(), ":r": ""}
        expr = "SET #s = :s, reviewed_at = :u, rejection_reason = :r"
        if new_role:
            names["#kr"] = "kyc_role"
            values[":kr"] = new_role
            expr += ", #kr = :kr"
        table.update_item(
            Key={"pk": f"KYC#USER#{user_sub}"},
            UpdateExpression=expr,
            ExpressionAttributeNames=names,
            ExpressionAttributeValues=values,
        )
        create_notification(user_sub, "kyc_update", "KYC Approved", "Your KYC has been approved! Create your shop now.")
    elif action == "reject":
        names = {"#s": "status"}
        values = {":s": "rejected", ":u": _now(), ":r": reason}
        expr = "SET #s = :s, reviewed_at = :u, rejection_reason = :r"
        if new_role:
            names["#kr"] = "kyc_role"
            values[":kr"] = new_role
            expr += ", #kr = :kr"
        table.update_item(
            Key={"pk": f"KYC#USER#{user_sub}"},
            UpdateExpression=expr,
            ExpressionAttributeNames=names,
            ExpressionAttributeValues=values,
        )
        create_notification(user_sub, "kyc_update", "KYC Rejected", f"KYC rejected: {reason or 'Please resubmit.'}")
    elif action == "update_role":
        # Standalone role correction — for the exact bug this fixes: an
        # already-approved KYC whose kyc_role was wrong (e.g. defaulted to
        # "shop_owner" at submit time) and had no way to be corrected since
        # approve/reject never touched kyc_role before this fix. Does NOT
        # touch status or send a KYC-status notification, since the KYC
        # decision itself isn't changing — only the role on file is.
        if not new_role:
            return _json_response(400, {"error": "kyc_role must be one of: shop_owner, delivery_partner, both"})
        table.update_item(
            Key={"pk": f"KYC#USER#{user_sub}"},
            UpdateExpression="SET kyc_role = :kr, reviewed_at = :u",
            ExpressionAttributeValues={":kr": new_role, ":u": _now()},
        )
        create_notification(
            user_sub, "kyc_update", "Account Role Updated",
            "Your account role has been updated by admin. Refresh the app to see any new tabs (e.g. Delivery)."
        )
    else:
        return _json_response(400, {"error": "action must be approve, reject, or update_role"})
    return _json_response(200, {"success": True})


def admin_shops_list(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    shops = []
    for s in _scan_by_pk_prefix("SHOP#"):
        shops.append({
            "shop_id": s.get("shop_id", ""),
            "user_name": s.get("user_name", ""),
            "user_email": s.get("user_email", ""),
            "shop_category": s.get("shop_category", ""),
            "product_count": int(_decimal(s.get("product_count", 0))),
            "avg_rating": _json_num(s.get("avg_rating", 0)),
            "status": s.get("status", ""),
            "created_at": s.get("created_at", ""),
            "user_sub": s.get("user_sub", ""),
        })
    return _json_response(200, {"shops": shops})


def admin_shop_block(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    shop_id = body.get("shop_id", "")
    blocked = body.get("blocked", True)
    shop = get_shop(shop_id)
    if not shop:
        return _json_response(404, {"error": "Shop not found"})
    status = "blocked" if blocked else "active"
    table.update_item(
        Key={"pk": f"SHOP#{shop_id}"},
        UpdateExpression="SET #s = :s",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": status},
    )
    owner = shop.get("user_sub", "")
    if owner:
        create_notification(owner, "shop_status", "Shop Status", f"Your shop has been {status} by admin.")
    return _json_response(200, {"success": True})


def admin_shop_delete(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(403, {"error": "Unauthorized"})
    body = _event_body(event)
    shop_id = body.get("shop_id", "")
    shop = get_shop(shop_id)
    if not shop:
        return _json_response(404, {"error": "Shop not found"})
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if item.get("shop_id") == shop_id:
            table.delete_item(Key={"pk": item["pk"]})
    table.delete_item(Key={"pk": f"SHOP#{shop_id}"})
    owner = shop.get("user_sub", "")
    if owner:
        create_notification(owner, "shop_status", "Shop Deleted", "Your shop and products have been removed by admin.")
    return _json_response(200, {"success": True})


def admin_marketplace_stats() -> dict:
    profiles = _scan_by_pk_prefix("PROFILE#USER#")
    kyc_pending = len([k for k in _scan_by_pk_prefix("KYC#USER#") if k.get("status") == "pending"])
    shops = _scan_by_pk_prefix("SHOP#")
    active_shops = len([s for s in shops if s.get("status") == "active"])
    seller_products = len([
        p for p in _scan_by_pk_prefix("CATALOGUE#CATEGORY#")
        if p.get("is_seller_product") and p.get("is_active", True)
    ])
    notifs = _scan_by_pk_prefix("NOTIFICATION#USER#")
    unread = sum(1 for n in notifs if not n.get("is_read"))
    return {
        "total_portal_users": len(profiles),
        "kyc_pending": kyc_pending,
        "total_active_shops": active_shops,
        "total_seller_products": seller_products,
        "unread_notifications": unread,
    }


def _normalize_http_path(path: str) -> str:
    if not path:
        return "/"
    path = path.split("?")[0]
    for stage in ("/prod", "/dev", "/staging", "/$default"):
        if path.startswith(stage + "/"):
            path = path[len(stage):]
            break
    if not path.startswith("/"):
        path = "/" + path
    return path if path == "/" else path.rstrip("/")


def _normalize_shop_id(raw: str) -> str:
    s = (raw or "").strip().upper()
    if not s:
        return ""
    if s.startswith("SHOP-"):
        return s
    digits = re.sub(r"\D", "", s)
    if digits:
        return f"SHOP-AX-{digits.zfill(5)[-5:]}"
    return s


def _approved_shopkeepers() -> list[dict]:
    shops = []
    for item in _scan_by_pk_prefix("SHOP#"):
        pk = item.get("pk", "")
        if "COUNTER" in pk:
            continue
        shop_id = item.get("shop_id") or pk.replace("SHOP#", "")
        if not shop_id:
            continue
        user_sub = item.get("user_sub", "")
        if not user_sub:
            continue
        kyc = get_kyc(user_sub)
        if kyc.get("status") != "approved":
            continue
        if item.get("status", "active") in ("blocked", "deleted"):
            continue
        shops.append(item)
    return shops


def _shop_public_stats(shop_id: str) -> dict:
    products = sum(
        1 for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#")
        if item.get("shop_id") == shop_id and item.get("is_active", True)
    )
    deals = sum(
        1 for item in _scan_by_pk_prefix("DEAL#SHOP#")
        if item.get("shop_id") == shop_id
    )
    return {"products_listed": products, "orders_completed": deals}


def _shop_public_reviews(shop_id: str) -> list[dict]:
    reviews = []
    for item in _scan_by_pk_prefix("REVIEW#"):
        if item.get("shop_id") != shop_id:
            continue
        if "rating" not in item:
            continue
        reviews.append({
            "reviewer_name": item.get("reviewer_name", "Customer"),
            "rating": int(item.get("rating", 0)),
            "comment": item.get("comment", ""),
            "created_at": item.get("created_at", ""),
            "product_id": item.get("product_id", ""),
        })
    reviews.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return reviews[:30]


def _serialize_shop_public(shop: dict, stats: dict | None = None) -> dict:
    shop_id = shop.get("shop_id") or shop.get("pk", "").replace("SHOP#", "")
    stats = stats or _shop_public_stats(shop_id)
    reviews = _shop_public_reviews(shop_id)
    avg = round(sum(r["rating"] for r in reviews) / len(reviews), 1) if reviews else 0.0
    return {
        "shop_id": shop_id,
        "shop_name": shop.get("shop_name") or shop_id,
        "shop_description": shop.get("shop_description", ""),
        "shop_category": shop.get("shop_category", ""),
        "address_city": shop.get("address_city", ""),
        "address_state": shop.get("address_state", ""),
        "address_pincode": shop.get("address_pincode", ""),
        "gst_number": shop.get("gst_number", ""),
        # Publicly-shareable contact info only -- business phone + city/state.
        # Never merge personal email or other sensitive KYC fields here.
        "contact_number": get_profile(shop.get("user_sub", "")).get("mobile") or get_profile(shop.get("user_sub", "")).get("phone", ""),
        "address_line": ", ".join(filter(None, [shop.get("address_city", ""), shop.get("address_state", "")])),
        "status": shop.get("status", "active"),
        "likes": int(_decimal(shop.get("likes", 0))),
        "dislikes": int(_decimal(shop.get("dislikes", 0))),
        "avg_rating": avg,
        "total_reviews": len(reviews),
        "products_listed": stats.get("products_listed", 0),
        "orders_completed": stats.get("orders_completed", 0),
        "member_since": shop.get("created_at", ""),
    }


def notify_shopkeepers_of_listing(exporter_data: dict, ticket_id: str, ref_id: str) -> int:
    crop = exporter_data.get("product_name") or exporter_data.get("crop") or "Produce"
    qty = exporter_data.get("quantity_available_kg", "")
    city = exporter_data.get("location_city", "")
    state = exporter_data.get("location_state", "")
    price = exporter_data.get("expected_price", "")
    price_line = f"Expected price: ₹{price}/kg\n" if price not in (None, "", 0) else ""
    body = (
        f"Crop: {crop}\nQuantity: {qty} kg\n{price_line}"
        f"Location: {city}, {state}\nReference: {ref_id}\n"
        f"5% platform fee applies on finalized deals."
    )
    count = 0
    for shop in _approved_shopkeepers():
        user_sub = shop.get("user_sub", "")
        if not user_sub:
            continue
        create_notification(
            user_sub, "new_lead", f"New produce listing — {crop}", body,
            ticket_id=ticket_id, reference_id=ref_id, listing_crop=crop,
            # Structured fields (Phase 2, Section 0 #4): "body" above is kept
            # as-is for older clients/other channels, but the in-app
            # notification-item template (CatalogueUI.notificationItemHtml)
            # reads these fields directly instead of parsing/dumping raw text.
            listing_quantity_kg=qty,
            listing_expected_price=price if price not in (None, "", 0) else None,
            listing_city=city,
            listing_state=state,
            platform_fee_pct=5,
        )
        count += 1
    logger.info("[SELL] Notified %s shopkeepers for %s", count, ref_id)
    return count


def handle_shop_public(event: dict) -> dict:
    params = event.get("queryStringParameters") or {}
    shop_id = _normalize_shop_id(params.get("shop_id") or "")
    q = (params.get("q") or params.get("search") or "").strip()

    if q and not shop_id:
        q_upper = _normalize_shop_id(q) if re.search(r"\d", q) else ""
        shops = []
        for item in _approved_shopkeepers():
            sid = item.get("shop_id") or item.get("pk", "").replace("SHOP#", "")
            desc = (item.get("shop_description") or "").lower()
            match = (q_upper and sid.upper() == q_upper) or q.lower() in sid.lower() or q.lower() in desc
            if match:
                shops.append(_serialize_shop_public(item))
        return _json_response(200, {"shops": shops[:20]})

    if not shop_id:
        return _json_response(400, {"error": "shop_id or search (q) required"})

    shop = get_shop(shop_id)
    if not shop:
        return _json_response(404, {"error": "Shop not found", "shop": None})

    products = []
    for item in _scan_by_pk_prefix("CATALOGUE#CATEGORY#"):
        if item.get("shop_id") == shop_id:
            ser = serialize_product(item)
            if ser:
                products.append(ser)

    reviews = _shop_public_reviews(shop_id)
    stats = _shop_public_stats(shop_id)
    return _json_response(200, {
        "shop": _serialize_shop_public(shop, stats),
        "products": products,
        "reviews": reviews,
    })


def handle_shop_react(event: dict) -> dict:
    body = _event_body(event)
    shop_id = _normalize_shop_id(body.get("shop_id") or "")
    reaction = (body.get("reaction") or "").strip().lower()
    user_sub = (body.get("user_sub") or "").strip()
    if not shop_id or reaction not in ("like", "dislike"):
        return _json_response(400, {"error": "Invalid reaction"})
    shop = get_shop(shop_id)
    if not shop:
        return _json_response(404, {"error": "Shop not found"})
    react_key = f"SHOP_REACT#{shop_id}#{user_sub or 'anon_' + str(uuid.uuid4())[:8]}"
    prev = table.get_item(Key={"pk": react_key}).get("Item") or {}
    likes = int(_decimal(shop.get("likes", 0)))
    dislikes = int(_decimal(shop.get("dislikes", 0)))
    if prev.get("reaction") == "like":
        likes = max(0, likes - 1)
    elif prev.get("reaction") == "dislike":
        dislikes = max(0, dislikes - 1)
    if reaction == "like":
        likes += 1
    else:
        dislikes += 1
    table.put_item(Item={"pk": react_key, "reaction": reaction, "user_sub": user_sub, "updated_at": _now(), "ttl": _ttl(365)})
    table.update_item(
        Key={"pk": f"SHOP#{shop_id}"},
        UpdateExpression="SET likes = :l, dislikes = :d",
        ExpressionAttributeValues={":l": likes, ":d": dislikes},
    )
    return _json_response(200, {"success": True, "likes": likes, "dislikes": dislikes})


def handle_shop_like(event: dict) -> dict:
    """Like a shop (auth required, idempotent per user). Increments like_count atomically."""
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    shop_id = _normalize_shop_id(body.get("shop_id") or "")
    if not shop_id:
        return _json_response(400, {"error": "shop_id required"})
    
    shop = get_shop(shop_id)
    if not shop:
        return _json_response(404, {"error": "Shop not found"})
    
    # Deduplication key: SHOPLIKE#{user_sub}#{shop_id}
    like_key = f"SHOPLIKE#{user['sub']}#{shop_id}"
    existing = table.get_item(Key={"pk": like_key}).get("Item")
    
    if existing:
        # Already liked - return current count without incrementing
        like_count = int(_decimal(shop.get("like_count", 0)))
        return _json_response(200, {"success": True, "like_count": like_count, "already_liked": True})
    
    # Atomically increment like_count
    try:
        resp = table.update_item(
            Key={"pk": f"SHOP#{shop_id}"},
            UpdateExpression="SET like_count = if_not_exists(like_count, :zero) + :one",
            ExpressionAttributeValues={":zero": 0, ":one": 1},
            ReturnValues="UPDATED_NEW",
        )
        like_count = int(resp["Attributes"].get("like_count", 1))
    except ClientError:
        # Fallback if atomic update fails
        like_count = int(_decimal(shop.get("like_count", 0))) + 1
        table.update_item(
            Key={"pk": f"SHOP#{shop_id}"},
            UpdateExpression="SET like_count = :l",
            ExpressionAttributeValues={":l": like_count},
        )
    
    # Record that this user liked this shop (idempotency)
    table.put_item(Item={
        "pk": like_key,
        "user_sub": user["sub"],
        "shop_id": shop_id,
        "liked_at": _now(),
        "ttl": _ttl(365),
    })
    
    return _json_response(200, {"success": True, "like_count": like_count, "already_liked": False})


def handle_shops_top(event: dict) -> dict:
    """Return top 10 active shops ranked by reputation (rating + reviews + likes)."""
    import math
    
    shops = []
    for item in _scan_by_pk_prefix("SHOP#"):
        if item.get("status") != "active":
            continue
        
        shop_id = item.get("shop_id", "")
        
        # Count published products for this shop
        product_count = sum(
            1 for prod in _scan_by_pk_prefix("CATALOGUE#CATEGORY#")
            if prod.get("shop_id") == shop_id and prod.get("is_active", True)
        )
        
        # Only include shops with at least 1 published product
        if product_count < 1:
            continue
        
        avg_rating = float(_decimal(item.get("avg_rating", 0)))
        total_reviews = int(_decimal(item.get("total_reviews", 0)))
        like_count = int(_decimal(item.get("like_count", 0)))
        
        # Composite score: avg_rating * log(1 + total_reviews) + like_count factor
        # This balances rating quality with review volume and likes
        review_factor = math.log(1 + total_reviews) if total_reviews > 0 else 0
        score = (avg_rating * review_factor) + (like_count * 0.1)
        
        shops.append({
            "shop_id": shop_id,
            "shop_name": item.get("shop_name") or shop_id,
            "shop_logo_url": "",  # No logo field in current schema
            "avg_rating": round(avg_rating, 1),
            "total_reviews": total_reviews,
            "like_count": like_count,
            "score": score,
            "product_count": product_count,
        })
    
    # Sort by score descending
    shops.sort(key=lambda s: s["score"], reverse=True)
    
    # Return top 10
    top_shops = shops[:10]
    for shop in top_shops:
        shop.pop("score", None)  # Don't expose internal score to frontend
    
    return _json_response(200, {"shops": top_shops})


def handle_shop_list(event: dict) -> dict:
    """List all active shops for the public Shop Directory tab (Trade > Shop).
    Unlike handle_shops_top (fixed top-10 leaderboard), this returns every
    active shop, paginated, so buyers can browse the full directory and search
    it client-side. Suspended/blocked/deleted shops are filtered out in the
    query itself so they disappear immediately, not just via a frontend filter.
    """
    params = event.get("queryStringParameters") or {}
    try:
        limit = min(max(int(params.get("limit", 50)), 1), 100)
    except (TypeError, ValueError):
        limit = 50
    try:
        offset = max(int(params.get("offset", 0)), 0)
    except (TypeError, ValueError):
        offset = 0

    shops = []
    for item in _scan_by_pk_prefix("SHOP#"):
        pk = item.get("pk", "")
        if "COUNTER" in pk:
            continue
        if item.get("status") != "active":
            continue
        shop_id = item.get("shop_id") or pk.replace("SHOP#", "")
        if not shop_id:
            continue

        product_count = sum(
            1 for prod in _scan_by_pk_prefix("CATALOGUE#CATEGORY#")
            if prod.get("shop_id") == shop_id and prod.get("is_active", True)
        )

        shops.append({
            "shop_id": shop_id,
            "shop_name": item.get("shop_name") or shop_id,
            "shop_description": item.get("shop_description", ""),
            "shop_category": item.get("shop_category", ""),
            "address_city": item.get("address_city", ""),
            "address_state": item.get("address_state", ""),
            "shop_logo_url": item.get("shop_logo_url", ""),
            "avg_rating": _json_num(item.get("avg_rating", 0)),
            "total_reviews": int(_decimal(item.get("total_reviews", 0))),
            "like_count": int(_decimal(item.get("like_count", 0))),
            "product_count": product_count,
            "created_at": item.get("created_at", ""),
        })

    # Stable order (newest shop first) so pagination offsets do not shuffle
    # results between pages as new shops are created concurrently.
    shops.sort(key=lambda s: s.get("created_at", ""), reverse=True)

    total = len(shops)
    page = shops[offset:offset + limit]
    next_offset = offset + limit if offset + limit < total else None
    return _json_response(200, {
        "shops": page,
        "total": total,
        "limit": limit,
        "offset": offset,
        "next_offset": next_offset,
    })


def handle_shop_feedback(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    shop_id = _normalize_shop_id(body.get("shop_id") or "")
    message = (body.get("message") or "").strip()
    if not shop_id or not message:
        return _json_response(400, {"error": "shop_id and message required"})
    shop = get_shop(shop_id)
    if not shop:
        return _json_response(404, {"error": "Shop not found"})
    owner_sub = shop.get("user_sub", "")
    fid = str(uuid.uuid4())
    table.put_item(Item={
        "pk": f"SHOP_FEEDBACK#{shop_id}#{fid}",
        "shop_id": shop_id, "owner_sub": owner_sub,
        "from_sub": user["sub"], "from_name": user.get("name", ""),
        "message": message[:500], "is_read": False,
        "created_at": _now(), "ttl": _ttl(365),
    })
    if owner_sub:
        create_notification(owner_sub, "admin_message", "New private feedback", message[:120])
    return _json_response(200, {"success": True})


def handle_shop_feedback_list(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    shop = get_shop_by_user(user["sub"])
    shop_id = shop.get("shop_id") or shop.get("pk", "").replace("SHOP#", "")
    if not shop_id:
        return _json_response(200, {"feedback": []})
    items = [i for i in _scan_by_pk_prefix(f"SHOP_FEEDBACK#{shop_id}#")]
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return _json_response(200, {"feedback": [{
        "feedback_id": i.get("pk", "").split("#")[-1],
        "from_name": i.get("from_name", "Customer"),
        "message": i.get("message", ""),
        "created_at": i.get("created_at", ""),
        "is_read": i.get("is_read", False),
    } for i in items[:50]]})


def handle_listing_deal_preview(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    ticket_id = (body.get("ticket_id") or body.get("reference_id") or "").strip()
    if not ticket_id:
        return _json_response(400, {"error": "Listing reference required"})
    ticket = table.get_item(Key={"pk": f"TICKET#EXPORTER#{ticket_id}"}).get("Item") or {}
    if not ticket:
        for item in _scan_by_pk_prefix("TICKET#EXPORTER#"):
            if item.get("ticket_id") == ticket_id:
                ticket = item
                break
    if not ticket:
        return _json_response(404, {"error": "Listing not found"})
    qty = _decimal(body.get("quantity_kg") or ticket.get("quantity_available_kg", 1))
    lot_price = _decimal(ticket.get("expected_price", 0)) * qty
    if _decimal(ticket.get("lot_price", 0)) > 0:
        lot_price = _decimal(ticket.get("lot_price"))
    breakdown = calc_payment_breakdown(
        lot_price,
        seller_pincode=ticket.get("location_pincode", ticket.get("pincode", "")),
        buyer_pincode=body.get("delivery_pincode", ""),
    )
    return _json_response(200, {"breakdown": breakdown, "ticket_id": ticket_id})


def handle_listing_deal(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    if get_kyc(user["sub"]).get("status") != "approved":
        return _json_response(403, {"error": "KYC approval required"})
    shop = get_shop_by_user(user["sub"])
    shop_id = shop.get("shop_id", "")
    if not shop_id:
        return _json_response(403, {"error": "Active shop required"})
    body = _event_body(event)
    ticket_id = (body.get("ticket_id") or body.get("reference_id") or "").strip()
    payment_mode = (body.get("payment_mode") or "online").strip().lower()
    if payment_mode in ("cash", "cash_on_delivery"):
        payment_mode = "cod"
    qty = _decimal(body.get("quantity_kg"), Decimal("0"))
    if not ticket_id:
        return _json_response(400, {"error": "Listing reference required"})

    ticket = table.get_item(Key={"pk": f"TICKET#EXPORTER#{ticket_id}"}).get("Item") or {}
    if not ticket:
        for item in _scan_by_pk_prefix("TICKET#EXPORTER#"):
            tid = item.get("ticket_id", "")
            if tid == ticket_id or tid[:8].upper() == ticket_id.upper():
                ticket = item
                ticket_id = tid
                break
    if not ticket:
        return _json_response(404, {"error": "Listing not found"})

    deal_qty = qty or _decimal(ticket.get("quantity_available_kg", 1))
    lot_price = _decimal(ticket.get("expected_price", 0)) * deal_qty
    if _decimal(ticket.get("lot_price", 0)) > 0:
        lot_price = _decimal(ticket.get("lot_price"))
    breakdown = calc_payment_breakdown(
        lot_price,
        seller_pincode=ticket.get("location_pincode", ticket.get("pincode", "")),
        buyer_pincode=body.get("delivery_pincode", shop.get("address_pincode", "")),
    )
    arn, tracking_key = generate_arn()
    deal_id = str(uuid.uuid4())
    payment_link_url = ""
    if payment_mode == "online":
        try:
            from advanced_features import create_razorpay_payment_link
            pseudo_ticket = {
                "arn": arn,
                "ticket_id": deal_id,
                "product_name": ticket.get("product_name", ""),
                "quantity_kg": deal_qty,
                "payment_amount": breakdown["total"],
                "payment_currency": "INR",
                "customer_name": user.get("name", ""),
                "email": user.get("email", ""),
                "mobile": get_profile(user["sub"]).get("phone", ""),
            }
            link = create_razorpay_payment_link(pseudo_ticket) or {}
            payment_link_url = link.get("short_url", "")
        except Exception as e:
            logger.error("[DEAL] Razorpay link: %s", e)

    table.put_item(Item={
        "pk": f"DEAL#SHOP#{deal_id}", "deal_id": deal_id, "arn": arn,
        "tracking_key": tracking_key,
        "exporter_ticket_id": ticket_id, "shop_id": shop_id,
        "shopkeeper_sub": user["sub"], "crop": ticket.get("product_name", ""),
        "quantity_kg": _json_num(deal_qty),
        "lot_price": breakdown["lot_price"],
        "delivery_charge": breakdown["delivery_charge"],
        "platform_fee": breakdown["platform_fee"],
        "platform_fee_pct": breakdown["platform_fee_pct"],
        "subtotal": breakdown["subtotal"],
        "gst_amount": breakdown["gst_amount"],
        "gst_rate_pct": breakdown["gst_rate_pct"],
        "total_amount": breakdown["total"],
        "payment_mode": payment_mode,
        "payment_link_url": payment_link_url,
        "status": "deal_finalized",
        "created_at": _now(), "ttl": _ttl(730),
    })
    table.put_item(Item={
        "pk": f"ORDER#{arn}", "sk": "STATUS", "arn": arn,
        "ticket_id": deal_id, "product_name": ticket.get("product_name", ""),
        "current_status": "Deal Finalized — Awaiting Payment" if payment_mode == "online" else "Deal Finalized",
        "status_history": [{"status": "Deal Finalized", "timestamp": _now(), "updated_by": user["sub"]}],
        "last_updated": _now(), "importer_sub": user["sub"],
    })
    if _delivery_mod:
        # Destination coords for the live tracking map: prefer precise
        # lat/lng if the buyer's browser sent them (Places autocomplete),
        # else fall back to a pincode-centroid geocode. Either way this
        # is best-effort — a missing destination never blocks the order.
        _dest_lat = _decimal(body.get("delivery_lat", 0))
        _dest_lng = _decimal(body.get("delivery_lng", 0))
        if not _dest_lat or not _dest_lng:
            try:
                from platform_utils import geocode_pincode
                _pin = body.get("delivery_pincode", shop.get("address_pincode", ""))
                _geo = geocode_pincode(_pin) if _pin else None
                if _geo:
                    _dest_lat, _dest_lng = _decimal(_geo[0]), _decimal(_geo[1])
            except Exception as _ge:
                logger.warning("[DEAL] destination geocode failed: %s", _ge)
        _delivery_mod.create_delivery_record(
            arn=arn,
            product_name=ticket.get("product_name", ""),
            importer_sub=user["sub"],
            pickup_city=ticket.get("location_city", ""),
            delivery_city=shop.get("address_city", body.get("delivery_city", "")),
            delivery_pincode=body.get("delivery_pincode", shop.get("address_pincode", "")),
            lot_size_kg=float(deal_qty),
            distance_km=breakdown["distance_km"],
            delivery_charge=breakdown["delivery_charge"],
            dest_lat=float(_dest_lat or 0),
            dest_lng=float(_dest_lng or 0),
            buyer_name=user.get("name", ""),
            buyer_email=user.get("email", ""),
            buyer_mobile=get_profile(user["sub"]).get("mobile") or get_profile(user["sub"]).get("phone", ""),
        )
    seller_mobile = ticket.get("whatsapp_number") or ticket.get("mobile", "")
    msg = (
        f"Deal Finalized — Aarvex Global\n\nCrop: {ticket.get('product_name', '')}\n"
        f"Lot: {deal_qty} kg · ₹{breakdown['lot_price']}\n"
        f"Delivery: ₹{breakdown['delivery_charge']}\n"
        f"Platform fee ({breakdown['platform_fee_pct']}%): ₹{breakdown['platform_fee']}\n"
        f"GST ({breakdown['gst_rate_pct']}%): ₹{breakdown['gst_amount']}\n"
        f"Total: ₹{breakdown['total']}\nPayment: {payment_mode.upper()}\nOrder ID: {arn}"
    )
    try:
        from advanced_features import send_whatsapp_text
        if seller_mobile:
            send_whatsapp_text(str(seller_mobile), msg)
    except Exception as e:
        logger.error("[DEAL] WhatsApp: %s", e)
    create_notification(user["sub"], "shop_status", "Deal finalized", f"Order {arn} — Total ₹{breakdown['total']} (incl. GST ₹{breakdown['gst_amount']})")
    return _json_response(200, {
        "success": True, "arn": arn, "breakdown": breakdown,
        "payment_link_url": payment_link_url,
        "total_amount": breakdown["total"],
        "gst_amount": breakdown["gst_amount"],
        "platform_fee": breakdown["platform_fee"],
    })


def handle_shop_subscribe(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    kyc = get_kyc(user["sub"])
    if kyc.get("status") != "approved":
        return _json_response(403, {"error": "KYC must be approved first"})
    if is_subscription_active(user["sub"]):
        return _json_response(200, {"success": True, "already_active": True, "message": "Subscription already active"})
    settings = get_platform_settings()
    amount = float(settings["shop_subscription_inr"])
    try:
        from advanced_features import create_razorpay_payment_link
        sub_id = str(uuid.uuid4())
        link = create_razorpay_payment_link({
            "arn": f"SUB-{sub_id[:8]}",
            "ticket_id": sub_id,
            "product_name": "Agro Shop Plan — Monthly",
            "quantity_kg": 1,
            "payment_amount": amount,
            "payment_currency": "INR",
            "customer_name": user.get("name", ""),
            "email": user.get("email", ""),
            "mobile": get_profile(user["sub"]).get("phone", ""),
        }) or {}
        table.put_item(Item={
            "pk": f"SUBSCRIPTION#USER#{user['sub']}",
            "user_sub": user["sub"],
            "subscription_id": sub_id,
            "status": "pending",
            "amount_inr": amount,
            "razorpay_link_id": link.get("id", ""),
            "created_at": _now(),
        })
        return _json_response(200, {"success": True, "payment_link_url": link.get("short_url", ""), "amount": amount})
    except Exception as e:
        logger.error("[SUB] %s", e)
        return _json_response(500, {"error": "Could not create subscription payment link"})


def admin_delivery_list(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(401, {"error": "Unauthorized"})
    rows = []
    if _delivery_mod:
        for item in _delivery_mod._scan_prefix("DELIVERY#ARN#"):
            rows.append({
                "arn": item.get("arn"),
                "status": item.get("status"),
                "product_name": item.get("product_name"),
                "pickup_city": item.get("pickup_city"),
                "delivery_city": item.get("delivery_city"),
                "claimed_by": item.get("claimed_by", ""),
            })
    return _json_response(200, {"deliveries": rows[:100]})


def admin_settings_get(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(401, {"error": "Unauthorized"})
    s = get_platform_settings()
    return _json_response(200, {"settings": {k: float(v) if isinstance(v, Decimal) else v for k, v in s.items()}})


def admin_settings_update(event: dict) -> dict:
    if not _admin_authorized(event):
        return _json_response(401, {"error": "Unauthorized"})
    body = _event_body(event)
    allowed = ("delivery_rate_per_km", "min_delivery_charge", "platform_fee_pct", "gst_rate_pct", "shop_subscription_inr", "otp_expiry_minutes")
    updates = {k: body[k] for k in allowed if k in body}
    if updates:
        from platform_utils import save_platform_settings
        save_platform_settings(updates)
    return _json_response(200, {"success": True})


def _address_pk(user_sub: str) -> str:
    return f"USER#{user_sub}"


def handle_address_list(event: dict) -> dict:
    """List saved delivery addresses for the logged-in buyer (address book)."""
    user, err = _require_auth(event)
    if err:
        return err
    try:
        resp = table.scan(
            FilterExpression="begins_with(pk, :p)",
            ExpressionAttributeValues={":p": f"ADDRESS#{user['sub']}#"},
        )
        raw = resp.get("Items", [])
    except Exception as e:
        logger.error("[ADDRESS] list failed: %s", e)
        raw = []
    addresses = sorted(
        [
            {
                "address_id": it.get("address_id", ""),
                "label": it.get("label", "Address"),
                "address": it.get("address", ""),
                "city": it.get("city", ""),
                "state": it.get("state", ""),
                "pincode": it.get("pincode", ""),
                "lat": _json_num(it.get("lat", 0)),
                "lng": _json_num(it.get("lng", 0)),
                "is_default": bool(it.get("is_default")),
                "created_at": it.get("created_at", ""),
            }
            for it in raw
        ],
        key=lambda a: a.get("created_at", ""),
        reverse=True,
    )
    return _json_response(200, {"success": True, "addresses": addresses})


def handle_address_save(event: dict) -> dict:
    """Save a new address (or update one, if address_id passed) — built from
    the Leaflet + Geocoder location picker on the frontend."""
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    address = (body.get("address") or "").strip()
    city = (body.get("city") or "").strip()
    state_name = (body.get("state") or "").strip()
    if not address or not city or not state_name:
        return _json_response(400, {"error": "address, city and state are required"})
    try:
        lat = float(body.get("lat") or 0)
        lng = float(body.get("lng") or 0)
    except (TypeError, ValueError):
        lat = lng = 0.0
    address_id = (body.get("address_id") or "").strip() or f"ADDR-{uuid.uuid4().hex[:12]}"
    pk = f"ADDRESS#{user['sub']}#{address_id}"
    existing_created = table.get_item(Key={"pk": pk}).get("Item", {}).get("created_at")
    item = {
        "pk": pk,
        "user_sub": user["sub"],
        "address_id": address_id,
        "label": (body.get("label") or "Address")[:40],
        "address": address[:300],
        "city": city[:80],
        "state": state_name[:80],
        "pincode": (body.get("pincode") or "").strip()[:10],
        "lat": _decimal(lat),
        "lng": _decimal(lng),
        "is_default": bool(body.get("is_default")),
        "created_at": existing_created or _now(),
        "updated_at": _now(),
    }
    table.put_item(Item=item)
    return _json_response(200, {"success": True, "address_id": address_id})


def handle_address_delete(event: dict) -> dict:
    user, err = _require_auth(event)
    if err:
        return err
    body = _event_body(event)
    address_id = (body.get("address_id") or "").strip()
    if not address_id:
        return _json_response(400, {"error": "address_id required"})
    pk = f"ADDRESS#{user['sub']}#{address_id}"
    try:
        table.delete_item(Key={"pk": pk})
    except Exception as e:
        logger.error("[ADDRESS] delete failed: %s", e)
        return _json_response(500, {"error": "Could not delete address"})
    return _json_response(200, {"success": True})


def handle_portal_route(event: dict) -> dict | None:
    """Route marketplace/portal HTTP endpoints."""
    method = event.get("requestContext", {}).get("http", {}).get("method") or event.get("httpMethod", "GET")
    path = _normalize_http_path(event.get("rawPath") or event.get("path") or "")
    logger.info(f"[PORTAL_ROUTE] {method} {path}")

    if method == "OPTIONS":
        return _json_response(200, {})

    routes = {
        ("POST", "/kyc/submit"): handle_kyc_submit,
        ("GET", "/kyc/status"): handle_kyc_status,
        ("POST", "/shop/create"): handle_shop_create,
        ("POST", "/shop/subscribe"): handle_shop_subscribe,
        ("GET", "/shop/info"): handle_shop_info,
        ("GET", "/shop/public"): handle_shop_public,
        ("POST", "/shop/react"): handle_shop_react,
        ("POST", "/shop/like"): handle_shop_like,
        ("POST", "/shop/feedback"): handle_shop_feedback,
        ("GET", "/shop/feedback"): handle_shop_feedback_list,
        ("GET", "/shops/top"): handle_shops_top,
        ("GET", "/shop/list"): handle_shop_list,
        ("POST", "/listing/deal/preview"): handle_listing_deal_preview,
        ("POST", "/listing/deal"): handle_listing_deal,
        ("POST", "/shop/toggle"): handle_shop_toggle,
        ("GET", "/shop/products"): handle_shop_products_list,
        ("POST", "/shop/product/add"): handle_shop_product_add,
        ("POST", "/shop/product/edit"): handle_shop_product_edit,
        ("POST", "/shop/product/delete"): handle_shop_product_delete,
        ("POST", "/shop/product/pause"): handle_shop_product_pause,
        ("POST", "/review/submit"): handle_review_submit,
        ("GET", "/reviews"): handle_reviews_list,
        ("GET", "/notifications"): handle_notifications_list,
        ("POST", "/notifications/read"): handle_notifications_read,
        ("POST", "/notifications/delete"): handle_notifications_delete,
        ("GET", "/banner/active"): handle_ad_active,
        ("POST", "/banner/upload"): handle_ad_upload,
        ("POST", "/banner/remove"): handle_ad_remove,
        ("GET", "/category/images"): handle_category_images_list,
        ("POST", "/category/image/upload"): handle_category_image_upload,
        ("POST", "/category/image/remove"): handle_category_image_remove,
        ("GET", "/category/list"): handle_category_list,
        ("POST", "/category/rename"): handle_category_rename,
        ("POST", "/category/delete"): handle_category_delete,
        ("POST", "/feed/post"): handle_feed_create,
        ("GET", "/feed"): handle_feed_list,
        ("POST", "/feed/edit"): handle_feed_edit,
        ("POST", "/feed/delete"): handle_feed_delete,
        ("POST", "/feed/like"): handle_feed_like,
        ("POST", "/feed/comment"): handle_feed_comment,
        ("GET", "/feed/comments"): handle_feed_comments,
        ("POST", "/feed/view"): handle_feed_view,
        ("POST", "/feed/share"): handle_feed_share,
        ("POST", "/profile/cover"): handle_profile_cover,
        ("GET", "/shop/favourites"): handle_shop_favourites,
        ("GET", "/favourites"): handle_favourites_get,
        ("POST", "/favourites/toggle"): handle_favourites_toggle,
        ("GET", "/track"): handle_track_order,
        ("POST", "/order/cancel"): handle_order_cancel,
        ("GET", "/profile"): handle_profile_get,
        ("POST", "/profile/update"): handle_profile_update,
        ("GET", "/admin/api/users"): admin_list_users,
        ("POST", "/admin/api/user/block"): admin_user_block,
        ("POST", "/admin/api/user/delete"): admin_user_delete,
        ("POST", "/admin/api/user/notify"): admin_user_notify,
        ("GET", "/admin/api/kyc/list"): admin_kyc_list,
        ("POST", "/admin/api/kyc/review"): admin_kyc_review,
        ("GET", "/admin/api/shops"): admin_shops_list,
        ("POST", "/admin/api/shop/block"): admin_shop_block,
        ("POST", "/admin/api/shop/delete"): admin_shop_delete,
        ("GET", "/admin/api/deliveries"): admin_delivery_list,
        ("GET", "/admin/api/settings"): admin_settings_get,
        ("POST", "/admin/api/settings"): admin_settings_update,
        ("GET", "/address/list"): handle_address_list,
        ("POST", "/address/save"): handle_address_save,
        ("POST", "/address/delete"): handle_address_delete,
    }
    if _delivery_mod:
        routes.update({
            ("GET", "/delivery/orders"): _delivery_mod.handle_delivery_orders,
            ("POST", "/delivery/claim"): _delivery_mod.handle_delivery_claim,
            ("POST", "/delivery/start"): _delivery_mod.handle_delivery_start,
            ("POST", "/delivery/location"): _delivery_mod.handle_delivery_location,
            ("POST", "/delivery/complete"): _delivery_mod.handle_delivery_complete,
            ("GET", "/delivery/earnings"): _delivery_mod.handle_delivery_earnings,
            ("GET", "/delivery/active"): _delivery_mod.handle_delivery_active,
            ("GET", "/delivery/my-claims"): _delivery_mod.handle_delivery_my_claims,
            ("POST", "/delivery/cancel"): _delivery_mod.handle_delivery_cancel,
            ("POST", "/delivery/reject"): _delivery_mod.handle_delivery_reject,
            ("POST", "/delivery/review/submit"): _delivery_mod.handle_delivery_review_submit,
        })

    handler = routes.get((method, path))
    if handler:
        try:
            result = handler(event)
        except Exception:
            logger.error(
                "[PORTAL_ROUTE][UNHANDLED] %s %s crashed:\n%s",
                method, path, traceback.format_exc(),
            )
            return _json_response(500, {"error": "Something went wrong on our end. Please try again in a moment."})
        status = result.get("statusCode", "?") if isinstance(result, dict) else "?"
        logger.info(f"[PORTAL_ROUTE] {method} {path} → {status}")
        return result
    logger.warning(f"[PORTAL_ROUTE] No handler for {method} {path}")
    if path.startswith("/admin/api/"):
        return None
    return None


if _delivery_mod:
    import sys as _sys
    _delivery_mod._bind_delivery_helpers(_sys.modules[__name__])
    _delivery_mod._bind_contact_helper(get_delivery_partner_contact)
    _delivery_mod._bind_partner_pool_helpers(list_approved_delivery_partners, suspend_delivery_partner)
