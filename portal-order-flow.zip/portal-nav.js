/* Aarvex Portal — Navigation
 * Extracted from portal.html's inline <script> (was lines 1382-2900).
 * Panel switching, bottom-nav sync, search dock, auto-hide chrome, trade-mode tabs.
 * Depends on: portal-helpers.js (gv/sv/showToast) — load this AFTER portal-helpers.js.
 * NOTE: switchPanel() defined here is later overridden by portal-marketplace.js
 * (pre-existing behaviour, unchanged by this split — just flagging it).
 */

/* ── NAVIGATION ── */
function switchPanel(panelId) {
  if (panelId === 'order' || panelId === 'sell') {
    const mode = panelId;
    panelId = 'trade';
    document.querySelectorAll('.portal-panel').forEach(el => el.classList.remove('active'));
    const panel = document.getElementById('panel-' + panelId);
    if (panel) panel.classList.add('active');
    document.querySelectorAll('.sidebar-nav-item[data-panel]').forEach(el => el.classList.toggle('active', el.dataset.panel === panelId));
    document.querySelectorAll('.mobile-nav-btn').forEach(el => el.classList.toggle('active', el.dataset.panel === panelId));
    syncNavSlider();
    syncNavIcons();
    // Instant jump — smooth-scrolling from a deep scroll position took
    // hundreds of ms and made every tab switch feel sluggish on mobile.
    window.scrollTo(0, 0);
    switchTradeMode(mode);
    if (typeof closeMobileSidebar === 'function') closeMobileSidebar();
    document.body.classList.toggle('ax-flush-top', panelId === 'dashboard' || panelId === 'trade');
    const navEl = document.querySelector('.nav');
    if (navEl) navEl.classList.toggle('on-trade-panel', panelId === 'trade');
    if (typeof window.searchDockUpdate === 'function') window.searchDockUpdate();
    if (typeof window.axChromeReset === 'function') window.axChromeReset();
    switchPanelClearAnimationFallback(panelId);
    return;
  }
  document.querySelectorAll('.portal-panel').forEach(el => el.classList.remove('active'));
  const panel = document.getElementById('panel-' + panelId);
  if (panel) panel.classList.add('active');
  document.querySelectorAll('.sidebar-nav-item[data-panel]').forEach(el => el.classList.toggle('active', el.dataset.panel === panelId));
  document.querySelectorAll('.mobile-nav-btn').forEach(el => el.classList.toggle('active', el.dataset.panel === panelId));
  syncNavSlider();
  syncNavIcons();
  window.scrollTo(0, 0);
  if (typeof closeMobileSidebar === 'function') closeMobileSidebar();
  document.body.classList.toggle('ax-flush-top', panelId === 'dashboard' || panelId === 'trade');
  const navEl = document.querySelector('.nav');
  if (navEl) navEl.classList.toggle('on-trade-panel', panelId === 'trade');
  if (panelId === 'trade') {
    const activeTradeTab = document.querySelector('.trade-mode-tab.active');
    if (!activeTradeTab) switchTradeMode('order');
    // Returning to Trade while Sell/Shop is still the active sub-mode:
    // flush-top only belongs to the Order catalogue (it has the ad).
    else document.body.classList.toggle('ax-flush-top', activeTradeTab.dataset.mode === 'order');
  }
  if (panelId === 'myorders') loadMyListings();
  if (panelId === 'favourites') renderFavouritesGrid();
  if (typeof window.searchDockUpdate === 'function') window.searchDockUpdate();
  if (typeof window.axChromeReset === 'function') window.axChromeReset();
  switchPanelClearAnimationFallback(panelId);
}

/* Nav icon markup — inline SVG for Home, Font Awesome glyphs (already
   loaded for the whole page, zero extra network requests) for the rest.
   The old icons8 raster <img> icons hit img.icons8.com on every tab
   switch, which is what made the bottom nav feel laggy — and being
   raster, they could never be tinted brand-green via CSS. FA glyphs
   colour with `currentColor`, so active = solid green is pure CSS. */
const NAV_ICONS = {
  dashboard: {
    inactive: '<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0 0 48 48"><path d="M 23.951172 4 A 1.50015 1.50015 0 0 0 23.072266 4.3222656 L 8.859375 15.519531 C 7.0554772 16.941163 6 19.113506 6 21.410156 L 6 40.5 C 6 41.863594 7.1364058 43 8.5 43 L 18.5 43 C 19.863594 43 21 41.863594 21 40.5 L 21 30.5 C 21 30.204955 21.204955 30 21.5 30 L 26.5 30 C 26.795045 30 27 30.204955 27 30.5 L 27 40.5 C 27 41.863594 28.136406 43 29.5 43 L 39.5 43 C 40.863594 43 42 41.863594 42 40.5 L 42 21.410156 C 42 19.113506 40.944523 16.941163 39.140625 15.519531 L 24.927734 4.3222656 A 1.50015 1.50015 0 0 0 23.951172 4 z M 24 7.4101562 L 37.285156 17.876953 C 38.369258 18.731322 39 20.030807 39 21.410156 L 39 40 L 30 40 L 30 30.5 C 30 28.585045 28.414955 27 26.5 27 L 21.5 27 C 19.585045 27 18 28.585045 18 30.5 L 18 40 L 9 40 L 9 21.410156 C 9 20.030807 9.6307412 18.731322 10.714844 17.876953 L 24 7.4101562 z" fill="currentColor"></path></svg>',
    active: '<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0 0 48 48"><path d="M39.5,43h-9c-1.381,0-2.5-1.119-2.5-2.5v-9c0-1.105-0.895-2-2-2h-4c-1.105,0-2,0.895-2,2v9c0,1.381-1.119,2.5-2.5,2.5h-9C7.119,43,6,41.881,6,40.5V21.413c0-2.299,1.054-4.471,2.859-5.893L23.071,4.321c0.545-0.428,1.313-0.428,1.857,0L39.142,15.52C40.947,16.942,42,19.113,42,21.411V40.5C42,41.881,40.881,43,39.5,43z" fill="currentColor"></path></svg>'
  },
  trade: {
    inactive: '<i class="fa-solid fa-cart-shopping" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-cart-shopping" aria-hidden="true"></i>'
  },
  favourites: {
    inactive: '<i class="fa-regular fa-heart" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-heart" aria-hidden="true"></i>'
  },
  shop: {
    inactive: '<i class="fa-solid fa-store" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-store" aria-hidden="true"></i>'
  },
  delivery: {
    inactive: '<i class="fa-solid fa-truck" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-truck-fast" aria-hidden="true"></i>'
  },
  profile: {
    inactive: '<i class="fa-regular fa-circle-user" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-circle-user" aria-hidden="true"></i>'
  },
  track: {
    inactive: '<i class="fa-solid fa-location-dot" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-location-dot" aria-hidden="true"></i>'
  },
  myorders: {
    inactive: '<i class="fa-solid fa-box" aria-hidden="true"></i>',
    active: '<i class="fa-solid fa-box-open" aria-hidden="true"></i>'
  }
};

/* Swaps each nav icon's innerHTML between its inactive/active markup
   from NAV_ICONS (keyed by data-icon-key), and re-triggers the .pop
   bounce animation whenever a button just became active. Called every
   time switchPanel() updates .active. */
function syncNavIcons() {
  document.querySelectorAll('.sidebar-nav-item[data-panel] .nav-anim-icon, .mobile-nav-btn[data-panel] .nav-anim-icon')
    .forEach(icon => {
      const btn = icon.closest('[data-panel]');
      if (!btn) return;
      const key = icon.dataset.iconKey;
      const iconData = NAV_ICONS[key];
      if (!iconData) return;
      const isActive = btn.classList.contains('active');
      const wasActive = icon.classList.contains('is-active-icon');
      icon.innerHTML = isActive ? iconData.active : iconData.inactive;
      icon.classList.toggle('is-active-icon', isActive);
      if (isActive && !wasActive) {
        icon.classList.add('pop');
        icon.addEventListener('animationend', () => icon.classList.remove('pop'), { once: true });
      }
    });
}
document.addEventListener('DOMContentLoaded', syncNavIcons);
/* Dashboard is the default active panel on load and never goes through
   switchPanel(), so seed the flush-top class here (CSS additionally gates
   it behind body.is-signed-in so the login screen is unaffected). */
document.addEventListener('DOMContentLoaded', () => {
  const active = document.querySelector('.portal-panel.active');
  const id = active ? active.id.replace('panel-', '') : 'dashboard';
  document.body.classList.toggle('ax-flush-top', id === 'dashboard' || id === 'trade');
});

/* Positions the shared sliding highlight pills behind whichever sidebar /
   mobile nav button is currently active, animating between buttons via
   CSS transitions (see .sidebar-nav-slider / .mobile-nav-slider). */
function syncNavSlider() {
  const sideSlider = document.getElementById('sidebarNavSlider');
  const activeSideItem = document.querySelector('.sidebar-nav-item[data-panel].active');
  if (sideSlider && activeSideItem) {
    sideSlider.style.transform = 'translateY(' + activeSideItem.offsetTop + 'px)';
    sideSlider.style.height = activeSideItem.offsetHeight + 'px';
    sideSlider.classList.add('ready');
  }
  const mobSlider = document.getElementById('mobileNavSlider');
  const activeMobBtn = document.querySelector('.mobile-nav-btn[data-panel].active');
  if (mobSlider && activeMobBtn) {
    mobSlider.style.transform = 'translateX(' + activeMobBtn.offsetLeft + 'px)';
    mobSlider.style.width = activeMobBtn.offsetWidth + 'px';
    mobSlider.classList.add('ready');
  }
}
window.addEventListener('resize', () => { if (typeof syncNavSlider === 'function') syncNavSlider(); });
document.addEventListener('DOMContentLoaded', () => { setTimeout(() => { if (typeof syncNavSlider === 'function') syncNavSlider(); }, 50); });

/* Docks the trade-tab search bar under the header once it scrolls past the
   ad banner. Unlike the old two-layer version (nav icons faded but the
   search bar stayed in its own sticky slot below the now-transparent nav,
   which read as a header split in two), this makes `.catalogue-search-sticky`
   go `position:fixed` and take over the nav's exact box (top:0, full width,
   nav's height, higher z-index) once docked — it visually *becomes* the
   header instead of sitting under it.
   `.search-docked` on <nav> still drives the hamburger/profile/notification
   fade (opacity+transform, so the change stays a smooth CSS transition);
   once that fade finishes we additionally set display:none on those
   elements via JS (transitionend) so their layout space collapses too —
   otherwise the flex gap between them would leave a dead gap even at
   opacity:0. Undocking reverses the exact same sequence: layout space is
   restored first (still invisible, since the docked classes are still on),
   then the classes are removed on the next frame so the fade-in animates
   over real, already-spaced-out elements instead of popping in. */
function initSearchDock() {
  const nav = document.querySelector('.nav');
  // Generalized to every `.catalogue-search-sticky` in the page (Trade →
  // Order catalogue, Trade → Shop Directory, and any future panel that
  // reuses this wrapper) instead of hard-coding to a single instance/panel —
  // this is what makes the scroll-collapse header work on every tab that
  // has a search bar, not just the Order catalogue.
  const searchBars = Array.from(document.querySelectorAll('.catalogue-search-sticky'));
  if (!nav || !searchBars.length) return;
  const collapseEls = [
    document.querySelector('.nav-profile-wrap'),
    ...document.querySelectorAll('.nav-right .nav-btn'),
  ].filter(Boolean);

  // A same-height placeholder inserted right after each bar so switching
  // that bar to position:fixed doesn't yank the content below it upward.
  searchBars.forEach(bar => {
    const spacer = document.createElement('div');
    spacer.className = 'search-dock-spacer';
    bar.insertAdjacentElement('afterend', spacer);
    bar._dockSpacer = spacer;
  });

  function collapseNavIcons() {
    collapseEls.forEach(el => { el.style.display = 'none'; });
  }
  function restoreNavIcons() {
    collapseEls.forEach(el => { el.style.display = ''; });
  }
  collapseEls.forEach(el => el.addEventListener('transitionend', (e) => {
    // Only collapse once the fade itself is done, and only if we're still
    // meant to be docked (guards against a stale event firing after a
    // quick scroll-back-up already restored things).
    if (e.propertyName === 'opacity' && nav.classList.contains('search-docked')) collapseNavIcons();
  }));

  let dockedBar = null;
  function dock(bar) {
    if (dockedBar === bar) return;
    if (dockedBar) undock(dockedBar);
    dockedBar = bar;
    const h = bar.offsetHeight;
    bar._dockSpacer.style.height = h + 'px';
    bar._dockSpacer.classList.add('active');
    nav.classList.add('search-docked');
    bar.classList.add('is-docked');
  }
  function undock(bar) {
    if (dockedBar !== bar) return;
    dockedBar = null;
    restoreNavIcons();
    bar._dockSpacer.classList.remove('active');
    // Synchronous — the old requestAnimationFrame deferral could lose the
    // race against a panel switch, leaving a stuck is-docked bar floating
    // over the next panel with the real header icons frozen at opacity 0
    // (the "double hamburger / buttons dabte hain" bug).
    nav.classList.remove('search-docked');
    bar.classList.remove('is-docked');
  }

  let ticking = false;
  function update() {
    ticking = false;
    // Whichever search bar is actually on screen right now. NOTE: a DOCKED
    // bar is position:fixed, and fixed elements report offsetParent === null
    // even while fully visible — so the panel's .active class is the source
    // of truth, and the currently-docked bar is matched explicitly. The old
    // offsetParent-only check misclassified the docked bar as hidden, which
    // is what let dock state leak across panel switches.
    const visibleBar = searchBars.find(b => {
      const panel = b.closest('.portal-panel');
      if (panel && !panel.classList.contains('active')) return false;
      if (b === dockedBar) return true;
      return b.offsetParent !== null;
    });
    if (!visibleBar) { if (dockedBar) undock(dockedBar); return; }
    const navH = nav.offsetHeight || 64;
    const rect = visibleBar.getBoundingClientRect();
    const referenceTop = dockedBar === visibleBar ? visibleBar._dockSpacer.getBoundingClientRect().top - visibleBar._dockSpacer.offsetHeight : rect.top;
    if (referenceTop <= navH + 1) dock(visibleBar); else undock(visibleBar);
  }
  function onScroll() {
    if (!ticking) { ticking = true; requestAnimationFrame(update); }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });
  window.searchDockUpdate = update;
  update();
}
document.addEventListener('DOMContentLoaded', initSearchDock);

/* ══════════════════════════════════════════════════════════════
   HEADER + BOTTOM-NAV AUTO-HIDE ON SCROLL (Prompt 4.txt Task F)
   Mobile-only (desktop keeps a persistent sidebar + header — hiding just
   the top bar there would look broken). Scrolling further into a page's
   content slides both the header and bottom-nav out of view for a
   full-screen reading area; scrolling back toward the top (or within
   TOP_BUFFER of it) brings them back. Also hides Trade's docked search
   bar when it's standing in for the header (see initSearchDock() above)
   so the two systems never leave a half-hidden header on screen. */
function initAutoHideChrome() {
  const nav = document.querySelector('.nav');
  const footer = document.getElementById('mobileNav');
  if (!nav || !footer) return;
  let lastY = window.scrollY;
  let hidden = false, ticking = false;
  // Hysteresis accumulator — the old version flipped on ANY 8px direction
  // change, so natural finger jitter / scroll-momentum wobble made the
  // header, footer and search bar rapid-fire in and out ("flicker").
  // Now the scroll has to travel a real distance in ONE direction before
  // anything toggles: a deliberate down-scroll hides, a small up-scroll
  // shows (shows stay eager so reaching for the header feels instant,
  // hides are lazy so browsing never trembles).
  let travel = 0, travelDir = 0;
  const TOP_BUFFER = 90, HIDE_TRAVEL = 64, SHOW_TRAVEL = 14;

  function apply(shouldHide) {
    if (shouldHide === hidden) return;
    hidden = shouldHide;
    // ONE class on <body> drives every piece of chrome via CSS (see
    // portal-ui.css) — the old per-element toggling left newly-docked
    // search bars out of sync with the nav/footer, which is where the
    // "search bar stuck floating mid-screen" states came from.
    document.body.classList.toggle('ax-chrome-hidden', hidden);
  }
  function update() {
    ticking = false;
    if (window.innerWidth > 768) { apply(false); return; }
    const maxY = Math.max(0, (document.documentElement.scrollHeight || 0) - window.innerHeight);
    // Clamp: rubber-band overscroll at the top/bottom reports out-of-range
    // scrollY values whose rebound reads as a fake direction change.
    const y = Math.max(0, Math.min(window.scrollY, maxY));
    const dy = y - lastY;
    lastY = y;
    if (y < TOP_BUFFER) { travel = 0; travelDir = 0; apply(false); return; }
    if (!dy) return;
    const dir = dy > 0 ? 1 : -1;
    if (dir !== travelDir) { travel = 0; travelDir = dir; }
    travel += Math.abs(dy);
    if (dir === 1 && travel >= HIDE_TRAVEL) apply(true);
    else if (dir === -1 && travel >= SHOW_TRAVEL) apply(false);
  }
  window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
  window.addEventListener('resize', update);
  window.axChromeReset = () => { travel = 0; travelDir = 0; lastY = window.scrollY; apply(false); };
}
document.addEventListener('DOMContentLoaded', initAutoHideChrome);

/* .portal-panel.active plays a one-off fade/slide-in (@keyframes panelIn,
   fill-mode:both) on every switchPanel() call. Because the animation's
   `to` keyframe is `transform:none`, the browser keeps reporting a
   resolved identity matrix (not the literal keyword "none") for as long
   as that filled animation stays attached — and per spec, ANY non-"none"
   transform on an ancestor makes it the containing block for
   `position:fixed` descendants instead of the viewport. That silently
   broke the Trade tab's docked search bar (and would break the new
   header/footer auto-hide transforms too): once docked, it was
   positioning itself relative to the scrolling panel instead of staying
   pinned to the screen. Clearing the animation once it finishes restores
   a true `transform:none` so position:fixed descendants dock to the
   viewport again. */
function clearPanelInAnimation(panel) {
  if (panel) panel.style.animation = 'none';
}
document.addEventListener('animationend', function (e) {
  if (e.animationName === 'panelIn' && e.target.classList.contains('portal-panel')) {
    clearPanelInAnimation(e.target);
  }
});
/* Fallback in case animationend never fires (backgrounded tab, reduced-
   motion, or any other reason the browser skips/interrupts the CSS
   animation) — the panelIn animation is 0.3s, so 400ms is a safe margin. */
function switchPanelClearAnimationFallback(panelId) {
  setTimeout(() => clearPanelInAnimation(document.getElementById('panel-' + panelId)), 400);
}
function switchTradeMode(mode) {
  document.querySelectorAll('.trade-mode-tab').forEach(el => el.classList.toggle('active', el.dataset.mode === mode));
  // Flush-top (ad at the very top, floating header icons) only makes
  // sense on the Order catalogue — Sell / Shop Directory start with
  // regular content and need the normal header offset back.
  if (document.getElementById('panel-trade')?.classList.contains('active')) {
    document.body.classList.toggle('ax-flush-top', mode === 'order');
  }
  document.getElementById('tradeOrderSection').style.display = mode === 'order' ? '' : 'none';
  document.getElementById('tradeSellSection').style.display = mode === 'sell' ? '' : 'none';
  document.getElementById('shopDirectoryStep').style.display = mode === 'shop' ? '' : 'none';
  if (mode === 'order') {
    if (!selectedProduct) {
      document.getElementById('orderStep1').style.display = '';
      document.getElementById('orderStep2').style.display = 'none';
      setOrderProgressStep(1);
    }
    prefillForms();
  }
  if (mode === 'sell') prefillForms();
  if (mode === 'shop') loadShopDirectory();
  // The search-dock behaviour only targets the Order sub-view's sticky
  // search bar — switching away from it should immediately release any
  // docked state instead of waiting for the next scroll event.
  if (typeof window.searchDockUpdate === 'function') window.searchDockUpdate();
}
