/* Aarvex Portal — Shop Directory + Catalogue rendering
 * Extracted from portal.html's inline <script> (was lines 1382-2900).
 * Shop directory list/cards, catalogue fetch+render, category quick-grid,
 * favourites grid, product-like toggling, search/filter.
 * Depends on: portal-helpers.js (gv/sv/showToast/escapeHtml) — load AFTER it.
 * NOTE: renderCatalogue() defined here is later overridden by portal-enhancements.js
 * (pre-existing behaviour, unchanged by this split — just flagging it).
 * Distinct from catalogue-ui.js (shared CatalogueUI.* render helpers used across
 * portal.html AND index.html) — this file is portal.html-only page logic that
 * calls into those shared helpers.
 */

/* ── SHOP DIRECTORY ── */
let shopDirectoryList = [];
let shopDirectoryLoaded = false;

function shopDirectoryCardHtml(shop) {
  const esc = (typeof CatalogueUI !== 'undefined') ? CatalogueUI.esc : (s => String(s == null ? '' : s));
  const rating = parseFloat(shop.avg_rating) || 0;
  const ratingHtml = rating
    ? '<span style="color:#C7993A;font-weight:700"><i class="fa-solid fa-star"></i> ' + rating.toFixed(1) + '</span>'
    : '<span style="color:var(--c-text4);font-weight:700">New</span>';
  return '<div class="product-card" style="cursor:pointer" onclick="ProductModal.openShopProfile(\'' + esc(shop.shop_id).replace(/'/g, "\\'") + '\')">' +
    '<div class="product-card-media" style="display:flex;align-items:center;justify-content:center;aspect-ratio:4/3;background:var(--color-surface-raised)">' +
      (shop.shop_logo_url ? '<img src="' + esc(shop.shop_logo_url) + '" alt="" style="width:100%;height:100%;object-fit:cover">' : '<i class="fa-solid fa-store" style="font-size:32px;color:var(--c-leaf)"></i>') +
    '</div>' +
    '<div class="product-card-body">' +
      '<div style="font-size:11px;color:var(--c-text3);font-weight:600;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">' + esc(shop.shop_category || 'Shop') + '</div>' +
      '<h4 style="font-family:var(--f-display);font-size:16px;margin-bottom:4px">' + esc(shop.shop_name || shop.shop_id) + '</h4>' +
      '<div style="font-size:12.5px;color:var(--c-text3);margin-bottom:8px"><i class="fa-solid fa-location-dot"></i> ' + esc(shop.address_city || '—') + (shop.address_state ? ', ' + esc(shop.address_state) : '') + '</div>' +
      '<div style="display:flex;align-items:center;justify-content:space-between;font-size:12.5px">' +
        ratingHtml +
        '<span class="sidebar-nav-badge" style="position:static">' + (shop.product_count || 0) + ' products</span>' +
      '</div>' +
    '</div></div>';
}

function shopDirectorySkeletonHtml() {
  return Array(6).fill(0).map(() =>
    '<div class="product-card" style="pointer-events:none">' +
      '<div class="skeleton" style="width:100%;aspect-ratio:4/3;border-radius:0"></div>' +
      '<div class="product-card-body">' +
        '<div class="skeleton" style="height:10px;width:50%;margin-bottom:8px;border-radius:4px"></div>' +
        '<div class="skeleton" style="height:18px;width:80%;margin-bottom:10px;border-radius:6px"></div>' +
        '<div class="skeleton" style="height:10px;width:60%;border-radius:4px"></div>' +
      '</div></div>'
  ).join('');
}

async function loadShopDirectory(forceRefresh) {
  const grid = document.getElementById('shopDirectoryGrid');
  if (!grid) return;
  if (shopDirectoryLoaded && !forceRefresh) { filterShopDirectory(); return; }
  grid.innerHTML = shopDirectorySkeletonHtml();
  try {
    const res = await fetch(LAMBDA_URL + '/shop/list?limit=100', {
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      signal: AbortSignal.timeout(10000),
    });
    const data = await res.json();
    shopDirectoryList = data.shops || [];
    shopDirectoryLoaded = true;
    filterShopDirectory();
  } catch (e) {
    console.error('[ShopDirectory] load failed:', e);
    grid.innerHTML = (typeof CatalogueUI !== 'undefined')
      ? CatalogueUI.emptyStateHtml({ icon: 'fa-triangle-exclamation', message: 'Could not load shops. Please try again.' })
      : '<p style="grid-column:1/-1;text-align:center;color:var(--c-text3)">Could not load shops. Please try again.</p>';
  }
}

function filterShopDirectory() {
  const grid = document.getElementById('shopDirectoryGrid');
  if (!grid) return;
  const q = (document.getElementById('shopDirectorySearch')?.value || '').trim().toLowerCase();
  const filtered = !q ? shopDirectoryList : shopDirectoryList.filter(s =>
    (s.shop_name || '').toLowerCase().includes(q) ||
    (s.shop_category || '').toLowerCase().includes(q) ||
    (s.address_city || '').toLowerCase().includes(q) ||
    (s.address_state || '').toLowerCase().includes(q)
  );
  if (!filtered.length) {
    grid.innerHTML = (typeof CatalogueUI !== 'undefined')
      ? CatalogueUI.emptyStateHtml({ icon: 'fa-shop', message: q ? 'No shops match your search.' : 'No active shops yet.' })
      : '<p style="grid-column:1/-1;text-align:center;color:var(--c-text3)">' + (q ? 'No shops match your search.' : 'No active shops yet.') + '</p>';
    return;
  }
  grid.innerHTML = filtered.map(shopDirectoryCardHtml).join('');
}

/* ── CATALOGUE ── */
let catalogueSource = 'loading'; // 'live' | 'offline'

// No hardcoded fallback — only real products from DynamoDB are shown.
const DEFAULT_PRODUCTS = [];

function showCatalogueSkeletons() {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = Array(6).fill(0).map(() =>
    '<div class="product-card" style="pointer-events:none">' +
      '<div class="skeleton" style="width:100%;aspect-ratio:4/3;border-radius:0"></div>' +
      '<div class="product-card-body">' +
        '<div class="skeleton" style="height:10px;width:60%;margin-bottom:8px;border-radius:4px"></div>' +
        '<div class="skeleton" style="height:18px;width:85%;margin-bottom:10px;border-radius:6px"></div>' +
        '<div class="skeleton" style="height:10px;width:45%;margin-bottom:8px;border-radius:4px"></div>' +
        '<div class="skeleton" style="height:24px;width:55%;margin-bottom:12px;border-radius:4px"></div>' +
        '<div class="skeleton" style="height:34px;width:100%;border-radius:8px"></div>' +
      '</div></div>'
  ).join('');
}

function updateCatalogueSourceBadge() {
  const badge = document.getElementById('catalogueSourceBadge');
  if (!badge) return;
  if (catalogueSource === 'live') {
    badge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:7px;animation:pulse 2s infinite"></i> Live · '+catalogue.length+' products available';
    badge.style.background = 'rgba(34,197,94,.1)';
    badge.style.border = '1px solid rgba(34,197,94,.22)';
    badge.style.color = '#16A34A';
  } else if (catalogueSource === 'offline') {
    badge.innerHTML = '<i class="fa-solid fa-wifi-slash"></i> Could not reach server — <a onclick="loadCatalogue()" style="color:inherit;font-weight:700;cursor:pointer;text-decoration:underline">Retry</a>';
    badge.style.background = 'rgba(239,68,68,.08)';
    badge.style.border = '1px solid rgba(239,68,68,.2)';
    badge.style.color = '#DC2626';
  }
}

async function loadCatalogue() {
  showCatalogueSkeletons();
  let loaded = false;
  for (let attempt = 0; attempt < 2 && !loaded; attempt++) {
    try {
      const res = await fetch(LAMBDA_URL + '/catalogue', {
        headers:{'Content-Type':'application/json', 'Accept':'application/json'},
        signal: AbortSignal.timeout(attempt === 0 ? 10000 : 6000),
      });
      if (res.ok) {
        const data = typeof safeFetchJson === 'function' ? await safeFetchJson(res) : await res.json();
        // Empty array bhi valid response hai — products abhi add nahi hue
        if (data.products !== undefined) {
          catalogue = data.products || [];
          catalogueSource = 'live';
          loaded = true;
        }
      }
    } catch(e) {
      console.warn('[Catalogue] Attempt', attempt+1, 'failed:', e.message);
    }
  }
  if (!loaded) {
    // API hi nahi reach hua — network error
    catalogue = [];
    catalogueSource = 'offline';
    console.error('[Catalogue] All attempts failed, showing empty state');
  }
  filteredCatalogue = [...catalogue];
  renderCatalogue();
  buildCatalogueFilters();
  updateCatalogueSourceBadge();
}

function categoryIconFor(cat) {
  const c = (cat || '').toLowerCase();
  if (c.includes('wheat') || c.includes('grain') || c.includes('rice')) return 'fa-wheat-awn';
  if (c.includes('onion') || c.includes('vegetable') || c.includes('veg')) return 'fa-carrot';
  if (c.includes('chili') || c.includes('chilli') || c.includes('mirch') || c.includes('spice')) return 'fa-pepper-hot';
  if (c.includes('fruit')) return 'fa-apple-whole';
  if (c.includes('pulse') || c.includes('lentil') || c.includes('dal')) return 'fa-seedling';
  return 'fa-leaf';
}
function buildCatalogueFilters() {
  const catMap = {};
  catalogue.forEach(p => {
    const cn = p.category_name || 'Other';
    catMap[cn] = (catMap[cn] || 0) + 1;
  });
  const cats = Object.keys(catMap).sort();
  const wrap = document.getElementById('catalogueFilters');
  if (!wrap) return;
  wrap.classList.add('chip-scroll-fade');
  wrap.innerHTML = '<button class="filter-pill active" data-cat="all" type="button"><span class="cat-icon-circle"><i class="fa-solid fa-border-all"></i></span>All</button>';
  cats.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'filter-pill';
    btn.type = 'button';
    btn.dataset.cat = cat;
    btn.innerHTML = '<span class="cat-icon-circle"><i class="fa-solid '+categoryIconFor(cat)+'"></i></span>' + cat;
    wrap.appendChild(btn);
  });
  if (typeof initPortalCatalogueFilter === 'function') initPortalCatalogueFilter();
}

function filterCat(btn, cat) {
  document.querySelectorAll('#catalogueFilters .filter-pill').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const search = gv('catalogueSearchInput').toLowerCase();
  filteredCatalogue = catalogue.filter(p =>
    (!cat || p.category_name === cat) &&
    (!search || (p.product_name||'').toLowerCase().includes(search) || (p.description||'').toLowerCase().includes(search))
  );
  renderCatalogue();
}

function filterSearch(val) {
  const activeCat = document.querySelector('#catalogueFilters .filter-pill.active')?.dataset?.cat || '';
  filteredCatalogue = catalogue.filter(p =>
    (!activeCat || p.category_name === activeCat) &&
    (!val || (p.product_name||'').toLowerCase().includes(val.toLowerCase()) || (p.description||'').toLowerCase().includes(val.toLowerCase()))
  );
  renderCatalogue();
}

function getProductIcon(p) {
  const n = (p.product_name||'').toLowerCase();
  const c = (p.category_id||p.category_name||'').toLowerCase();
  if (n.includes('mirch')||n.includes('chilli')||n.includes('pepper')||n.includes('kashmiri')) return 'fa-solid fa-pepper-hot';
  if (n.includes('haldi')||n.includes('turmeric')) return 'fa-solid fa-mortar-pestle';
  if (n.includes('jeera')||n.includes('cumin')||n.includes('coriander')||n.includes('dhania')) return 'fa-solid fa-leaf';
  if (n.includes('rice')||n.includes('basmati')||n.includes('chawal')) return 'fa-solid fa-bowl-rice';
  if (n.includes('wheat')||n.includes('gehun')||n.includes('flour')||n.includes('atta')) return 'fa-solid fa-wheat-awn';
  if (n.includes('soy')||n.includes('chana')||n.includes('dal')||n.includes('pulse')||n.includes('lentil')) return 'fa-solid fa-circle-dot';
  if (n.includes('onion')||n.includes('pyaz')) return 'fa-solid fa-circle';
  if (n.includes('garlic')||n.includes('lahsun')) return 'fa-solid fa-asterisk';
  if (n.includes('sesame')||n.includes('til')) return 'fa-solid fa-seedling';
  if (n.includes('oil')||n.includes('tel')) return 'fa-solid fa-droplet';
  if (n.includes('sugar')||n.includes('jaggery')||n.includes('gur')) return 'fa-solid fa-cubes-stacked';
  if (n.includes('cotton')||n.includes('kapas')) return 'fa-solid fa-cloud';
  if (n.includes('maize')||n.includes('corn')||n.includes('makka')||n.includes('sorghum')||n.includes('jowar')) return 'fa-solid fa-wheat-awn';
  if (c.includes('spice')||c.includes('masala')) return 'fa-solid fa-mortar-pestle';
  if (c.includes('grain')||c.includes('cereal')) return 'fa-solid fa-wheat-awn';
  if (c.includes('veggie')||c.includes('vegetable')) return 'fa-solid fa-carrot';
  if (c.includes('seed')||c.includes('oil')) return 'fa-solid fa-seedling';
  if (c.includes('pulse')||c.includes('dal')) return 'fa-solid fa-circle-dot';
  if (c.includes('fruit')) return 'fa-solid fa-apple-whole';
  return 'fa-solid fa-seedling';
}

function likedProductsKey() {
  return currentUser ? 'ax_liked_products_' + currentUser.sub : 'ax_liked_products_guest';
}
function getLikedProducts() {
  try { return JSON.parse(localStorage.getItem(likedProductsKey()) || '[]'); } catch (e) { return []; }
}
function isProductLiked(key) {
  return getLikedProducts().indexOf(key) !== -1;
}
function toggleProductLike(ev, key, btn) {
  if (ev) ev.stopPropagation(); // don't trigger the card's own onclick (open product)
  let liked = getLikedProducts();
  const i = liked.indexOf(key);
  let nowLiked;
  if (i === -1) { liked.push(key); nowLiked = true; }
  else { liked.splice(i, 1); nowLiked = false; }
  localStorage.setItem(likedProductsKey(), JSON.stringify(liked));
  if (btn) {
    btn.classList.toggle('liked', nowLiked);
    const icon = btn.querySelector('i');
    if (icon) icon.className = (nowLiked ? 'fa-solid' : 'fa-regular') + ' fa-heart';
  }
  refreshFavouritesGridIfVisible();
  if (!currentUser || !localStorage.getItem('ax_google_token')) return;
  fetch(LAMBDA_URL + '/favourites/toggle', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + localStorage.getItem('ax_google_token') },
    body: JSON.stringify({ key: key, liked: nowLiked })
  }).then(function (res) {
    if (res.ok) return;
    var reverted = getLikedProducts();
    var at = reverted.indexOf(key);
    if (nowLiked && at !== -1) reverted.splice(at, 1);
    if (!nowLiked && at === -1) reverted.push(key);
    localStorage.setItem(likedProductsKey(), JSON.stringify(reverted));
    renderCatalogue();
    refreshFavouritesGridIfVisible();
    showToast('Could not save favourite. Please try again.', 'error');
  }).catch(function () {
    var reverted = getLikedProducts();
    var at = reverted.indexOf(key);
    if (nowLiked && at !== -1) reverted.splice(at, 1);
    if (!nowLiked && at === -1) reverted.push(key);
    localStorage.setItem(likedProductsKey(), JSON.stringify(reverted));
    renderCatalogue();
    refreshFavouritesGridIfVisible();
    showToast('Could not save favourite. Please try again.', 'error');
  });
}

/* Re-renders the standalone Favourites grid only when that panel is the one
   currently on screen — cheap no-op from the Trade tab, but on the
   Favourites page itself this is what makes an unliked card disappear
   immediately instead of waiting for the next panel switch. */
function refreshFavouritesGridIfVisible() {
  const favPanel = document.getElementById('panel-favourites');
  if (favPanel && favPanel.classList.contains('active') && typeof renderFavouritesGrid === 'function') {
    renderFavouritesGrid();
  }
}

async function syncFavourites() {
  if (!currentUser || !localStorage.getItem('ax_google_token')) return;
  try {
    const res = await fetch(LAMBDA_URL + '/favourites', { headers: { Authorization: 'Bearer ' + localStorage.getItem('ax_google_token'), Accept: 'application/json' } });
    const data = await res.json();
    if (res.ok && Array.isArray(data.liked_keys)) {
      localStorage.setItem(likedProductsKey(), JSON.stringify(data.liked_keys));
      if (typeof renderCatalogue === 'function') renderCatalogue();
    }
  } catch (e) { console.warn('[Favourites] sync failed', e); }
}

function renderStarRating(avg) {
  const n = parseFloat(avg) || 0;
  if (!n) {
    // §0-5: zero/no reviews yet — an empty 5-star row reads as "rated zero",
    // which is worse than showing nothing. Show only the New badge, no stars.
    return '<div class="product-card-rating"><span class="rating-count rating-count-new">New</span></div>';
  }
  // Inline-SVG stars instead of ★/☆ text glyphs: stroke-linejoin:round
  // softens every point (no sharp spikes), unfilled stars render as grey
  // outlines and filled ones as solid dark gold — see .ax-star in
  // portal-base.css. Flex row keeps the numeric score vertically centred
  // beside the stars instead of drifting on the text baseline.
  const filled = Math.round(Math.min(5, Math.max(0, n)));
  let stars = '';
  for (let i = 0; i < 5; i++) {
    stars += '<svg class="ax-star' + (i < filled ? ' filled' : '') + '" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.8l2.44 4.95 5.46.79-3.95 3.85.93 5.44L12 16.26l-4.88 2.57.93-5.44-3.95-3.85 5.46-.79z"/></svg>';
  }
  return '<div class="product-card-rating"><span class="rating-stars rating-stars-svg">' + stars + '</span><span class="rating-count">' + n.toFixed(1) + '</span></div>';
}

/* Which array a card index refers to — 'catalogue' cards are indexed into
   filteredCatalogue (Trade tab), 'favourites' cards are indexed into
   favouritesCatalogue (standalone Favourites page). Keeping this as a small
   lookup (rather than window[name]) because these are `let`-scoped globals,
   not `var`, so they never attach to window. */
function productListBySource(source) {
  return source === 'favourites' ? favouritesCatalogue : filteredCatalogue;
}

/* Shared product-card markup used by both renderCatalogue() (Trade tab)
   and renderFavouritesGrid() (My Favourites page) — avoids maintaining two
   copies of the same card HTML. `source` tags the card's click handlers so
   they look the product back up in the right array. */
function buildProductCardHtml(p, idx, source) {
  source = source || 'catalogue';
  const iconClass = getProductIcon(p);
  const hasImg = p.image_url && p.image_url.trim().length > 10;
  const disc = typeof CatalogueUI !== 'undefined' ? CatalogueUI.priceDiscountInfo(p) : { show: false, pct: 0, mrpHtml: '', badgeHtml: '' };
  const usingLot = !!(p.lot_size_kg && p.lot_price);
  const priceNow = usingLot ? p.lot_price : p.price_per_kg;
  const qtyLabel = usingLot ? ('1 lot (' + p.lot_size_kg + ' kg)') : (p.price_per_kg ? 'per kg' : '');
  const priceHtml = priceNow
    ? '<div class="product-card-price-row"><span class="product-card-price-now">₹' + priceNow + '</span>' + disc.mrpHtml + '</div>' +
      (disc.show ? '<div class="product-card-discount-note">' + disc.pct + '% OFF on MRP</div>' : '')
    : '<div class="product-card-price-row"><span class="product-card-price-now product-card-price-unset">Contact for price</span></div>';
  const stockTextLc = (p.available_stock||'').toLowerCase();
  const isOut = stockTextLc.includes('out');
  const isLow = !isOut && (stockTextLc.includes('low') || stockTextLc.includes('limited') || stockTextLc.includes('few'));
  const stockColor = isOut ? '#EF4444' : (isLow ? '#EF4444' : '#22C55E');
  const stockUrgentStyle = isLow ? ' style="background:rgba(239,68,68,.08);border-radius:999px;padding:2px 9px;font-weight:800"' : '';
  const imgSrc = hasImg ? p.image_url.trim() : '';
  const likeKey = (p.shop_id||'')+'::'+(p.product_id||idx);
  const isLiked = isProductLiked(likeKey);
  const ratingNum = parseFloat(p.avg_rating) || 0;
  const ratedBadge = ratingNum >= 4.5 ? '<span class="product-card-badge-rated">Top Rated</span>' : '';
  return '<div class="product-card product-card-reveal" style="animation-delay:'+Math.min(idx*35,350)+'ms" onclick="selectProductByIndex('+idx+',\''+source+'\')">' +
    '<div class="product-card-media">' +
      (hasImg
        ? '<img class="product-card-thumb" src="'+imgSrc+'" alt="'+p.product_name+'" loading="lazy" onerror="this.onerror=null;this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">' +
          '<div class="product-card-placeholder" style="display:none"><i class="'+iconClass+'"></i></div>'
        : '<div class="product-card-placeholder"><i class="'+iconClass+'"></i></div>') +
      ratedBadge +
      '<button type="button" class="product-card-like-btn'+(isLiked?' liked':'')+'" onclick="toggleProductLike(event,\''+likeKey+'\',this)"><i class="'+(isLiked?'fa-solid':'fa-regular')+' fa-heart"></i></button>' +
      '<div class="product-card-media-footer">' +
        (qtyLabel ? '<span class="product-card-qty-chip">'+qtyLabel+'</span>' : '<span></span>') +
        '<button type="button" class="product-card-add-btn" onclick="directBuyByIndex('+idx+',event,\''+source+'\')" aria-label="Buy"><i class="fa-solid fa-bolt"></i></button>' +
      '</div>' +
    '</div>' +
    '<div class="product-card-body">' +
      priceHtml +
      '<div class="product-card-name">'+p.product_name+'</div>' +
      renderStarRating(p.avg_rating) +
      '<div class="product-card-stock"'+stockUrgentStyle+'><i class="fa-solid fa-circle" style="color:'+stockColor+'"></i> '+(p.available_stock||'In Stock')+'</div>' +
    '</div></div>';
}

function renderCatalogue() {
  const grid = document.getElementById('productGrid');
  if (!filteredCatalogue.length) {
    // Agar catalogue hi empty hai (koi product add nahi hua) vs search match nahi
    const isSearchActive = (document.getElementById('catalogueSearchInput')?.value||'').trim().length > 0;
    const catalogueIsEmpty = catalogue.length === 0;
    if (catalogueIsEmpty) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:var(--s7);color:var(--c-text3)">' +
        '<div class="empty-icon-wrap"><i class="fa-solid fa-store"></i></div>' +
        '<div style="font-size:17px;font-weight:700;color:var(--c-text2);margin-bottom:8px">Products coming soon</div>' +
        '<div style="font-size:13px;line-height:1.6">Sellers are onboarding right now.<br>Check back shortly or <a onclick="switchPanel(\'sell\')" style="color:var(--c-leaf2);font-weight:700;cursor:pointer">list your own produce →</a></div>' +
        '</div>';
    } else {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:var(--s7);color:var(--c-text3)"><div class="empty-icon-wrap"><i class="fa-solid fa-magnifying-glass"></i></div><div style="font-size:16px;font-weight:600;">No products found</div><div style="font-size:13px;margin-top:8px">Try a different search or category</div></div>';
    }
    return;
  }
  grid.innerHTML = filteredCatalogue.map((p, idx) => buildProductCardHtml(p, idx, 'catalogue')).join('');
}

/* Standalone "My Favourites" page (see panel-favourites) — filters the
   full catalogue down to whatever the user has liked, using the same
   likeKey convention as renderCatalogue(). This is deliberately separate
   from the Trade tab's own catalogue, which always shows everything
   (see applyPortalCatalogueFilters — no favourites filtering there). */
function renderFavouritesGrid() {
  favouritesCatalogue = catalogue.filter((p, idx) => {
    const likeKey = (p.shop_id||'')+'::'+(p.product_id||idx);
    return isProductLiked(likeKey);
  });
  favouritesCatalogueAll = favouritesCatalogue.slice();
  const searchInput = document.getElementById('favSearchInput');
  if (searchInput) searchInput.value = '';
  document.getElementById('favSearchClearBtn')?.classList.remove('show');
  renderFavouritesGridCards();
}

/* Renders whatever is currently in `favouritesCatalogue` (the full liked
   list, or a text/category-filtered subset of it — see filterFavouritesGrid
   / filterFavouritesGridByCategory below). Kept separate from
   renderFavouritesGrid() so filtering never re-fetches the like-state from
   `catalogue`, it just re-slices the already-known liked list. */
function renderFavouritesGridCards() {
  const grid = document.getElementById('favouritesGrid');
  if (!grid) return;
  if (!favouritesCatalogue.length) {
    const noneAtAll = !favouritesCatalogueAll.length;
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:var(--s7);color:var(--c-text3)">' +
      (typeof CatalogueUI !== 'undefined'
        ? CatalogueUI.emptyStateHtml({
            icon: noneAtAll ? 'fa-heart' : 'fa-magnifying-glass',
            message: noneAtAll
              ? "No favourites yet. Go to Trade and tap the heart icon on a product to save it here."
              : "No favourites match your search."
          })
        : '<div class="empty-icon-wrap"><i class="fa-solid fa-heart"></i></div><div style="font-size:16px;font-weight:600;">' + (noneAtAll ? 'No favourites yet' : 'No matches') + '</div><div style="font-size:13px;margin-top:8px">' + (noneAtAll ? 'Go to Trade and tap the heart icon on a product to save it here.' : 'No favourites match your search.') + '</div>') +
      '</div>';
    return;
  }
  grid.innerHTML = favouritesCatalogue.map((p, idx) => buildProductCardHtml(p, idx, 'favourites')).join('');
}

/* ══════════════════════════════════════════════════════════════
   AX SEARCH BAR + CATEGORY QUICK-GRID (Prompt 4.txt Tasks B/D/E)
   Shared full-screen category grid opened by tapping the leading icon
   on the Home, Trade or Favourites search bars. Home has no catalogue
   grid of its own so it redirects into Trade; Favourites filters its
   own already-loaded liked list in place; Trade reuses the existing
   #catalogueFilters pills so filtering logic is never duplicated.
   ══════════════════════════════════════════════════════════════ */
let axCategoryGridSource = 'trade';
function axSourceInputId() {
  return axCategoryGridSource === 'favourites' ? 'favSearchInput' : 'catalogueSearchInput';
}

/* Admin-uploaded category photos (see admin_dashboard.html "Category
   Images" card) — fetched once and cached; falls back to the generic
   categoryIconFor() icon for any category that has no photo configured.
   Keys are lowercased so admin-entered casing never has to exactly match
   the catalogue's category_name. */
let axCategoryImages = null;
let axCategoryImagesPromise = null;
let axCategoryImageNames = []; // original-casing names from the admin config
function fetchCategoryImages(force) {
  // `force` re-fetches so categories the admin just added show up on the
  // next grid open without a full page reload (the old always-cached
  // version is why "maine do category add kiye lekin purani hi dikh rahi
  // hai" happened).
  if (axCategoryImagesPromise && !force) return axCategoryImagesPromise;
  axCategoryImagesPromise = fetch(LAMBDA_URL + '/category/images?t=' + Date.now(), { headers: { Accept: 'application/json' }, cache: 'no-store' })
    .then(res => res.json())
    .then(data => {
      const raw = (data && data.images) || {};
      axCategoryImages = {};
      axCategoryImageNames = Object.keys(raw);
      Object.keys(raw).forEach(k => { axCategoryImages[k.toLowerCase()] = raw[k]; });
      return axCategoryImages;
    })
    .catch(() => { axCategoryImages = axCategoryImages || {}; return axCategoryImages; });
  return axCategoryImagesPromise;
}
function categoryImageFor(cat) {
  return axCategoryImages ? axCategoryImages[(cat || '').toLowerCase()] : null;
}
function renderCategoryGridItems(cats) {
  const grid = document.getElementById('axCategoryGrid');
  if (!grid) return;
  // "All" always leads; every real category follows; "Other" always closes
  // the list (fallback bucket for products whose category was deleted).
  const allTile = '<button type="button" class="ax-category-grid-item" onclick="selectQuickCategory(\'__ALL__\')">' +
    '<span class="cat-icon-circle cat-icon-all"><i class="fa-solid fa-border-all"></i></span><span class="label">All</span></button>';
  grid.innerHTML = allTile + (cats.length
    ? cats.map(cat => {
        const img = categoryImageFor(cat);
        const tile = img
          ? '<span class="cat-icon-circle cat-icon-photo" style="background-image:url(&quot;' + img.replace(/"/g, '%22') + '&quot;)"></span>'
          : '<span class="cat-icon-circle"><i class="fa-solid ' + categoryIconFor(cat) + '"></i></span>';
        return '<button type="button" class="ax-category-grid-item" onclick=\'selectQuickCategory(' + JSON.stringify(cat) + ')\'>' + tile + '<span class="label">' + cat.replace(/</g, '&lt;') + '</span></button>';
      }).join('')
    : '');
}

/* Merged category list: product categories (live catalogue) + every
   category the admin configured an image for — so a brand-new category
   with no products yet still appears — with "Other" pinned last. */
function axAllCategoryNames() {
  const seen = {};
  const out = [];
  const add = (name) => {
    const key = (name || '').trim().toLowerCase();
    if (!key || key === 'other' || seen[key]) return;
    seen[key] = true;
    out.push(name.trim());
  };
  catalogue.forEach(p => add(p.category_name || 'Other'));
  axCategoryImageNames.forEach(add);
  out.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
  out.push('Other');
  return out;
}

function openCategoryQuickGrid(source) {
  axCategoryGridSource = source || 'trade';
  axSetQuickGridMode('categories');
  renderCategoryGridItems(axAllCategoryNames());
  // Always re-fetch the admin category config in the background so newly
  // added categories/images appear without a page reload.
  fetchCategoryImages(true).then(() => renderCategoryGridItems(axAllCategoryNames()));
  const sourceInput = document.getElementById(axSourceInputId());
  const overlayInput = document.getElementById('axCategoryGridSearchInput');
  if (overlayInput) {
    overlayInput.value = sourceInput ? sourceInput.value : '';
    if (sourceInput) overlayInput.placeholder = sourceInput.placeholder;
  }
  document.getElementById('axCategoryGridOverlay')?.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(() => overlayInput && overlayInput.focus(), 50);
}

/* ── Categories | Shops toggle inside the quick grid ── */
let axQuickGridMode = 'categories';
let axShopsCache = null;
function axSetQuickGridMode(mode) {
  axQuickGridMode = mode;
  const catGrid = document.getElementById('axCategoryGrid');
  const shopList = document.getElementById('axShopsGridList');
  const label = document.getElementById('axCategoryGridLabel');
  document.querySelectorAll('.ax-grid-mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  if (catGrid) catGrid.style.display = mode === 'categories' ? '' : 'none';
  if (shopList) shopList.style.display = mode === 'shops' ? '' : 'none';
  if (label) label.textContent = mode === 'shops' ? 'Browse shops' : 'Browse by category';
  if (mode === 'shops') axRenderShopsGrid();
}
async function axRenderShopsGrid() {
  const list = document.getElementById('axShopsGridList');
  if (!list) return;
  if (!axShopsCache) {
    list.innerHTML = '<p class="ax-category-grid-empty"><i class="fa-solid fa-spinner fa-spin"></i> Loading shops…</p>';
    try {
      const res = await fetch(LAMBDA_URL + '/shop/list?limit=100', { headers: { Accept: 'application/json' } });
      const data = await res.json();
      axShopsCache = data.shops || [];
    } catch (e) {
      list.innerHTML = '<p class="ax-category-grid-empty">Could not load shops — try again.</p>';
      return;
    }
  }
  if (!axShopsCache.length) {
    list.innerHTML = '<p class="ax-category-grid-empty">No shops yet.</p>';
    return;
  }
  list.innerHTML = axShopsCache.map(s => {
    const initials = (s.shop_name || 'S').trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
    const meta = [s.shop_category, [s.address_city, s.address_state].filter(Boolean).join(', ')].filter(Boolean).join(' · ');
    return '<button type="button" class="ax-shop-row" onclick=\'axOpenShopFromGrid(' + JSON.stringify(s.shop_id) + ')\'>' +
      '<span class="ax-shop-row-avatar">' + (s.shop_logo_url ? '<img src="' + s.shop_logo_url.replace(/"/g, '%22') + '" alt="">' : initials) + '</span>' +
      '<span class="ax-shop-row-info"><b>' + String(s.shop_name || s.shop_id).replace(/</g, '&lt;') + '</b>' +
        '<small>' + String(meta || 'Verified seller').replace(/</g, '&lt;') + '</small></span>' +
      '<span class="ax-shop-row-meta"><span><i class="fa-solid fa-star"></i> ' + (s.avg_rating || 0) + '</span>' +
        '<span>' + (s.product_count || 0) + ' products</span></span>' +
    '</button>';
  }).join('');
}
function axOpenShopFromGrid(shopId) {
  closeCategoryQuickGrid();
  if (window.ProductModal && typeof ProductModal.openShopProfile === 'function') {
    ProductModal.openShopProfile(shopId);
  }
}
function closeCategoryQuickGrid() {
  document.getElementById('axCategoryGridOverlay')?.classList.remove('open');
  document.body.style.overflow = '';
}
/* Typing inside the full-screen grid's own search field mirrors straight
   back to whichever page-level bar opened it, reusing THAT bar's existing
   filter pipeline (Trade's applyPortalCatalogueFilters via a real 'input'
   event, Favourites' filterFavouritesGrid directly) instead of building a
   second, parallel filtering implementation here. */
let axGridTypeTimer = null;
function axCategoryGridSearchChanged(val) {
  const sourceInput = document.getElementById(axSourceInputId());
  if (sourceInput) sourceInput.value = val;
  // Debounced: the downstream filters rebuild whole product grids, which
  // made typing in this overlay stutter on mobile.
  clearTimeout(axGridTypeTimer);
  axGridTypeTimer = setTimeout(() => {
    if (axCategoryGridSource === 'favourites') {
      filterFavouritesGrid(val);
    } else if (sourceInput) {
      sourceInput.dispatchEvent(new Event('input'));
    }
  }, 180);
}
function selectQuickCategory(cat) {
  closeCategoryQuickGrid();
  if (cat === '__ALL__') {
    // "All" tile: clear every filter and show the full list again.
    if (axCategoryGridSource === 'favourites') renderFavouritesGrid();
    else filterCatalogueByCategoryName('all');
    return;
  }
  if (axCategoryGridSource === 'favourites') {
    filterFavouritesGridByCategory(cat);
  } else {
    filterCatalogueByCategoryName(cat);
  }
}
/* Drives the category filter through the SAME #catalogueFilters pills +
   applyPortalCatalogueFilters() pipeline the Trade tab already uses, by
   simulating a click on the matching pill — avoids a second, parallel
   filtering implementation that could drift out of sync with the first. */
function filterCatalogueByCategoryName(cat) {
  const input = document.getElementById('catalogueSearchInput');
  if (input) { input.value = ''; input.dispatchEvent(new Event('input')); }
  const pill = document.querySelector('#catalogueFilters .filter-pill[data-cat="' + CSS.escape(cat) + '"]');
  if (pill) pill.click();
}

/* Favourites: filters the already-loaded liked-products list in place —
   no navigation, no backend call needed. */
function filterFavouritesGrid(query) {
  const q = (query || '').trim().toLowerCase();
  document.getElementById('favSearchClearBtn')?.classList.toggle('show', !!q);
  favouritesCatalogue = !q ? favouritesCatalogueAll.slice() : favouritesCatalogueAll.filter(p =>
    [p.product_name, p.category_name, p.shop_id, p.shop_name].join(' ').toLowerCase().includes(q)
  );
  renderFavouritesGridCards();
}
function filterFavouritesGridByCategory(cat) {
  const searchInput = document.getElementById('favSearchInput');
  if (searchInput) searchInput.value = '';
  document.getElementById('favSearchClearBtn')?.classList.remove('show');
  favouritesCatalogue = favouritesCatalogueAll.filter(p => (p.category_name || 'Other') === cat);
  renderFavouritesGridCards();
}

/* Clear-button show/hide sync for the Home + Favourites search bars —
   lightweight standalone version of the sync CatalogueUI.initFilterDropdown()
   already does for Trade's #catalogueSearchInput, since those two bars have
   no filter-dropdown menu (they open the full-screen category grid instead,
   see openCategoryQuickGrid above) and so can't reuse that function (it
   requires a menu element to be found before wiring anything). */
function wireSimpleSearchClear(inputId, clearId, onInput) {
  const input = document.getElementById(inputId);
  const clearBtn = document.getElementById(clearId);
  if (!input || !clearBtn) return;
  function sync() { clearBtn.classList.toggle('show', !!input.value.trim()); }
  // Debounce the grid-rebuilding filter callback (typing lag fix) — the
  // clear-button sync itself stays instant, it's just a class toggle.
  let filterTimer = null;
  input.addEventListener('input', () => {
    sync();
    if (typeof onInput !== 'function') return;
    clearTimeout(filterTimer);
    filterTimer = setTimeout(() => onInput(input.value), 180);
  });
  clearBtn.addEventListener('click', () => { clearTimeout(filterTimer); input.value = ''; sync(); if (typeof onInput === 'function') onInput(''); input.focus(); });
  sync();
}
document.addEventListener('DOMContentLoaded', function () {
  wireSimpleSearchClear('favSearchInput', 'favSearchClearBtn', filterFavouritesGrid);
});

function selectProductByIndex(idx, source) {
  const p = productListBySource(source)[idx];
  if (!p) return;
  if (typeof ProductModal !== 'undefined') ProductModal.openModal(p);
  else selectProductForOrder(p);
}

/* "Direct Buy" button on the catalogue card — skips the product detail
   modal and jumps straight into the order flow for that product. */
function directBuyByIndex(idx, ev, source) {
  if (ev) { ev.stopPropagation(); ev.preventDefault(); }
  const p = productListBySource(source)[idx];
  if (!p) return;
  selectProductForOrder(p);
}
