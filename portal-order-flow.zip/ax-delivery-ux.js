/* Aarvex Portal — Delivery/Track UX module
 * Journey strip, separate claims page + pause mode, radius filter,
 * distance-triangle overlay, Track-tab strip with 3-party contacts,
 * cancel-from-track, second-ARN lookup, map fullscreen label sync.
 * Load AFTER portal-delivery.js and portal-enhancements.js.
 */
'use strict';

/* ── Claims page (separate view inside the Delivery tab) ── */
let _axJourneyPaused = false;

function axOpenDeliveryClaimsView(viewOnly) {
  const home = document.getElementById('deliveryHomeView');
  const claims = document.getElementById('deliveryClaimsView');
  if (!home || !claims) return;
  home.style.display = 'none';
  claims.style.display = '';
  const radiusInput = document.getElementById('deliveryRadiusInput');
  if (radiusInput && !radiusInput.value) {
    radiusInput.value = localStorage.getItem('ax_delivery_radius_km') || '';
  }
  const pausedNote = document.getElementById('deliveryClaimsPausedNote');
  const resumeBtn = document.getElementById('deliveryResumeBtn');
  if (pausedNote) pausedNote.style.display = viewOnly ? '' : 'none';
  if (resumeBtn) resumeBtn.style.display = viewOnly ? '' : 'none';
  mpLoadDeliveryDashboard();
  window.scrollTo(0, 0);
}

function axCloseDeliveryClaimsView() {
  const home = document.getElementById('deliveryHomeView');
  const claims = document.getElementById('deliveryClaimsView');
  if (!home || !claims) return;
  claims.style.display = 'none';
  home.style.display = '';
}

/* Pause: journey stays fully alive (GPS keeps pushing, polling keeps
   running) — this only lets the partner LOOK at other available orders.
   Claim buttons stay locked until the current delivery closes. */
function axPauseJourneyView() {
  _axJourneyPaused = true;
  axOpenDeliveryClaimsView(true);
}
function axResumeJourneyView() {
  _axJourneyPaused = false;
  axCloseDeliveryClaimsView();
  window.scrollTo(0, 0);
}

/* ── Radius filter ── */
function axApplyDeliveryRadius() {
  const input = document.getElementById('deliveryRadiusInput');
  const km = parseFloat(input && input.value) || 0;
  if (km <= 0) {
    localStorage.removeItem('ax_delivery_radius_km');
    window._axPartnerPos = null;
    showToast('Radius filter cleared — showing all orders', 'info');
    mpLoadDeliveryDashboard();
    return;
  }
  localStorage.setItem('ax_delivery_radius_km', String(km));
  if (!navigator.geolocation) {
    showToast('GPS not available — radius needs your location', 'warning');
    mpLoadDeliveryDashboard();
    return;
  }
  showToast('Getting your location…', 'info');
  navigator.geolocation.getCurrentPosition(function (pos) {
    window._axPartnerPos = { lat: pos.coords.latitude, lng: pos.coords.longitude };
    showToast('Radius set: only orders within ' + km + ' km', 'success');
    mpLoadDeliveryDashboard();
  }, function () {
    showToast('Could not get location — enable GPS and try again', 'error');
    mpLoadDeliveryDashboard();
  }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 });
}

/* ── Journey UI state ── */
function axActivateJourneyUi() {
  const panel = document.getElementById('panel-delivery');
  if (panel) panel.classList.add('ax-journey-active');
  const strip = document.getElementById('deliveryInfoCard');
  if (strip) strip.style.display = 'block';
  axCloseDeliveryClaimsView();
  window.scrollTo(0, 0);
}
function axDeactivateJourneyUi() {
  _axJourneyPaused = false;
  const panel = document.getElementById('panel-delivery');
  if (panel) panel.classList.remove('ax-journey-active');
  const strip = document.getElementById('deliveryInfoCard');
  if (strip) { strip.style.display = 'none'; strip.classList.remove('collapsed'); }
}

/* Fresh /track data for the partner's own journey → keep the strip's call
   button live (renderDeliveryActiveMapData fills the name/km/ETA ids). */
window.axOnDeliveryTrackData = function (data) {
  const callBtn = document.getElementById('deliveryImporterCallBtn');
  if (callBtn) {
    const phone = (data && data.buyer_mobile) || '';
    callBtn.style.display = phone ? '' : 'none';
    if (phone) callBtn.href = 'tel:' + phone;
  }
};

/* ── Strip collapse (shared by delivery + track strips) ── */
function axToggleJourneyStrip(btn) {
  const strip = btn && btn.closest('.ax-journey-strip');
  if (!strip) return;
  const collapsed = strip.classList.toggle('collapsed');
  const icon = btn.querySelector('i');
  if (icon) icon.className = collapsed ? 'fa-solid fa-chevron-down' : 'fa-solid fa-chevron-up';
}

/* ── Map fullscreen button label sync ── */
function axSyncMapFsBtn(wrapId, btnId) {
  const wrap = document.getElementById(wrapId);
  const btn = document.getElementById(btnId);
  if (!wrap || !btn) return;
  const fs = wrap.classList.contains('fullscreen');
  btn.innerHTML = fs
    ? '<i class="fa-solid fa-compress"></i> Minimize'
    : '<i class="fa-solid fa-expand"></i> Fullscreen';
}

/* ══════════ DISTANCE TRIANGLE (delivery boy / shop / importer) ══════════
   One overlay for all three roles — opened from the delivery strip or the
   track strip. Uses the latest /track payload (pushed by
   portal-enhancements.js into window._axLastTrackData). */
function axShowTriangle() {
  const data = window._axLastTrackData;
  if (!data) { showToast('Track an order first to see the distance triangle', 'info'); return; }
  const shop = data.pickup && data.pickup.lat ? { lat: +data.pickup.lat, lng: +data.pickup.lng } : null;
  const dest = data.destination && data.destination.lat ? { lat: +data.destination.lat, lng: +data.destination.lng } : null;
  const boy = data.driver_location && data.driver_location.lat ? { lat: +data.driver_location.lat, lng: +data.driver_location.lng } : null;
  const fmt = function (km) { return km == null ? '—' : (km < 10 ? km.toFixed(1) : Math.round(km)) + ' km'; };
  const dist = function (a, b) { return (a && b) ? calculateDistance(a.lat, a.lng, b.lat, b.lng) : null; };
  const dBoyShop = dist(boy, shop);
  const dShopImp = dist(shop, dest);
  const dImpBoy = dist(dest, boy);
  const partnerName = (data.delivery_partner && data.delivery_partner.name) || 'Delivery boy';
  const buyerName = data.buyer_name || 'Importer';
  const shopName = (data.seller_contact && data.seller_contact.name) || (data.pickup && data.pickup.city) || 'Shop';
  let overlay = document.getElementById('axTriangleOverlay');
  if (overlay) overlay.remove();
  overlay = document.createElement('div');
  overlay.id = 'axTriangleOverlay';
  overlay.className = 'ax-triangle-overlay';
  overlay.innerHTML =
    '<div class="ax-triangle-box">' +
      '<div class="ax-triangle-head">' +
        '<h3><i class="fa-solid fa-diagram-project"></i> Delivery Triangle</h3>' +
        '<button type="button" class="ax-strip-icon-btn" id="axTriangleCloseBtn" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>' +
      '</div>' +
      '<svg viewBox="0 0 320 260" class="ax-triangle-svg" aria-hidden="true">' +
        '<line x1="160" y1="46" x2="46"  y2="214" stroke="#2E6B41" stroke-width="2.5" stroke-dasharray="6 5"/>' +
        '<line x1="46"  y1="214" x2="274" y2="214" stroke="#C7993A" stroke-width="2.5" stroke-dasharray="6 5"/>' +
        '<line x1="274" y1="214" x2="160" y2="46"  stroke="#2A7F7E" stroke-width="2.5" stroke-dasharray="6 5"/>' +
        '<circle cx="160" cy="46" r="22" fill="#2E6B41"/>' +
        '<circle cx="46" cy="214" r="22" fill="#C7993A"/>' +
        '<circle cx="274" cy="214" r="22" fill="#2A7F7E"/>' +
        '<text x="160" y="52" text-anchor="middle" font-size="14" fill="#fff" font-weight="700">DB</text>' +
        '<text x="46" y="220" text-anchor="middle" font-size="14" fill="#fff" font-weight="700">SH</text>' +
        '<text x="274" y="220" text-anchor="middle" font-size="14" fill="#fff" font-weight="700">IM</text>' +
        '<text x="88"  y="122" text-anchor="middle" font-size="13" font-weight="700" fill="#2E6B41">' + fmt(dBoyShop) + '</text>' +
        '<text x="160" y="240" text-anchor="middle" font-size="13" font-weight="700" fill="#8A6B2E">' + fmt(dShopImp) + '</text>' +
        '<text x="234" y="122" text-anchor="middle" font-size="13" font-weight="700" fill="#236866">' + fmt(dImpBoy) + '</text>' +
      '</svg>' +
      '<div class="ax-triangle-legend">' +
        '<div><span class="ax-tri-dot" style="background:#2E6B41"></span> ' + mpEscDelivery(partnerName) + ' (delivery boy)</div>' +
        '<div><span class="ax-tri-dot" style="background:#C7993A"></span> ' + mpEscDelivery(shopName) + ' (shop)</div>' +
        '<div><span class="ax-tri-dot" style="background:#2A7F7E"></span> ' + mpEscDelivery(buyerName) + ' (importer)</div>' +
      '</div>' +
      '<div class="ax-triangle-rows">' +
        '<div><span>Delivery boy to Shop</span><b>' + fmt(dBoyShop) + '</b></div>' +
        '<div><span>Shop to Importer</span><b>' + fmt(dShopImp) + '</b></div>' +
        '<div><span>Importer to Delivery boy</span><b>' + fmt(dImpBoy) + '</b></div>' +
      '</div>' +
      (!boy ? '<p class="ax-triangle-note"><i class="fa-solid fa-circle-info"></i> Live location of the delivery boy is not available yet — all three distances appear once the journey starts.</p>' : '') +
    '</div>';
  overlay.addEventListener('click', function (e) { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  const closeBtn = document.getElementById('axTriangleCloseBtn');
  if (closeBtn) closeBtn.addEventListener('click', function () { overlay.remove(); });
}

/* ══════════ TRACK-TAB STRIP (importer / shop keeper / delivery boy) ══════════ */
window.axRenderTrackStrip = function (data) {
  const strip = document.getElementById('axTrackStrip');
  if (!strip || !data) return;
  strip.style.display = 'block';
  const set = function (id, txt) { const el = document.getElementById(id); if (el) el.textContent = txt; };
  set('axTrackStripProduct', data.product_name || 'Order');
  set('axTrackStripArn', data.arn || '');
  set('axTrackStripStatus', String(data.status || '—').replace(/_/g, ' '));
  set('axTrackStripKm', data.distance_remaining_km != null ? data.distance_remaining_km + ' km' : '-- km');
  set('axTrackStripEta', data.eta_minutes != null ? data.eta_minutes + ' min' : '-- min');
  const contacts = [];
  if (data.buyer_name || data.buyer_mobile) contacts.push({ icon: 'fa-user', label: 'Importer', name: data.buyer_name || '—', phone: data.buyer_mobile || '' });
  if (data.seller_contact) contacts.push({ icon: 'fa-store', label: 'Shop keeper', name: data.seller_contact.name || '—', phone: data.seller_contact.phone || '' });
  if (data.delivery_partner) contacts.push({ icon: 'fa-truck-fast', label: 'Delivery boy', name: data.delivery_partner.name || '—', phone: data.delivery_partner.phone || '' });
  const wrap = document.getElementById('axTrackStripContacts');
  if (wrap) {
    wrap.innerHTML = contacts.map(function (c) {
      return '<div class="ax-contact-row">' +
        '<span class="ax-contact-icon"><i class="fa-solid ' + c.icon + '"></i></span>' +
        '<span class="ax-contact-text"><small>' + c.label + '</small><b>' + mpEscDelivery(c.name) + '</b></span>' +
        (c.phone
          ? '<a class="ax-contact-call" href="tel:' + mpEscDelivery(c.phone) + '"><i class="fa-solid fa-phone"></i> Call</a>'
          : '<span class="ax-contact-call ax-contact-call-na">No number</span>') +
      '</div>';
    }).join('') || '<div class="ax-contact-row"><span class="ax-contact-text"><small>Contacts appear once a delivery partner claims this order.</small></span></div>';
  }
  // Cancel makes no sense once delivered/cancelled.
  const cancelBtn = document.getElementById('axTrackCancelBtn');
  if (cancelBtn) cancelBtn.style.display = (data.status === 'COMPLETED' || data.status === 'CANCELLED') ? 'none' : '';
};

/* Cancel from the Track tab — the backend decides which of the three
   parties you are (importer / shop keeper / delivery partner) and
   notifies the others. Falls back to /order/cancel for pre-claim
   importer cancels. */
async function axCancelTrackedOrder() {
  const input = document.getElementById('trackARN');
  const arn = ((input && input.value) || (window._axLastTrackData && window._axLastTrackData.arn) || '').trim();
  if (!arn) { showToast('Track an order first', 'error'); return; }
  if (!confirm('Cancel order ' + arn + '? All parties will be notified.')) return;
  let data = await mpApi('/delivery/cancel', { method: 'POST', body: JSON.stringify({ arn: arn }) });
  if (!data || !data.success) {
    const fallback = await mpApi('/order/cancel', { method: 'POST', body: JSON.stringify({ arn: arn }) });
    if (fallback && fallback.success) data = fallback;
    else if (fallback && fallback.error) data = fallback;
  }
  if (data && data.success) {
    showToast('Order cancelled', 'success');
    if (typeof trackOrder === 'function') trackOrder();
  } else {
    showToast((data && data.error) || 'Could not cancel this order', 'error');
  }
}

/* Second product? Reset the lookup so another ARN can be tracked without
   reloading the page. */
function axTrackAnother() {
  const input = document.getElementById('trackARN');
  const result = document.getElementById('trackResult');
  const strip = document.getElementById('axTrackStrip');
  if (result) result.style.display = 'none';
  if (strip) strip.style.display = 'none';
  if (typeof PortalEnhancements !== 'undefined' && PortalEnhancements.stopTrackPolling) {
    try { PortalEnhancements.stopTrackPolling(); } catch (e) {}
  }
  if (input) { input.value = ''; input.focus(); }
  window.scrollTo(0, 0);
}

/* Notification "Track live" button — jump straight into the Track tab with
   the ARN filled in and the live map opening (used by catalogue-ui.js). */
function axOpenTrackFromNotif(arn) {
  if (typeof switchPanel === 'function') switchPanel('track');
  const input = document.getElementById('trackARN');
  if (input) input.value = arn || '';
  if (typeof trackOrder === 'function') trackOrder();
}

/* ── Dark mode ── head inline script applied the saved theme pre-paint;
   this just flips + persists it and keeps the drawer row's label live. */
function axSyncThemeUi() {
  const dark = document.documentElement.getAttribute('data-theme') === 'dark';
  const icon = document.getElementById('axThemeIcon');
  const label = document.getElementById('axThemeLabel');
  if (icon) icon.className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  if (label) label.textContent = dark ? 'Light Mode' : 'Dark Mode';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', dark ? '#121714' : '#143026');
}
function axToggleTheme() {
  const dark = document.documentElement.getAttribute('data-theme') === 'dark';
  if (dark) document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', 'dark');
  try { localStorage.setItem('ax_theme', dark ? 'light' : 'dark'); } catch (e) {}
  axSyncThemeUi();
}
document.addEventListener('DOMContentLoaded', axSyncThemeUi);
