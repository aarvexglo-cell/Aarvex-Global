/* Aarvex Portal — Marketplace, KYC, Shop, Notifications, Ads */
'use strict';

let mpKycStatus = 'none';
let mpKycRole = 'shop_owner';
let mpSubscriptionActive = false;
let mpShop = null;
let mpProducts = [];
let mpNotifUnread = 0;
let mpReviewRating = 0;
let mpCurrentOrderArn = null;

function mpAuthHeaders() {
  const h = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem('ax_google_token');
  if (token) h['Authorization'] = 'Bearer ' + token;
  return h;
}

async function mpApi(path, opts = {}) {
  // Proactive: refresh the Google token BEFORE it's used if it's already
  // expired (or about to, within 60s) — silent, no popup for the person.
  if (typeof window.ensureFreshGoogleToken === 'function') {
    try { await window.ensureFreshGoogleToken(); } catch (e) { /* fall through with whatever token we have */ }
  }
  const res = await fetch(LAMBDA_URL + path, {
    ...opts,
    headers: { ...mpAuthHeaders(), ...(opts.headers || {}) },
  });
  const text = await res.text();
  let data;
  try {
    data = text.charAt(0) === '{' ? JSON.parse(text) : { error: 'Invalid response', status: res.status };
  } catch (e) {
    data = { error: 'Invalid JSON', status: res.status };
  }
  // Reactive fallback: covers the token expiring in the tiny window between
  // the proactive check above and the server processing the request, or a
  // browser environment where silent refresh wasn't possible earlier. One
  // retry only (opts._retried guards against looping forever).
  if (res.status === 401 && !opts._retried && typeof window.ensureFreshGoogleToken === 'function'
      && typeof currentUser !== 'undefined' && currentUser && currentUser.provider === 'google') {
    await window.ensureFreshGoogleToken();
    return mpApi(path, { ...opts, _retried: true });
  }
  return data;
}

async function mpLoadKycStatus() {
  const data = await mpApi('/kyc/status');
  // ROOT-CAUSE FIX ("Shop/Delivery/Both button disappears after a while"):
  // this call used to blindly overwrite mpKycStatus/mpKycRole/mpShop with
  // data.kyc?.* even when the request itself FAILED (401 from an expired
  // Google token, a transient network blip, etc). On failure `data` is
  // `{error: "..."}` with no `.kyc` key, so `data.kyc?.status || 'none'`
  // silently reset the role to defaults and hid the Shop nav — even though
  // the user's real KYC role never changed. Now: if the call failed, keep
  // whatever we already knew and leave every nav button exactly as it was.
  if (!data || data.error) {
    console.warn('[KYC] status fetch failed — keeping last known role/nav state', data && data.error);
    return data; // let callers (e.g. portal-delivery.js) see the failure too
  }
  mpKycStatus = data.kyc?.status || 'none';
  mpKycRole = data.kyc?.kyc_role || 'shop_owner';
  mpSubscriptionActive = !!data.subscription?.active;
  mpShop = data.shop || null;
  const shopNav = document.getElementById('navShop');
  const mobileShop = document.getElementById('mobileNavShop');
  const showShop = mpKycStatus === 'approved' && (mpKycRole === 'shop_owner' || mpKycRole === 'both');
  if (shopNav) shopNav.style.display = showShop ? '' : 'none';
  if (mobileShop) mobileShop.style.display = showShop ? '' : 'none';
  updateKycUI(data);
  updateShopUI();
  renderDashboardCta(data);
  return data;
}

function renderDashboardCta(data) {
  const container = document.getElementById('dashShopCta');
  if (!container) return;
  const showDelivery = mpKycStatus === 'approved' && (mpKycRole === 'delivery_partner' || mpKycRole === 'both');
  const showShop = mpKycStatus === 'approved' && (mpKycRole === 'shop_owner' || mpKycRole === 'both');
  const kycPending = data.kyc?.status === 'pending';
  const kycNone = data.kyc?.status === 'none';
  let html = '';
  if (showDelivery) {
    html += `
      <div class="dash-cta-grid" style="grid-template-columns:1fr;gap:var(--s3);margin-bottom:var(--s4)">
        <div class="cta-card sell-cta" onclick="switchPanel('delivery');mpLoadDeliveryDashboard()">
          <div class="cta-icon delivery" style="background:linear-gradient(135deg,#3E9159 0%,#143026 100%);"><i class="fa-solid fa-truck-fast"></i></div>
          <div>
            <div class="cta-title">Delivery Partner Dashboard</div>
            <div class="cta-desc">Your delivery jobs and earnings are ready. Claim orders, start journeys, and complete deliveries from one place.</div>
          </div>
          <div class="cta-arrow green"><i class="fa-solid fa-arrow-right"></i> Open delivery</div>
        </div>
      </div>`;
  }
  if (showShop && !mpShop) {
    html += `
      <div class="dash-cta-grid" style="grid-template-columns:1fr;gap:var(--s3);margin-bottom:var(--s4)">
        <div class="cta-card shop-cta" onclick="switchPanel('shop');mpLoadShopProducts();mpLoadShopFeedback()">
          <div class="cta-icon" style="background:linear-gradient(135deg,#E2B65C 0%,#C7993A 100%);"><i class="fa-solid fa-store"></i></div>
          <div>
            <div class="cta-title">Open Your Shop</div>
            <div class="cta-desc">Your seller account is approved. Start listing products and reach buyers across the marketplace.</div>
          </div>
          <div class="cta-arrow gold"><i class="fa-solid fa-arrow-right"></i> Open shop</div>
        </div>
      </div>`;
  }
  if (!html && (kycPending || kycNone)) {
    html = `
      <div class="section-card" style="padding:var(--s4);margin-bottom:var(--s4);background:rgba(14,30,22,.04)">
        <div class="section-header" style="margin-bottom:var(--s3)">
          <div class="section-header-icon gold"><i class="fa-solid fa-id-card"></i></div>
          <div class="section-header-title">KYC Required</div>
        </div>
        <div class="section-body" style="padding:0;">
          <p style="margin-bottom:var(--s3);color:var(--c-text3)">Choose your role and submit KYC to unlock seller or delivery features. You can manage everything from the profile section.</p>
          <button class="btn-primary" type="button" onclick="switchPanel('profile');mpGenerateCaptcha()">Complete KYC</button>
        </div>
      </div>`;
  }
  container.innerHTML = html;
  container.style.display = html ? '' : 'none';
}

function updateShopUI() {
  const createForm = document.getElementById('shopCreateForm');
  const manageArea = document.getElementById('shopManageArea');
  const hasShop = !!(mpShop && mpShop.shop_id);
  if (createForm) createForm.style.display = (mpKycStatus === 'approved' && !hasShop) ? '' : 'none';
  if (manageArea) manageArea.style.display = hasShop ? '' : 'none';
}

function updateKycUI(data) {
  const badge = document.getElementById('kycStatusBadge');
  if (badge) {
    const st = data.kyc?.status || 'none';
    badge.textContent = st === 'none' ? 'Not submitted' : st.replace('_', ' ');
    badge.className = 'kyc-badge kyc-' + st;
  }
  const reason = document.getElementById('kycRejectReason');
  if (reason && data.kyc?.rejection_reason) {
    reason.textContent = data.kyc.rejection_reason;
    reason.style.display = '';
  }
}

// The catalogue search bar (.catalogue-search-sticky, right after
// #tradeBannerSlot in the DOM) should only be position:sticky when there's
// an ad banner above it to scroll behind — otherwise it stays static.
// Call this any time tradeBannerSlot's visibility/content changes.
function mpSyncSearchStickyState() {
  const banner = document.getElementById('tradeBannerSlot');
  const searchBar = document.querySelector('.catalogue-search-sticky');
  if (!searchBar) return;
  const hasAd = !!banner && !banner.hidden && banner.innerHTML.trim() !== '';
  searchBar.classList.toggle('banner-active', hasAd);
}

function mpRenderBanner(ad, targetId) {
  const banner = document.getElementById(targetId || 'dashBannerSlot');
  if (!banner || !ad || !ad.image_url) return false;
  const link = ad.link_url && ad.link_url !== '#' ? ad.link_url : '';
  const imgUrl = ad.image_url + (ad.image_url.includes('?') ? '&' : '?') + 't=' + Date.now();
  const alt = ad.alt_text || 'Advertisement';
  const sponsoredChip = link ? '<div class="dash-banner-sponsored-chip"><i class="fa-solid fa-star"></i> Sponsored</div>' : '';
  // Plain rounded box, no decorative SVG wave edges — height follows the
  // image's natural aspect ratio (see .dash-banner-rounded img in CSS).
  const media = ad.media_type === 'video'
    ? '<video autoplay muted loop playsinline poster="" aria-label="' + alt.replace(/"/g, '') + '" onerror="console.error(\'[Ad] media failed to load:\', this.currentSrc || this.src); this.style.display=\'none\';this.parentElement.classList.add(\'banner-media-failed\')"><source src="' + imgUrl + '">Your browser cannot play this video.</video>'
    : '<img src="' + imgUrl + '" alt="' + alt.replace(/"/g, '') + '" onerror="console.error(\'[Ad] media failed to load:\', this.src); this.style.display=\'none\';this.parentElement.classList.add(\'banner-media-failed\')">';
  const inner =
    '<div class="dash-banner-img-wrap" style="position:relative">' +
      sponsoredChip +
      media + '<div class="banner-media-fallback">' + alt + '</div>' +
    '</div>';
  banner.hidden = false;
  banner.className = (targetId === 'tradeBannerSlot' ? 'trade-banner' : 'dash-banner portal-bleed dash-banner-rounded');
  banner.innerHTML = link
    ? '<a href="' + link + '" target="_blank" rel="noopener sponsored">' + inner + '</a>'
    : inner;
  mpSyncSearchStickyState();
  return true;
}

async function mpLoadBanner(placement, targetId) {
  placement = placement || 'dashboard';
  targetId = targetId || 'dashBannerSlot';
  const banner = document.getElementById(targetId);
  if (!banner) return;

  try {
    const res = await fetch(LAMBDA_URL + '/banner/active?placement=' + encodeURIComponent(placement) + '&t=' + Date.now(), {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    const text = await res.text();
    if (text.charAt(0) === '{') {
      const data = JSON.parse(text);
      if (data.ad && data.ad.image_url) {
        localStorage.setItem('ax_active_banner_' + placement, JSON.stringify(data.ad));
        if (mpRenderBanner(data.ad, targetId)) return;
      }
    }
  } catch (e) {
    console.warn('[Ad] API load failed', e);
  }

  try {
    const cached = JSON.parse(localStorage.getItem('ax_active_banner_' + placement) || 'null');
    if (cached && mpRenderBanner(cached, targetId)) return;
  } catch (e) { /* ignore */ }

  if (placement === 'dashboard') {
    banner.innerHTML = '<div class="dash-banner-default"><div class="dash-banner-eyebrow"><i class="fa-solid fa-leaf"></i> Aarvex Global</div><h3>Premium Agri Exports</h3><p>Your trusted partner in global agricultural trade</p><button type="button" class="dash-banner-cta-btn" onclick="switchPanel(\'trade\'); switchTradeMode(\'order\')"><i class="fa-solid fa-arrow-right"></i> Browse Products</button></div>';
    banner.className = 'dash-banner portal-bleed dash-banner-rounded';
  } else banner.hidden = true;
  mpSyncSearchStickyState();
}

async function mpLoadNotifications() {
  const data = await mpApi('/notifications');
  mpNotifUnread = data.unread || 0;
  const badgeIds = ['notifBadge', 'notifBadgeMobile', 'notifBadgeDesktop', 'notifBadgeAlert', 'navNotifBadge'];
  badgeIds.forEach(id => {
    const badge = document.getElementById(id);
    if (badge) {
      badge.textContent = mpNotifUnread > 99 ? '99+' : mpNotifUnread;
      badge.style.display = mpNotifUnread > 0 ? '' : 'none';
    }
  });
  if (typeof PortalEnhancements !== 'undefined' && PortalEnhancements.updateBadges) {
    PortalEnhancements.updateBadges(mpNotifUnread);
  }
  const list = document.getElementById('notificationsList');
  if (!list) return;
  const items = data.notifications || [];
  if (!items.length) {
    list.innerHTML = '<p style="padding:24px;color:var(--c-text3);text-align:center">No notifications yet.</p>';
    return;
  }
  const icons = { new_lead: 'fa-wheat-awn', new_review: 'fa-star', kyc_update: 'fa-id-card', admin_message: 'fa-envelope', shop_status: 'fa-store', delivery_otp: 'fa-key' };
  list.innerHTML = items.map(n => {
    const isLead = n.type === 'new_lead' && (n.ticket_id || n.reference_id);
    const dealBtns = isLead && mpKycStatus === 'approved' ? `
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button type="button" class="btn-primary btn-sm" onclick="mpShowDealPaymentModal('${n.ticket_id || n.reference_id}','online')"><i class="fa-solid fa-credit-card"></i> Finalize — Online</button>
        <button type="button" class="btn-sm-outline" onclick="mpShowDealPaymentModal('${n.ticket_id || n.reference_id}','cod')"><i class="fa-solid fa-money-bill"></i> Finalize — COD</button>
      </div>` : '';
    // Section 0 #4 fix: the templated card (icon + primary line + up to two
    // supporting facts + "View details") replaces the old raw n.body dump —
    // see CatalogueUI.notificationItemHtml in catalogue-ui.js for why.
    const itemHtml = typeof CatalogueUI !== 'undefined'
      ? CatalogueUI.notificationItemHtml(n, { showMarkRead: true, markReadFn: 'mpMarkRead', showDelete: true })
      : `<div class="notif-item${n.is_read ? '' : ' unread'}"><div class="notif-icon"><i class="fa-solid ${icons[n.type] || 'fa-bell'}"></i></div><div style="flex:1"><div class="notif-title">${n.title || ''}</div><div class="notif-body" style="white-space:pre-line">${n.body || ''}</div></div></div>`;
    if (!dealBtns) return itemHtml;
    // Deal-finalize buttons stay appended after the templated body (they're
    // an action, not descriptive text, so they don't belong inside the
    // template itself).
    return itemHtml.replace('</div></div>', dealBtns + '</div></div>');
  }).join('');
}

async function mpMarkRead(id) {
  await mpApi('/notifications/read', { method: 'POST', body: JSON.stringify({ notification_id: id }) });
  mpLoadNotifications();
}

async function mpMarkAllRead() {
  await mpApi('/notifications/read', { method: 'POST', body: JSON.stringify({ mark_all: true }) });
  mpLoadNotifications();
}

/* Bulk-remove every already-read notification (unread ones stay). */
async function mpClearReadNotifications() {
  if (!confirm('Remove all read notifications? Unread ones will stay.')) return;
  const data = await mpApi('/notifications/delete', { method: 'POST', body: JSON.stringify({ delete_all_read: true }) });
  if (data && data.success) {
    showToast((data.deleted || 0) + ' notification' + (data.deleted === 1 ? '' : 's') + ' removed', 'success');
    mpLoadNotifications();
  } else showToast((data && data.error) || 'Could not clear notifications', 'error');
}

/* Delete one notification — the card slides out optimistically, then the
   list refreshes from the server (and slides back on failure). */
async function mpDeleteNotification(nid, btn) {
  const card = btn && btn.closest('.notif-item');
  if (card) {
    card.style.transition = 'opacity .25s ease, transform .25s ease';
    card.style.opacity = '0';
    card.style.transform = 'translateX(16px)';
  }
  const data = await mpApi('/notifications/delete', { method: 'POST', body: JSON.stringify({ notification_id: nid }) });
  if (data && data.success) {
    showToast('Notification deleted', 'info');
    mpLoadNotifications();
    if (typeof PortalEnhancements !== 'undefined') PortalEnhancements.refreshNotifications(true);
  } else {
    if (card) { card.style.opacity = '1'; card.style.transform = 'none'; }
    showToast((data && data.error) || 'Could not delete notification', 'error');
  }
}

function toggleProfileDropdown() {
  document.getElementById('profileDropdown')?.classList.toggle('open');
}

document.addEventListener('click', e => {
  const dd = document.getElementById('profileDropdown');
  const btn = document.getElementById('navProfileBtn');
  if (dd && btn && !dd.contains(e.target) && !btn.contains(e.target)) dd.classList.remove('open');
});

function mpShowKycSection() {
  toggleProfileDropdown();
  switchPanel('profile');
  resetRecaptchaWidget('kycRecaptcha');
  document.getElementById('kycSection')?.scrollIntoView({ behavior: 'smooth' });
}

function mpGenerateCaptcha() {
  resetRecaptchaWidget('kycRecaptcha');
}

function updateKycFileLabel(inputId) {
  const input = document.getElementById(inputId);
  const label = document.getElementById(inputId + 'Name');
  if (!input || !label) return;
  label.textContent = input.files && input.files[0] ? input.files[0].name : 'No file selected';
}

async function mpSubmitKyc() {
  if (!localStorage.getItem('ax_google_token')) {
    showToast('KYC requires Google sign-in', 'warning'); return;
  }
  const recaptchaToken = typeof getRecaptchaToken === 'function'
    ? getRecaptchaToken('kycRecaptcha')
    : '';
  if (!recaptchaToken) { showToast('Please complete the captcha verification', 'error'); return; }
  if (!document.getElementById('kycDeclare')?.checked) { showToast('Please accept declaration', 'error'); return; }

  const toB64 = (inputId) => new Promise((resolve) => {
    const f = document.getElementById(inputId)?.files?.[0];
    if (!f) { resolve(''); return; }
    if (f.size > 2 * 1024 * 1024) { showToast('File max 2MB', 'error'); resolve(''); return; }
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.readAsDataURL(f);
  });

  const [front, back, sig] = await Promise.all([
    toB64('kycAadhaarFront'), toB64('kycAadhaarBack'), toB64('kycSignature')
  ]);
  if (!front || !back || !sig) { showToast('Upload all KYC documents', 'error'); return; }

  const fullName = document.getElementById('kycFullName')?.value.trim() || currentUser?.name || '';
  const aadhaar = (document.getElementById('kycAadhaar')?.value || '').replace(/\D/g, '');
  const pan = (document.getElementById('kycPan')?.value || '').trim().toUpperCase();
  const ifsc = (document.getElementById('kycBankIfsc')?.value || '').trim().toUpperCase();
  const bankAccount = (document.getElementById('kycBankAccount')?.value || '').trim();
  if (!fullName) { showToast('Please enter your full legal name', 'error'); return; }
  if (aadhaar.length !== 12) { showToast('Aadhaar number must be 12 digits', 'error'); return; }
  if (pan && pan.length !== 10) { showToast('PAN must be 10 characters', 'error'); return; }
  if (!bankAccount) { showToast('Please enter your account number', 'error'); return; }
  if (!ifsc || ifsc.length !== 11) { showToast('IFSC code must be 11 characters', 'error'); return; }

  const payload = {
    full_name: fullName,
    aadhaar_number: aadhaar,
    pan_number: pan,
    kyc_role: document.querySelector('input[name="kycRole"]:checked')?.value || 'shop_owner',
    bank_account_holder: document.getElementById('kycBankHolder')?.value || '',
    bank_name: document.getElementById('kycBankName')?.value || '',
    bank_account_number: bankAccount,
    bank_ifsc: ifsc,
    bank_branch: document.getElementById('kycBankBranch')?.value || '',
    aadhaar_front_b64: front, aadhaar_back_b64: back, signature_b64: sig,
    declaration_accepted: true,
    recaptcha_token: recaptchaToken,
  };
  const data = await mpApi('/kyc/submit', { method: 'POST', body: JSON.stringify(payload) });
  if (data.success) {
    showToast('KYC submitted — under review', 'success');
    resetRecaptchaWidget('kycRecaptcha');
    mpLoadKycStatus();
  } else {
    showToast(data.error || 'KYC submit failed', 'error');
    resetRecaptchaWidget('kycRecaptcha');
  }
}

async function mpCreateShop() {
  const shopName = document.getElementById('shopName')?.value.trim() || '';
  if (!shopName) { showToast('Please enter a shop name', 'error'); return; }
  const payload = {
    shop_name: shopName,
    shop_description: document.getElementById('shopDesc')?.value || '',
    shop_category: document.getElementById('shopCategory')?.value || 'Other',
    address_city: document.getElementById('shopCity')?.value || '',
    address_state: document.getElementById('shopState')?.value || '',
    address_pincode: document.getElementById('shopPin')?.value || '',
    gst_number: document.getElementById('shopGst')?.value || '',
    terms_accepted: document.getElementById('shopTerms')?.checked,
  };
  const data = await mpApi('/shop/create', { method: 'POST', body: JSON.stringify(payload) });
  if (data.success) {
    showToast('Shop created: ' + data.shop_name, 'success');
    mpShop = { shop_id: data.shop_id || data.shop_name };
    mpLoadKycStatus();
    mpLoadShopProducts();
  } else showToast(data.error || 'Shop creation failed', 'error');
}

async function mpToggleShop() {
  const data = await mpApi('/shop/toggle', { method: 'POST', body: '{}' });
  if (data.success) { showToast('Shop ' + data.status, 'success'); mpLoadShopProducts(); }
}

async function mpLoadShopFeedback() {
  const data = await mpApi('/shop/feedback');
  const list = document.getElementById('shopFeedbackList');
  if (!list) return;
  const items = data.feedback || [];
  if (!items.length) {
    list.innerHTML = '<p style="color:var(--c-text3);font-size:13px;padding:12px 0">No private feedback yet.</p>';
    return;
  }
  list.innerHTML = items.map(f => `
    <div class="notif-item${f.is_read ? '' : ' unread'}" style="margin-bottom:8px">
      <div class="notif-icon"><i class="fa-solid fa-comment-dots"></i></div>
      <div><div class="notif-title">${f.from_name || 'Customer'}</div>
      <div class="notif-body">${f.message || ''}</div>
      <div class="notif-time">${(f.created_at||'').slice(0,16).replace('T',' ')}</div></div>
    </div>`).join('');
}

async function mpShowDealPaymentModal(ticketId, paymentMode) {
  if (!ticketId) { showToast('Invalid listing reference', 'error'); return; }
  const data = await mpApi('/listing/deal/preview', {
    method: 'POST',
    body: JSON.stringify({ ticket_id: ticketId, delivery_pincode: document.getElementById('p_pincode')?.value || '' }),
  });
  if (!data.breakdown) { showToast(data.error || 'Could not load payment details', 'error'); return; }
  const b = data.breakdown;
  const modal = document.getElementById('dealPaymentModal');
  const body = document.getElementById('dealPaymentBody');
  if (!modal || !body) { mpFinalizeListingDeal(ticketId, paymentMode, b); return; }
  body.innerHTML =
    '<div class="payment-breakdown">' +
    '<div class="pb-row"><span>Lot Price</span><strong>₹' + b.lot_price + '</strong></div>' +
    '<div class="pb-row"><span>Delivery (~' + b.distance_km + ' km)</span><strong>₹' + b.delivery_charge + '</strong></div>' +
    '<div class="pb-row"><span>Platform Fee (' + b.platform_fee_pct + '%)</span><strong>₹' + b.platform_fee + '</strong></div>' +
    '<div class="pb-row pb-sub"><span>Subtotal</span><strong>₹' + b.subtotal + '</strong></div>' +
    '<div class="pb-row pb-gst"><span>GST @ ' + b.gst_rate_pct + '%</span><strong>+ ₹' + b.gst_amount + '</strong></div>' +
    '<div class="pb-row pb-total"><span>Total Payable</span><strong>₹' + b.total + '</strong></div>' +
    '<p class="pb-note"><i class="fa-solid fa-circle-info"></i> GST is shown separately as required for invoicing. Platform service rate is ' + b.platform_fee_pct + '%.</p>' +
    '</div>';
  modal.dataset.ticketId = ticketId;
  modal.dataset.paymentMode = paymentMode;
  modal.classList.add('open');
}

function mpCloseDealPaymentModal() {
  document.getElementById('dealPaymentModal')?.classList.remove('open');
}

async function mpConfirmDealPayment() {
  const modal = document.getElementById('dealPaymentModal');
  if (!modal) return;
  await mpFinalizeListingDeal(modal.dataset.ticketId, modal.dataset.paymentMode);
  mpCloseDealPaymentModal();
}

async function mpFinalizeListingDeal(ticketId, paymentMode, previewBreakdown) {
  if (!ticketId) { showToast('Invalid listing reference', 'error'); return; }
  if (!previewBreakdown && !confirm('Finalize this deal with payment breakdown?')) return;
  const data = await mpApi('/listing/deal', {
    method: 'POST',
    body: JSON.stringify({
      ticket_id: ticketId,
      payment_mode: paymentMode || 'online',
      delivery_pincode: document.getElementById('p_pincode')?.value || '',
    }),
  });
  if (data.success) {
    let msg = 'Deal finalized! Order ID: ' + data.arn;
    if (data.breakdown) msg += ' · Total ₹' + data.breakdown.total + ' (GST ₹' + data.breakdown.gst_amount + ')';
    showToast(msg, 'success');
    if (data.payment_link_url && paymentMode === 'online') window.open(data.payment_link_url, '_blank');
    mpLoadNotifications();
  } else showToast(data.error || 'Deal could not be finalized', 'error');
}

/* ── My Shop helpers ──────────────────────────────────────────────── */
function escS(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
/* wa.me deep link with a ready-made intro message — 10-digit numbers get
   the +91 country code (Indian marketplace default). */
function axWaLink(phone, msg) {
  let d = String(phone || '').replace(/\D/g, '');
  if (d.length === 10) d = '91' + d;
  return 'https://wa.me/' + d + (msg ? '?text=' + encodeURIComponent(msg) : '');
}
/* One person-row inside a claim card: role + name on the left, the three
   contact actions (Call / SMS / WhatsApp-with-prefilled-message) on the
   right. */
function axContactRow(role, icon, name, phone, waMsg) {
  return '<div class="shop-claim-row">' +
    '<div class="sc-who"><i class="fa-solid ' + icon + '"></i><div><span>' + escS(role) + '</span><b>' + escS(name || '—') + '</b></div></div>' +
    (phone
      ? '<div class="sc-actions">' +
        '<a class="sc-btn sc-call" href="tel:' + escS(phone) + '" title="Call ' + escS(name || '') + '" aria-label="Call"><i class="fa-solid fa-phone"></i></a>' +
        '<a class="sc-btn sc-sms" href="sms:' + escS(phone) + '" title="Message" aria-label="SMS"><i class="fa-solid fa-comment-dots"></i></a>' +
        '<a class="sc-btn sc-wa" href="' + axWaLink(phone, waMsg) + '" target="_blank" rel="noopener" title="WhatsApp" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>' +
        '</div>'
      : '')
    + '</div>';
}

async function mpLoadShopProducts() {
  const data = await mpApi('/shop/products');
  mpProducts = data.products || [];
  const header = document.getElementById('shopHeader');
  const shopId = data.shop || mpShop?.shop_id;
  const shopName = (mpShop && mpShop.shop_name) || shopId || 'My Shop';
  if (header && shopId) {
    const status = mpShop?.status || 'active';
    header.innerHTML =
      '<h3>' + escS(shopName) + '</h3>' +
      '<p class="shop-hero-meta">' +
        '<button type="button" class="shop-id-chip" onclick="axCopyText(\'' + escS(shopId) + '\', this)" title="Copy shop ID"><i class="fa-regular fa-copy"></i> ' + escS(shopId) + '</button>' +
        '<span class="shop-hero-dot">·</span><span>' + mpProducts.length + ' products</span>' +
        '<span class="shop-hero-dot">·</span><span class="kyc-badge kyc-' + (status === 'active' ? 'approved' : 'pending') + '">' + escS(status) + '</span>' +
      '</p>';
  }
  const grid = document.getElementById('shopProductsList');
  if (!grid) return;
  if (!shopId) {
    grid.innerHTML = document.getElementById('shopCreateForm') ? '' : '<p>Create shop after KYC approval.</p>';
    return;
  }
  grid.innerHTML = mpProducts.length ? mpProducts.map(p => {
    const lotLabel = p.lot_size_kg ? `Lot ${p.lot_size_kg} kg — ₹${p.lot_price || (p.lot_size_kg * p.price_per_kg)}` : `₹${p.price_per_kg}/kg`;
    // Fully reserved: a delivery partner has claimed the WHOLE lot, so it's
    // hidden from the public catalogue (lot_status="reserved") but kept
    // visible here so the seller can see who claimed it and track it until
    // delivery completes. It's removed automatically once that delivery is
    // finalized — see platform_utils.finalize_product_reservation(), called
    // from delivery.handle_delivery_complete() once the OTP is verified.
    const isFullyReserved = p.lot_status === 'reserved' || p.lot_status === 'sold';
    const paused = !!p.is_paused;
    const statusChip = isFullyReserved
      ? '<span class="sp-chip sp-sold"><i class="fa-solid fa-truck-fast"></i> Out for delivery</span>'
      : paused
        ? '<span class="sp-chip sp-paused"><i class="fa-solid fa-pause"></i> Paused</span>'
        : '<span class="sp-chip sp-live"><i class="fa-solid fa-circle"></i> Live</span>';
    // claimed_orders: attached by the backend (handle_shop_products_list)
    // for BOTH the full-lot case above AND partial (quarter/half) claims —
    // a partial claim leaves the listing itself active with reduced
    // available_stock_kg, but still surfaces buyer + delivery-partner
    // contact for that claimed portion here.
    const claims = p.claimed_orders || [];
    const claimStatusLabel = { DELIVERY_ASSIGNED: 'Claimed', IN_TRANSIT: 'Out for delivery', NEAR_DESTINATION: 'Arriving soon' };
    const claimedInfoHtml = claims.length ? claims.map(function (c) {
      const label = claimStatusLabel[c.status] || c.status || 'Claimed';
      const waIntroBuyer = 'Namaste ' + (c.buyer_name || '') + '! Main ' + shopName + ' (Aarvex Global) se aapke order ' + (c.arn || '') + ' — ' + (p.product_name || '') + ' — ke baare mein sampark kar raha/rahi hun.';
      const waIntroPartner = 'Namaste ' + (c.delivery_partner_name || '') + '! ' + shopName + ' (Aarvex Global) se — order ' + (c.arn || '') + ' (' + (p.product_name || '') + ') ki delivery ke baare mein.';
      return '<div class="shop-claim-card">' +
        '<div class="shop-claim-head">' +
          '<span class="sp-chip sp-transit">' + escS(label) + '</span>' +
          (c.reserved_kg ? '<span class="sc-kg">' + escS(c.reserved_kg) + ' kg</span>' : '') +
          (c.arn ? '<button type="button" class="sc-arn" onclick="axCopyText(\'' + escS(c.arn) + '\', this)" title="Copy order ID"><i class="fa-regular fa-copy"></i> ' + escS(c.arn) + '</button>' : '') +
        '</div>' +
        axContactRow('Buyer', 'fa-user', c.buyer_name || 'Buyer', c.buyer_mobile, waIntroBuyer) +
        axContactRow('Delivery partner', 'fa-truck-fast', c.delivery_partner_name, c.delivery_partner_mobile, waIntroPartner) +
      '</div>';
    }).join('') + (isFullyReserved ? '<div class="sp-autonote">Removed automatically once delivery completes.</div>' : '') : '';
    const actions = isFullyReserved
      ? '' // no Pause/Delete while a confirmed buyer + delivery partner is waiting on this lot
      : '<div class="sp-actions">' +
          '<button type="button" class="sp-btn" onclick="mpToggleProductPause(\'' + p.product_id + '\',\'' + p.category_id + '\',' + (!paused) + ')"><i class="fa-solid fa-' + (paused ? 'play' : 'pause') + '"></i> ' + (paused ? 'Activate' : 'Pause') + '</button>' +
          '<button type="button" class="sp-btn sp-danger" onclick="mpDeleteProduct(\'' + p.product_id + '\',\'' + p.category_id + '\')"><i class="fa-regular fa-trash-can"></i> Delete</button>' +
        '</div>';
    const media = p.image_url
      ? '<img class="sp-img" src="' + escS(p.image_url) + '" alt="" loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'"><div class="sp-img sp-img-ph" style="display:none"><i class="fa-solid fa-box-open"></i></div>'
      : '<div class="sp-img sp-img-ph"><i class="fa-solid fa-box-open"></i></div>';
    return '<div class="shop-prod-card' + (isFullyReserved ? ' is-sold' : '') + '">' +
      '<div class="sp-media">' + media + statusChip + '</div>' +
      '<div class="sp-body">' +
        '<div class="sp-name">' + escS(p.product_name) + '</div>' +
        '<div class="sp-meta">' + escS(p.category_name || '') + ' · ' + escS(lotLabel) + '</div>' +
        claimedInfoHtml +
        actions +
      '</div>' +
    '</div>';
  }).join('') : (typeof CatalogueUI !== 'undefined'
    ? CatalogueUI.emptyStateHtml({ icon: 'fa-box-open', message: 'No products yet — tap Add Product to list your first lot.' })
    : '<p>No products yet. Add your first lot.</p>');
}

async function mpAddProduct() {
  const imgs = document.getElementById('prodImages');
  const b64s = [];
  if (imgs?.files) {
    for (const f of imgs.files) {
      if (b64s.length >= 3) break;
      const b64 = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
      b64s.push(b64);
    }
  }
  const lotSize = parseFloat(document.getElementById('prodLotSize')?.value || document.getElementById('prodMinQty')?.value || 0);
  const priceKg = parseFloat(document.getElementById('prodPrice')?.value || 0);
  const mrpKg = parseFloat(document.getElementById('prodMrp')?.value || 0);
  const payload = {
    product_name: document.getElementById('prodName')?.value,
    category_id: (document.getElementById('prodCategory')?.value || 'other').toLowerCase().replace(/ /g,'_'),
    category_name: document.getElementById('prodCategory')?.value,
    description: document.getElementById('prodDesc')?.value,
    price_per_kg: priceKg,
    mrp_price_per_kg: mrpKg || undefined,
    lot_size_kg: lotSize,
    images_b64: b64s,
  };
  const data = await mpApi('/shop/product/add', { method: 'POST', body: JSON.stringify(payload) });
  if (data.success) {
    showToast('Product added', 'success');
    document.getElementById('addProductModal')?.classList.remove('open');
    mpLoadShopProducts();
  } else showToast(data.error || 'Failed', 'error');
}

async function mpToggleProductPause(pid, cid, pause) {
  await mpApi('/shop/product/pause', { method: 'POST', body: JSON.stringify({ product_id: pid, category_id: cid, is_paused: pause }) });
  mpLoadShopProducts();
}

async function mpDeleteProduct(pid, cid) {
  if (!confirm('Delete this product?')) return;
  await mpApi('/shop/product/delete', { method: 'POST', body: JSON.stringify({ product_id: pid, category_id: cid }) });
  mpLoadShopProducts();
}

async function mpSaveProfile() {
  const payload = {
    name: document.getElementById('p_name')?.value,
    email: document.getElementById('p_email')?.value,
    mobile: document.getElementById('p_mobile')?.value,
    address: document.getElementById('p_address')?.value,
    city: document.getElementById('p_city')?.value,
    state: document.getElementById('p_state')?.value,
    pincode: document.getElementById('p_pincode')?.value,
    gender: document.getElementById('p_gender')?.value,
    company_name: document.getElementById('p_company')?.value,
    gst_number: document.getElementById('p_gst')?.value,
    account_status: document.getElementById('p_frozen')?.checked ? 'frozen' : 'active',
  };
  const data = await mpApi('/profile/update', { method: 'POST', body: JSON.stringify(payload) });
  if (data.success) showToast('Profile saved', 'success');
}

function mpShowGoogleKycBanner() {
  if (!currentUser || currentUser.provider === 'google') return;
  const kycSection = document.getElementById('kycSection');
  if (!kycSection || kycSection.querySelector('.google-required-banner')) return;
  const banner = document.createElement('div');
  banner.className = 'google-required-banner';
  banner.innerHTML = '<i class="fa-brands fa-google"></i><div><strong>Google sign-in required for KYC &amp; Shop</strong><br>Marketplace verification (KYC, shop creation, delivery partner) needs Google authentication for secure identity. Sign out and sign in with Google to unlock seller features.</div>';
  kycSection.insertBefore(banner, kycSection.firstChild);
}

function mpInitMarketplace() {
  if (!currentUser) return;
  const profileTrigger = document.querySelector('.profile-nav-trigger');
  if (profileTrigger && currentUser.name) {
    profileTrigger.dataset.initials = currentUser.name.split(/\s+/).filter(Boolean).slice(0, 2).map(function (part) { return part.charAt(0).toUpperCase(); }).join('');
    profileTrigger.classList.add('has-initials');
  }
  const dashboard = document.getElementById('panel-dashboard');
  const banner = document.getElementById('dashBannerSlot');
  const greeting = document.querySelector('.dash-hero');
  if (dashboard && banner && greeting) dashboard.insertBefore(banner, greeting);
  mpShowGoogleKycBanner();
  mpLoadKycStatus();
  mpLoadNotifications();
  mpLoadBanner();
  mpLoadBanner('trade', 'tradeBannerSlot');
  if (typeof syncFavourites === 'function') syncFavourites();
  mpLoadShopProducts();
  mpLoadShopFeedback();
  mpGenerateCaptcha();
  ['prodPrice', 'prodLotSize', 'prodMrp'].forEach(function (id) {
    document.getElementById(id)?.addEventListener('input', function () {
      const kg = parseFloat(document.getElementById('prodLotSize')?.value || 0);
      const rate = parseFloat(document.getElementById('prodPrice')?.value || 0);
      const mrp = parseFloat(document.getElementById('prodMrp')?.value || 0);
      const prev = document.getElementById('prodLotPreview');
      if (!prev) return;
      if (!kg || !rate) { prev.value = ''; return; }
      let text = '₹' + (kg * rate) + ' per lot';
      if (mrp > rate) {
        const pct = Math.round(((mrp - rate) / mrp) * 100);
        text += '  (MRP ₹' + (kg * mrp) + ' — ' + pct + '% off)';
      }
      prev.value = text;
    });
  });
  
  // Show cancel button if there's an active order
  if (mpCurrentOrderArn) {
    const cancelBtn = document.getElementById('orderCancelBtn');
    if (cancelBtn) cancelBtn.style.display = 'block';
  }
  
  const kycName = document.getElementById('kycFullName');
  if (kycName && currentUser.name) kycName.value = currentUser.name;
}

const _origOnSignedIn = typeof onSignedIn === 'function' ? onSignedIn : null;
onSignedIn = function() {
  if (_origOnSignedIn) _origOnSignedIn();
  setTimeout(mpInitMarketplace, 300);
  setTimeout(mpLoadBanner, 2000);
};

// Order cancellation function
async function cancelCurrentOrder() {
  if (!mpCurrentOrderArn) {
    showToast('No active order to cancel', 'error');
    return;
  }
  
  if (!confirm('Are you sure you want to cancel this order? The product will be returned to the public catalogue.')) {
    return;
  }
  
  const data = await mpApi('/order/cancel', { method: 'POST', body: JSON.stringify({ arn: mpCurrentOrderArn }) });
  if (data.success) {
    showToast('Order cancelled successfully', 'success');
    mpCurrentOrderArn = null;
    
    // Hide cancel button
    const cancelBtn = document.getElementById('orderCancelBtn');
    if (cancelBtn) cancelBtn.style.display = 'none';
    
    // Reload orders to reflect cancellation
    if (typeof mpLoadMyOrders === 'function') {
      mpLoadMyOrders();
    }
    
    // Reload catalogue to show the product as available again
    if (typeof loadCatalogue === 'function') {
      loadCatalogue();
    }
  } else {
    showToast(data.error || 'Cancellation failed', 'error');
  }
}

// Store current ARN when order is placed
const _origSubmitOrder = typeof submitOrder === 'function' ? submitOrder : null;
if (_origSubmitOrder) {
  submitOrder = async function() {
    const result = await _origSubmitOrder.apply(this, arguments);
    // Store the ARN if order was successful
    if (result && result.arn) {
      mpCurrentOrderArn = result.arn;
      const cancelBtn = document.getElementById('orderCancelBtn');
      if (cancelBtn) cancelBtn.style.display = 'block';
    }
    return result;
  };
}

const _origHandleGoogle = typeof handleGoogleCredential === 'function' ? handleGoogleCredential : null;
handleGoogleCredential = function(response) {
  localStorage.setItem('ax_google_token', response.credential);
  if (_origHandleGoogle) _origHandleGoogle(response);
};

const _origSwitchPanel = typeof switchPanel === 'function' ? switchPanel : null;
switchPanel = function(panelId) {
  if (_origSwitchPanel) _origSwitchPanel(panelId);
  if (panelId === 'notifications') mpLoadNotifications();
  if (panelId === 'shop') { mpLoadShopProducts(); mpLoadShopFeedback(); }
  if (panelId === 'dashboard') mpLoadBanner();
  if (panelId === 'trade') mpLoadBanner('trade', 'tradeBannerSlot');
};

document.addEventListener('DOMContentLoaded', function () {
  mpLoadBanner();
});
