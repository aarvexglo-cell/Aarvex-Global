/* Aarvex Portal — Order / Sell / Track / History flows
 * Extracted from portal.html's inline <script> (was lines 1382-2900).
 * Order placement (submitOrder), sell listing (submitSell), order tracking
 * (trackOrder), and local order-history rendering.
 * Depends on: portal-helpers.js (gv/sv/showToast) — load AFTER it.
 */

/* ── ORDER FLOW ── */
function selectProductForOrder(productJson) {
  let product;
  try { product = typeof productJson === 'string' ? JSON.parse(productJson.replace(/&quot;/g,'"').replace(/&#39;/g,"'")) : productJson; }
  catch(e) { showToast('Error selecting product', 'error'); return; }
  selectedProduct = product;
  const iconClass = getProductIcon(product);
  const priceTag = product.price_per_kg ? '₹'+product.price_per_kg+'/kg' : 'Price on request';
  document.getElementById('selectedProductCard').innerHTML =
    '<div class="selected-product-emoji"><i class="'+iconClass+'"></i></div>' +
    '<div style="flex:1;min-width:0">' +
      '<div class="selected-product-name">'+product.product_name+'</div>' +
      '<div class="selected-product-meta">'+(product.category_name||'')+' · Min '+(product.min_order_kg||1)+' kg · '+priceTag+'</div>' +
    '</div>' +
    '<button class="change-product-btn" onclick="backToCatalogue()"><i class="fa-solid fa-rotate"></i> Change</button>';
  // The whole order flow (orderStep1/2/3) lives inside #panel-trade →
  // Order mode. Buying from anywhere else (Favourites grid, a shop
  // profile modal, etc.) used to just toggle step2 visible INSIDE a
  // display:none panel — the click appeared to do nothing. Bring the
  // Trade panel + Order mode forward first; selectedProduct is already
  // set above, so switchTradeMode('order') won't reset us back to step 1.
  const tradePanelEl = document.getElementById('panel-trade');
  if (tradePanelEl && !tradePanelEl.classList.contains('active')) switchPanel('trade');
  const activeModeTab = document.querySelector('.trade-mode-tab.active');
  if (!activeModeTab || activeModeTab.dataset.mode !== 'order') switchTradeMode('order');
  document.getElementById('orderStep1').style.display = 'none';
  document.getElementById('orderStep2').style.display = '';
  document.getElementById('orderStep3').style.display = 'none';
  setOrderProgressStep(2);
  prefillForms();
  updateOrderSectionStatus('yourDetails');
  updateOrderSectionStatus('delivery');
  setOrderType('sample');
  refreshStockFractions();
  loadAddressBook();
  const editing = window._orderEditIndex != null;
  document.getElementById('orderUpdateBtn').style.display = editing ? '' : 'none';
  document.getElementById('orderExternalSection').style.display = editing ? 'none' : '';
  window.scrollTo({top:0,behavior:'smooth'});
}

function setOrderProgressStep(step) {
  const s1 = document.getElementById('orderProgressStep1');
  const s2 = document.getElementById('orderProgressStep2');
  if (s1) s1.classList.toggle('active', step === 1);
  if (s2) s2.classList.toggle('active', step === 2);
  if (s1) s1.classList.toggle('done', step === 2);
}
function backToCatalogue() {
  document.getElementById('orderStep1').style.display = '';
  document.getElementById('orderStep2').style.display = 'none';
  setOrderProgressStep(1);
  selectedProduct = null;
}

let orderPurchaseFraction = null; // 'quarter' | 'half' | 'full' — bulk orders only

function refreshStockFractions() {
  if (!selectedProduct) return;
  const stock = parseFloat(selectedProduct.available_stock_kg) || 0;
  const q = (stock * 0.25), h = (stock * 0.5), f = stock;
  document.getElementById('fracQuarterKg').textContent = q ? Math.round(q) + ' kg' : '—';
  document.getElementById('fracHalfKg').textContent = h ? Math.round(h) + ' kg' : '—';
  document.getElementById('fracFullKg').textContent = f ? Math.round(f) + ' kg (all remaining)' : '—';
  const note = document.getElementById('stockRemainingNote');
  if (note) {
    note.style.display = '';
    note.innerHTML = '<i class="fa-solid fa-boxes-stacked"></i> ' + (stock ? Math.round(stock) + ' kg currently in stock' : 'Out of stock');
  }
  orderPurchaseFraction = null;
  ['Quarter','Half','Full'].forEach(function (n) {
    document.getElementById('fracCard'+n).classList.remove('active');
  });
}

function setPurchaseFraction(frac) {
  orderPurchaseFraction = frac;
  ['quarter','half','full'].forEach(function (f) {
    const id = 'fracCard' + f.charAt(0).toUpperCase() + f.slice(1);
    document.getElementById(id).classList.toggle('active', f === frac);
  });
}

function setOrderType(type) {
  orderType = type;
  document.getElementById('typeCardSample').className = 'order-type-card sample' + (type==='sample'?' active':'');
  document.getElementById('typeCardBulk').className   = 'order-type-card bulk'   + (type==='bulk'?' active':'');
  document.getElementById('qtySampleBox').style.display = type === 'sample' ? '' : 'none';
  document.getElementById('qtyBulkBox').style.display   = type === 'bulk'   ? '' : 'none';
  if (type === 'bulk') refreshStockFractions();
}
let orderPaymentMethod = 'online';
function setPaymentMethod(method) {
  orderPaymentMethod = method;
  document.getElementById('payCardOnline').className = 'order-type-card sample' + (method==='online'?' active':'');
  document.getElementById('payCardCod').className     = 'order-type-card bulk'   + (method==='cod'?' active':'');
}

/* ── Your Details / Delivery Location collapse cards ──────────────────
   Both start collapsed regardless of state; the header just turns green
   ("already have this") or red ("still needed") based on whether the
   required fields / a picked address are present. Re-run on every input
   change so the header updates live while a red card is open and being
   filled in. */
function orderSectionEls(section) {
  const id = section === 'yourDetails' ? 'yourDetailsCard' : 'deliveryCard';
  return {
    card: document.getElementById(id),
    summary: document.getElementById(section === 'yourDetails' ? 'yourDetailsSummary' : 'deliverySummary'),
  };
}
function updateOrderSectionStatus(section) {
  const { card, summary } = orderSectionEls(section);
  if (!card) return false;
  let complete, text;
  if (section === 'yourDetails') {
    const name = gv('o_name').trim(), mobile = gv('o_mobile').trim(), email = gv('o_email').trim();
    complete = !!(name && mobile && email);
    text = complete ? (name + ' · ' + mobile) : 'Please fill your details';
  } else {
    const addr = typeof getSelectedAddress === 'function' ? getSelectedAddress() : null;
    complete = !!addr;
    text = complete ? ((addr.label || 'Address') + ' · ' + (addr.city || '')) : 'Please select or add an address';
  }
  card.classList.toggle('is-complete', complete);
  card.classList.toggle('is-incomplete', !complete);
  if (summary) summary.textContent = text;
  return complete;
}
function toggleOrderSection(section) {
  const { card } = orderSectionEls(section);
  if (card) card.classList.toggle('is-open');
}
/* Used by submitOrder() to draw attention to whichever card is still
   incomplete instead of only showing the generic error banner. */
function expandOrderSection(section) {
  const { card } = orderSectionEls(section);
  if (!card) return;
  card.classList.add('is-open');
  card.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function submitOrder() {
  const errBox = document.getElementById('orderError');
  errBox.classList.remove('show');
  if (!selectedProduct) { showToast('Please select a product first', 'error'); backToCatalogue(); return; }

  let qty = 0;
  if (orderType === 'bulk') {
    if (!orderPurchaseFraction) {
      document.getElementById('orderErrorMsg').textContent = 'Please choose Quarter, Half or Full quantity.';
      errBox.classList.add('show'); return;
    }
    const stock = parseFloat(selectedProduct.available_stock_kg) || 0;
    qty = orderPurchaseFraction === 'quarter' ? stock * 0.25 : orderPurchaseFraction === 'half' ? stock * 0.5 : stock;
  } else {
    qty = parseFloat(gv('o_qty')) || 0;
    if (qty > 5) {
      document.getElementById('orderErrorMsg').textContent = 'Sample orders are max 5 kg. Switch to Bulk for more.';
      errBox.classList.add('show'); return;
    }
  }
  const name    = gv('o_name').trim();
  const mobile  = gv('o_mobile').trim();
  const email   = gv('o_email').trim();
  const selectedAddr = typeof getSelectedAddress === 'function' ? getSelectedAddress() : null;
  const missing = [];
  if (!qty)     missing.push('Quantity');
  if (!name)    missing.push('Full Name');
  if (!mobile)  missing.push('Mobile');
  if (!email)   missing.push('Email');
  // company_name required by backend — auto-fill with name if blank
  const company = gv('o_company').trim() || (name + ' (Individual)');
  if (missing.length) {
    updateOrderSectionStatus('yourDetails');
    expandOrderSection('yourDetails');
    document.getElementById('orderErrorMsg').textContent = 'Please fill: ' + missing.join(', ');
    errBox.classList.add('show'); return;
  }
  if (!selectedAddr) {
    document.getElementById('addressBookError').style.display = '';
    updateOrderSectionStatus('delivery');
    expandOrderSection('delivery');
    document.getElementById('orderErrorMsg').textContent = 'Please select or add a delivery address.';
    errBox.classList.add('show'); return;
  }
  const recaptchaToken = getRecaptchaToken('orderRecaptcha');
  if (!recaptchaToken) {
    showToast('Please complete the captcha verification', 'error');
    return;
  }
  const payload = {
    product_id: selectedProduct.product_id || '',
    category_id: selectedProduct.category_id || '',
    product_name: selectedProduct.product_name || '',
    order_type: orderType, quantity_kg: qty,
    purchase_option: orderType === 'bulk' ? orderPurchaseFraction : '',
    payment_method: orderPaymentMethod,
    customer_name: name, company_name: company,
    mobile, email, gst_number: gv('o_gst').trim(),
    address_id: selectedAddr.address_id,
    country: gv('o_country').trim() || 'India',
    amount_inr: orderType === 'sample' ? 500 : (selectedProduct.price_per_kg ? Math.round(qty * parseFloat(selectedProduct.price_per_kg)) : 0),
    price_per_kg: selectedProduct.price_per_kg || 0,
    recaptcha_token: recaptchaToken,
  };
  if (window._orderEditIndex != null) {
    const existing = getOrderHistory()[window._orderEditIndex];
    if (existing && existing.arn) payload.existing_arn = existing.arn;
  }
  const btn = document.getElementById('orderSubmitBtn');
  btn.disabled = true; btn.innerHTML = '<div class="spinner"></div> Submitting…';
  try {
    const _authToken = localStorage.getItem('ax_google_token');
    const _headers = {'Content-Type':'application/json'};
    if (_authToken) _headers['Authorization'] = 'Bearer ' + _authToken;
    const res = await fetch(LAMBDA_URL + '/web/order', {
      method:'POST', headers: _headers, body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15000),
    });
    const data = typeof safeFetchJson === 'function' ? await safeFetchJson(res) : await res.json();
    if (res.ok && data.success) {
      document.getElementById('orderStep2').style.display = 'none';
      document.getElementById('orderStep3').style.display = '';
      const arnEl = document.getElementById('orderARN');
      const arnRow = document.getElementById('orderARNRow');
      const arn = data.arn || (window._orderEditIndex != null ? getOrderHistory()[window._orderEditIndex]?.arn : '');
      if (arn && arnEl) { arnEl.textContent = arn; if (arnRow) arnRow.style.display = ''; }
      // Compact what-you-ordered recap under the Order ID.
      const sumEl = document.getElementById('orderSuccessSummary');
      if (sumEl && selectedProduct) {
        sumEl.innerHTML =
          '<div class="ss-cell"><span>Product</span><b>' + (selectedProduct.product_name || '—') + '</b></div>' +
          '<div class="ss-cell"><span>Quantity</span><b>' + (Math.round(qty * 100) / 100) + ' kg · ' + (orderType === 'bulk' ? 'Bulk' : 'Sample') + '</b></div>' +
          '<div class="ss-cell"><span>Payment</span><b>' + (orderPaymentMethod === 'cod' ? 'Cash on Delivery' : 'Pay Online') + '</b></div>';
        sumEl.style.display = '';
      }
      if (window._orderEditIndex != null && data.updated) {
        updateOrderHistory(window._orderEditIndex, { product: selectedProduct.product_name, type: orderType, qty, status: 'Updated', date: getOrderHistory()[window._orderEditIndex]?.date || new Date().toISOString() });
        window._orderEditIndex = null;
        showToast('Order updated successfully', 'success');
      } else if (!data.updated) {
        saveOrderHistory({arn: data.arn, product: selectedProduct.product_name, type: orderType, qty, status: 'New', date: new Date().toISOString()});
        showToast('Order placed! Check WhatsApp for payment link.', 'success');
      }
    } else {
      document.getElementById('orderErrorMsg').textContent = data.error || 'Something went wrong. Please try again.';
      errBox.classList.add('show');
      resetRecaptchaWidget('orderRecaptcha');
    }
  } catch(e) {
    document.getElementById('orderErrorMsg').textContent = 'Network error. Check your connection and try again.';
    errBox.classList.add('show');
    resetRecaptchaWidget('orderRecaptcha');
  }
  btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Order Request';
}

function resetOrder() {
  selectedProduct = null; orderType = 'sample'; orderPurchaseFraction = null;
  document.getElementById('orderStep1').style.display = '';
  document.getElementById('orderStep2').style.display = 'none';
  document.getElementById('orderStep3').style.display = 'none';
  setOrderProgressStep(1);
  sv('o_qty', ''); setOrderType('sample');
}


/* ── SELL FLOW ── */
async function submitSell() {
  const errBox = document.getElementById('sellError');
  errBox.classList.remove('show');
  const name   = gv('s_name').trim();
  const mobile = gv('s_mobile').trim();
  const crop   = gv('s_crop').trim();
  const qty    = parseFloat(gv('s_qty')) || 0;
  const city   = gv('s_city').trim();
  const state  = gv('s_state').trim();
  const missing = [];
  if (!name)   missing.push('Name');
  if (!mobile) missing.push('Mobile');
  if (!crop)   missing.push('Crop');
  if (!qty)    missing.push('Quantity');
  if (!city)   missing.push('City');
  if (!state)  missing.push('State');
  if (missing.length) {
    document.getElementById('sellErrorMsg').textContent = 'Please fill: ' + missing.join(', ');
    errBox.classList.add('show'); return;
  }
  const recaptchaToken = getRecaptchaToken('sellRecaptcha');
  if (!recaptchaToken) {
    showToast('Please complete the captcha verification', 'error');
    return;
  }
  const payload = {
    contact_name: name, mobile,
    email: gv('s_email').trim() || undefined,
    crop, quantity_available_kg: qty,
    expected_price: gv('s_price').trim() || undefined,
    location_city: city, location_state: state,
    pincode: gv('s_pincode').trim() || undefined,
    recaptcha_token: recaptchaToken,
  };
  const btn = document.getElementById('sellSubmitBtn');
  btn.disabled = true; btn.innerHTML = '<div class="spinner" style="border-color:rgba(0,0,0,.2);border-top-color:var(--c-earth)"></div> Submitting…';
  try {
    const res = await fetch(LAMBDA_URL + '/web/sell', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15000),
    });
    const data = typeof safeFetchJson === 'function' ? await safeFetchJson(res) : await res.json();
    if (res.ok && data.success) {
      document.getElementById('sellFormWrapper').style.display = 'none';
      document.getElementById('sellSuccess').style.display = '';
      const refEl = document.getElementById('sellRefId');
      if (data.reference_id) { refEl.textContent = 'Reference ID: '+data.reference_id; refEl.style.display = ''; }
      saveSellHistory({
        crop, quantity_available_kg: qty, expected_price: gv('s_price').trim(),
        location_city: city, location_state: state,
        contact_name: name, mobile, reference_id: data.reference_id,
        status: 'Submitted'
      });
      updateStats();
      showToast('Listing submitted! Team will call within 24 hrs.', 'success');
    } else {
      document.getElementById('sellErrorMsg').textContent = data.error || 'Something went wrong. Please try again.';
      errBox.classList.add('show');
      resetRecaptchaWidget('sellRecaptcha');
    }
  } catch(e) {
    document.getElementById('sellErrorMsg').textContent = 'Network error. Check your connection.';
    errBox.classList.add('show');
    resetRecaptchaWidget('sellRecaptcha');
  }
  btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Listing';
}

function resetSell() {
  document.getElementById('sellFormWrapper').style.display = '';
  document.getElementById('sellSuccess').style.display = 'none';
  sv('s_crop',''); sv('s_qty',''); sv('s_price','');
}

/* ── TRACK ORDER ── */
async function trackOrder() {
  const arn = gv('trackARN').trim();
  if (!arn) { showToast('Please enter an Order ID', 'error'); return; }
  const btn = document.getElementById('trackBtn');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner dark"></span> Tracking…'; }
  const resultBox = document.getElementById('trackResult');
  const content = document.getElementById('trackResultContent');
  const mapWrap = document.getElementById('trackMapWrap');
  const timeline = document.getElementById('trackTimeline');
  const otpBanner = document.getElementById('trackOtpBanner');
  const otpVal = document.getElementById('trackOtpValue');
  try {
    const res = await fetch(LAMBDA_URL + '/track?arn=' + encodeURIComponent(arn), {
      headers: { Authorization: 'Bearer ' + (localStorage.getItem('ax_google_token') || ''), Accept: 'application/json' },
    });
    const data = typeof safeFetchJson === 'function' ? await safeFetchJson(res) : await res.json();
    if (data.error && res.status >= 400) throw new Error(data.error);
    const statusClass = {'PENDING_DELIVERY':'status-new','DELIVERY_ASSIGNED':'status-processing','IN_TRANSIT':'status-shipped','NEAR_DESTINATION':'status-shipped','COMPLETED':'status-delivered','Delivered':'status-delivered'}[data.status] || 'status-processing';
    content.innerHTML =
      '<div style="display:flex;align-items:center;gap:var(--s3);margin-bottom:var(--s3)">' +
        '<div style="width:48px;height:48px;border-radius:12px;background:var(--c-mist);display:grid;place-items:center;color:var(--c-leaf2);font-size:20px"><i class="fa-solid fa-box"></i></div>' +
        '<div style="flex:1"><div style="font-size:15px;font-weight:700">'+(data.product_name||'Order')+'</div>' +
        '<div style="font-size:12px;color:var(--c-text3)">'+arn+'</div></div>' +
        '<div class="status-pill '+statusClass+'">'+(data.status||'—')+'</div></div>';
    if (timeline && data.timeline) {
      mapWrap.style.display = '';
      timeline.innerHTML = data.timeline.map(function(s) {
        return '<div style="display:flex;align-items:center;gap:10px;padding:6px 0;font-size:13px;color:'+(s.done?'var(--c-leaf2)':'var(--c-text3)')+'">' +
          '<i class="fa-solid fa-'+(s.done?'circle-check':'circle')+'"></i> '+s.step+'</div>';
      }).join('');
    }
    if (data.your_otp && otpBanner && otpVal) {
      otpBanner.style.display = '';
      otpVal.textContent = data.your_otp;
    } else if (otpBanner) otpBanner.style.display = 'none';
    if (typeof PortalEnhancements !== 'undefined' && PortalEnhancements.renderTrackMap) {
      PortalEnhancements.renderTrackMap(data);
    }
    if (data.driver_location && data.driver_location.lat) {
      timeline.innerHTML += '<p style="font-size:12px;color:var(--c-text3);margin-top:8px"><i class="fa-solid fa-location-dot"></i> Driver location updated '+((data.driver_location.updated_at||'').slice(0,16).replace('T',' '))+'</p>';
    }
    resultBox.style.display = '';
  } catch (e) {
    const local = getOrderHistory().find(o => o.arn && o.arn.toLowerCase() === arn.toLowerCase());
    if (local) {
      const statusClass = {'new':'status-new','processing':'status-processing','shipped':'status-shipped','delivered':'status-delivered'}[(local.status||'new').toLowerCase()] || 'status-new';
      content.innerHTML = '<div class="status-pill '+statusClass+'">'+(local.status||'New')+'</div><p style="margin-top:8px">'+ (local.product||'') +'</p>';
      resultBox.style.display = '';
    } else {
      content.innerHTML = '<p style="color:var(--c-text3);text-align:center;padding:var(--s3)">'+(e.message||'Order not found')+'</p>';
      resultBox.style.display = '';
    }
  }
  if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i> Track Order'; }
}

/* ── ORDER HISTORY ── */
function orderHistoryKey() { return currentUser ? 'ax_orders_' + currentUser.sub : null; }
function getOrderHistory() {
  const key = orderHistoryKey(); if (!key) return [];
  try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch(e) { return []; }
}
function saveOrderHistory(order) {
  const key = orderHistoryKey(); if (!key) return;
  const hist = getOrderHistory(); hist.unshift(order);
  localStorage.setItem(key, JSON.stringify(hist.slice(0,50)));
  renderDashRecent(); updateStats();
}

function loadMyOrders() {
  if (typeof getUnifiedListings === 'function') { loadMyListings(); return; }
  const orders = getOrderHistory();
  const wrap = document.getElementById('myOrdersList');
  if (wrap) {
    wrap.innerHTML = orders.length
      ? orders.slice(0,30).map((o,i) => orderCardHtml(o,i)).join('')
      : '<div class="orders-empty"><div class="orders-empty-icon"><i class="fa-solid fa-box-open"></i></div><h4>No orders yet</h4><p>Your placed orders will appear here.<br><a onclick="switchPanel(\'order\')" style="color:var(--c-leaf2);font-weight:700;cursor:pointer">Place your first order →</a></p></div>';
  }
  renderDashRecent();
}

function renderDashRecent() {
  const orders = getOrderHistory().slice(0,3);
  const dash = document.getElementById('dashRecentOrders');
  if (!dash) return;
  dash.innerHTML = orders.length
    ? orders.map((o,i) => orderCardHtml(o,i)).join('')
    : '<div style="text-align:center;padding:var(--s5);color:var(--c-text3);font-size:13px"><div class="empty-icon-wrap" style="margin-bottom:var(--s2)"><i class="fa-solid fa-box-open"></i></div>No orders yet — <a onclick="switchPanel(\'order\')" style="color:var(--c-leaf2);font-weight:700;cursor:pointer">place your first order</a></div>';
}

function orderCardHtml(o, index) {
  index = index !== undefined ? index : 0;
  const statusKey = (o.status||'new').toLowerCase().replace(/\s/g,'_');
  const statusClass = {'new':'status-new','processing':'status-processing','shipped':'status-shipped','delivered':'status-delivered','payment_confirmed':'status-processing','pending':'status-pending','cancelled':'status-pending'}[statusKey] || 'status-new';
  const date = o.date ? new Date(o.date).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}) : '';
  const click = typeof openListingDetail === 'function' ? ' onclick="openListingDetail(\'order\','+index+')"' : '';
  return '<div class="order-card listing-card"'+click+' role="button" tabindex="0">' +
    '<div class="order-card-icon"><i class="fa-solid fa-box"></i></div>' +
    '<div style="flex:1;min-width:0">' +
      '<div class="order-card-name">'+(o.product||'—')+'</div>' +
      '<div class="order-card-meta">'+(o.type?o.type.charAt(0).toUpperCase()+o.type.slice(1):'')+' · '+(o.qty||'')+' kg · '+date+'</div>' +
      (o.arn?'<div class="order-card-arn">ARN: '+o.arn+'<button class="arn-copy-btn" onclick="event.stopPropagation();copyARN(\''+o.arn+'\')" title="Copy ARN"><i class="fa-regular fa-copy"></i></button></div>':'') +
    '</div>' +
    '<div class="status-pill '+statusClass+'">'+(o.status||'New')+'</div>' +
    '</div>';
}
