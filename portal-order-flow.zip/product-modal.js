/* Shared product detail modal — index.html (browse) & portal.html (buy) */
(function (global) {
  'use strict';

  var selectedProduct = null;
  var reviewRating = 0;
  var LISTING_MODIFY_MS = 30 * 60 * 1000;

  function esc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function starsHtml(rating, size) {
    var r = Math.round(parseFloat(rating) || 0);
    if (!r) {
      // §0-5: no reviews yet — an empty 5-star row reads as "rated zero".
      // Show a plain "New" label instead of grey stars.
      return '<span class="rating-count-new" style="font-size:' + (size || 14) + 'px;font-weight:700;color:var(--c-gold,#C7993A)">New</span>';
    }
    var out = '';
    for (var i = 1; i <= 5; i++) {
      out += '<i class="fa-solid fa-star' + (i <= r ? '' : '-half-stroke') + '" style="color:' + (i <= r ? '#C7993A' : '#D5C9B6') + ';font-size:' + (size || 14) + 'px"></i>';
    }
    return out;
  }

  function apiUrl(path) {
    return (global.LAMBDA_URL || '') + path;
  }

  async function safeApiJson(path) {
    var res = await fetch(apiUrl(path), { headers: { Accept: 'application/json' }, cache: 'no-store' });
    var text = await res.text();
    if (!text || text.trim().charAt(0) !== '{') {
      throw new Error('Server returned non-JSON (HTTP ' + res.status + '). Please deploy the latest Lambda code.');
    }
    return JSON.parse(text);
  }

  function getUser() {
    try { return JSON.parse(localStorage.getItem('ax_user') || 'null'); } catch (e) { return null; }
  }

  function toast(msg, type) {
    if (typeof global.showToast === 'function') global.showToast(msg, type || 'info');
    else if (typeof global.toast === 'function') global.toast(msg, type || 'success');
  }

  function renderStars(rating) {
    if (typeof global.renderStarRating === 'function') return global.renderStarRating(rating);
    return starsHtml(rating, 14);
  }

  function getProductIcon(p) {
    if (typeof global.getProductIcon === 'function') return global.getProductIcon(p);
    return 'fa-solid fa-seedling';
  }

  function truncateDesc(text, max) {
    if (typeof global.CatalogueUI !== 'undefined') return global.CatalogueUI.truncateDesc(text, max || 180);
    var t = (text || '').trim();
    if (t.length <= max) return t;
    return t.slice(0, max).replace(/\s+\S*$/, '') + '…';
  }

  function buildPriceHtml(product) {
    var disc = (typeof global.CatalogueUI !== 'undefined')
      ? global.CatalogueUI.priceDiscountInfo(product)
      : { show: false, mrpHtml: '', badgeHtml: '' };
    var usingLot = product.lot_size_kg && product.lot_price;
    var mainPrice = usingLot
      ? '₹' + product.lot_price + '<span> / lot (' + product.lot_size_kg + ' kg)</span>'
      : (product.price_per_kg ? '₹' + product.price_per_kg + '<span>/kg</span>' : '');
    if (!mainPrice) return '<div class="pd-modal-price pd-price-contact">Contact for price</div>';
    return '<div class="product-card-price-wrap"><div class="pd-modal-price">' + mainPrice + '</div>' + disc.mrpHtml + '</div>' + disc.badgeHtml;
  }

  function findProduct(productId, categoryId) {
    var list = global.catalogueProducts || global.catalogue || global.filteredCatalogue || [];
    return list.find(function (x) {
      return x.product_id === productId && (!categoryId || x.category_id === categoryId);
    });
  }

  function openById(productId, categoryId) {
    var p = findProduct(productId, categoryId);
    if (p) openModal(p);
  }

  function closeModal() {
    var el = document.getElementById('productDetailModal');
    if (el) el.classList.remove('open');
    selectedProduct = null;
    reviewRating = 0;
    if (_lastFocusedEl && typeof _lastFocusedEl.focus === 'function') _lastFocusedEl.focus();
    _lastFocusedEl = null;
  }

  function redirectToPortalOrder(product) {
    var q = 'product=' + encodeURIComponent(product.product_id || '') +
      '&category=' + encodeURIComponent(product.category_id || '') +
      '&action=order';
    window.location.href = 'portal.html?' + q;
  }

  function normalizeShopId(q) {
    var s = (q || '').trim().toUpperCase().replace(/\s+/g, '');
    if (/^\d{4,5}$/.test(s)) return 'SHOP-AX-' + s.replace(/^0+/, '').padStart(5, '0').slice(-5);
    var m = s.match(/^SHOP[-\s]?AX[-\s]?(\d+)/);
    if (m) return 'SHOP-AX-' + m[1].padStart(5, '0').slice(-5);
    return s;
  }

  function portalBuyProduct(product) {
    closeModal();
    if (typeof global.selectProductForOrder === 'function') {
      global.selectProductForOrder(product);
    }
  }

  function buildInfoHtml(product) {
    var hasImg = product.image_url && product.image_url.length > 10;
    var icon = getProductIcon(product);
    var desc = product.description || '';
    var shopLine = product.shop_id
      ? '<button type="button" class="shop-badge shop-badge-link" onclick="ProductModal.openShopProfile(\'' + esc(product.shop_id).replace(/'/g, "\\'") + '\')"><i class="fa-solid fa-store"></i> ' + esc(product.shop_name || 'Unnamed Shop') + '</button>'
      : (product.shop_name ? '<div class="shop-badge"><i class="fa-solid fa-store"></i> ' + esc(product.shop_name) + '</div>' : '');
    return (
      '<div class="pd-modal-hero">' +
        (hasImg
          ? '<img class="pd-modal-img" src="' + esc(product.image_url) + '" alt="' + esc(product.product_name) + '">'
          : '<div class="pd-modal-img-fallback"><i class="' + icon + '"></i></div>') +
      '</div>' +
      '<div class="pd-modal-info">' +
        '<div class="pd-modal-name">' + esc(product.product_name) + '</div>' +
        shopLine +
        '<div class="pd-modal-rating">' + renderStars(product.avg_rating) +
          (product.total_reviews ? ' <span class="pd-review-count">(' + product.total_reviews + ' reviews)</span>' : '') +
        '</div>' +
        '<div class="pd-modal-meta">' + esc(product.category_name || '') + ' · Min ' + (product.min_order_kg || 1) + ' kg · ' + esc(product.available_stock || 'In Stock') + '</div>' +
        (desc ? '<p class="pd-modal-desc" data-full="' + esc(desc) + '" onclick="ProductModal.toggleDesc(this)">' + esc(truncateDesc(desc, 180)) + (desc.length > 180 ? ' <span class="read-more-hint">Read more</span>' : '') + '</p>' : '') +
        buildPriceHtml(product) +
      '</div>'
    );
  }

  function toggleDesc(el) {
    if (!el) return;
    var full = el.getAttribute('data-full') || '';
    if (el.classList.contains('expanded')) {
      el.classList.remove('expanded');
      el.innerHTML = esc(truncateDesc(full, 180)) + ' <span class="read-more-hint">Read more</span>';
    } else {
      el.classList.add('expanded');
      el.innerHTML = esc(full) + ' <span class="read-more-hint">Show less</span>';
    }
  }

  async function loadShopReactions(shopId) {
    var wrap = document.getElementById('pdShopReactions');
    if (!wrap || !shopId) return;
    try {
      var data = await safeApiJson('/shop/public?shop_id=' + encodeURIComponent(shopId));
      var shop = data.shop || {};
      var likes = shop.likes || 0;
      var dislikes = shop.dislikes || 0;
      wrap.innerHTML =
        '<div class="pd-reaction-bar">' +
          '<button type="button" class="pd-react-btn like" onclick="ProductModal.reactShop(\'' + esc(shopId).replace(/'/g, "\\'") + '\',\'like\')"><i class="fa-solid fa-thumbs-up"></i> ' + likes + '</button>' +
          '<button type="button" class="pd-react-btn dislike" onclick="ProductModal.reactShop(\'' + esc(shopId).replace(/'/g, "\\'") + '\',\'dislike\')"><i class="fa-solid fa-thumbs-down"></i> ' + dislikes + '</button>' +
          '<span class="pd-react-hint">Public ratings — visible to everyone</span>' +
        '</div>';
    } catch (e) {
      wrap.innerHTML = '';
    }
  }

  async function reactShop(shopId, reaction) {
    var user = getUser();
    var token = localStorage.getItem('ax_google_token');
    if (!user) {
      toast('Sign in to rate shops', 'warning');
      setTimeout(function () { window.location.href = 'portal.html'; }, 1200);
      return;
    }
    try {
      var headers = { 'Content-Type': 'application/json' };
      if (token) headers.Authorization = 'Bearer ' + token;
      var res = await fetch(apiUrl('/shop/react'), {
        method: 'POST', headers: headers,
        body: JSON.stringify({ shop_id: shopId, reaction: reaction, user_sub: user.sub })
      });
      var data = await res.json();
      if (data.success) {
        // Update counts in both product modal and shop profile modal
        loadShopReactions(shopId);
        // Also refresh shop profile counts if open
        var likeEl = document.getElementById('shopLikeCount');
        var dislikeEl = document.getElementById('shopDislikeCount');
        if (likeEl && data.likes != null) likeEl.textContent = data.likes;
        if (dislikeEl && data.dislikes != null) dislikeEl.textContent = data.dislikes;
        toast(reaction === 'like' ? 'Thanks for your support! 👍' : 'Feedback noted 👎', 'success');
      } else toast(data.error || 'Could not save reaction', 'error');
    } catch (e) { toast('Network error', 'error'); }
  }

  async function loadReviews(product) {
    var listEl = document.getElementById('pdReviewsList');
    var formWrap = document.getElementById('pdReviewForm');
    if (!listEl) return;
    listEl.innerHTML = '<p class="pd-muted">Loading reviews…</p>';
    try {
      var res = await fetch(apiUrl('/reviews?product_id=' + encodeURIComponent(product.product_id)), { headers: { Accept: 'application/json' } });
      var text = await res.text();
      var data = text.charAt(0) === '{' ? JSON.parse(text) : { reviews: [] };
      var reviews = data.reviews || [];
      listEl.innerHTML = reviews.length
        ? reviews.map(function (r) {
          return '<div class="pd-review-item"><div class="pd-review-head">' + renderStars(r.rating) +
            ' <strong>' + esc(r.reviewer_name || 'Customer') + '</strong> · ' + esc((r.created_at || '').slice(0, 10)) +
            '</div><div class="pd-review-body">' + esc(r.comment || '') + '</div></div>';
        }).join('')
        : '<p class="pd-muted">No reviews yet. Be the first to share your experience.</p>';
    } catch (e) {
      listEl.innerHTML = '<p class="pd-muted">Reviews are temporarily unavailable.</p>';
    }

    if (!formWrap) return;
    var user = getUser();
    var token = localStorage.getItem('ax_google_token');
    if (user && token) {
      formWrap.innerHTML =
        '<div class="pd-review-form">' +
          '<strong>Write a Review</strong>' +
          '<div class="star-picker" id="pdReviewStars">' +
            [1, 2, 3, 4, 5].map(function (n) {
              return '<button type="button" data-v="' + n + '" onclick="ProductModal.setReviewStar(' + n + ')">★</button>';
            }).join('') +
          '</div>' +
          '<textarea id="pdReviewComment" class="form-input" rows="3" maxlength="300" placeholder="Share your experience with this product…"></textarea>' +
          '<button type="button" class="pd-btn-primary" onclick="ProductModal.submitReview()"><i class="fa-solid fa-paper-plane"></i> Submit Review</button>' +
        '</div>';
      reviewRating = 0;
    } else {
      formWrap.innerHTML =
        '<p class="pd-muted"><a href="portal.html" class="pd-link">Sign in with Google</a> to write a review.</p>';
    }
  }

  function setReviewStar(n) {
    reviewRating = n;
    document.querySelectorAll('#pdReviewStars button').forEach(function (btn, i) {
      btn.classList.toggle('on', i < n);
    });
  }

  async function submitReview() {
    if (!selectedProduct || !reviewRating) { toast('Please select a star rating', 'error'); return; }
    // If this page has the silent-refresh helper (portal.html) and the
    // stored token has expired, refresh it first instead of letting the
    // submit fail with "Unauthorized — valid Google token required" after
    // the person has already typed out their review.
    if (typeof window.ensureFreshGoogleToken === 'function') {
      try { await window.ensureFreshGoogleToken(); } catch (e) { /* fall through */ }
    }
    var token = localStorage.getItem('ax_google_token');
    if (!token) { toast('Sign in to submit a review', 'warning'); return; }
    var comment = (document.getElementById('pdReviewComment')?.value || '').trim();
    try {
      var res = await fetch(apiUrl('/review/submit'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({
          product_id: selectedProduct.product_id,
          category_id: selectedProduct.category_id,
          rating: reviewRating,
          comment: comment
        })
      });
      var data = await res.json();
      if (res.ok && data.success) {
        toast('Review submitted — thank you!', 'success');
        loadReviews(selectedProduct);
        if (typeof global.loadCatalogue === 'function') global.loadCatalogue();
      } else toast(data.error || 'Review could not be submitted', 'error');
    } catch (e) { toast('Network error', 'error'); }
  }

  function renderActions(product) {
    var wrap = document.getElementById('pdModalActions');
    if (!wrap) return;
    var mode = document.body.getAttribute('data-site-mode') || 'index';
    if (mode === 'portal') {
      wrap.innerHTML =
        '<button type="button" class="pd-btn-buy" onclick="ProductModal.buy()"><i class="fa-solid fa-bag-shopping"></i> Buy Now</button>';
    } else {
      wrap.innerHTML =
        '<button type="button" class="pd-btn-buy" onclick="ProductModal.orderViaPortal()" style="background:linear-gradient(135deg,#4EA86A,#2E6B41)">' +
          '<i class="fa-solid fa-cart-shopping"></i> Order This Product' +
        '</button>' +
        '<p class="pd-action-note" style="margin-top:10px">' +
          '<i class="fa-solid fa-lock"></i> Sign in on the portal, then complete the order form for this product.' +
        '</p>';
    }
  }

  function openModal(product) {
    selectedProduct = product;
    var modal = document.getElementById('productDetailModal');
    if (!modal) return;
    _lastFocusedEl = document.activeElement;
    document.getElementById('pdModalTitle').textContent = product.product_name || 'Product Details';
    document.getElementById('pdModalBody').innerHTML = buildInfoHtml(product);
    renderActions(product);
    modal.classList.add('open');
    var closeBtn = modal.querySelector('.pd-modal-close');
    if (closeBtn) closeBtn.focus();
    loadReviews(product);
    if (product.shop_id) loadShopReactions(product.shop_id);
    else {
      var react = document.getElementById('pdShopReactions');
      if (react) react.innerHTML = '';
    }
  }

  function orderViaPortal() {
    if (selectedProduct) redirectToPortalOrder(selectedProduct);
  }

  function buy() {
    if (selectedProduct) portalBuyProduct(selectedProduct);
  }

  async function openShopProfile(shopId) {
    shopId = normalizeShopId(shopId);
    var modal = document.getElementById('shopProfileModal');
    var body = document.getElementById('shopProfileBody');
    if (!modal || !body) return;
    _lastFocusedEl = document.activeElement;
    body.innerHTML = '<p class="pd-muted">Loading shop profile…</p>';
    modal.classList.add('open');
    var closeBtn = modal.querySelector('.pd-modal-close');
    if (closeBtn) closeBtn.focus();
    try {
      var data = await safeApiJson('/shop/public?shop_id=' + encodeURIComponent(shopId));
      if (!data.shop) {
        body.innerHTML = '<p class="pd-muted">Shop not found.</p>';
        return;
      }
      var shop = data.shop;
      var products = data.products || [];
      var reviews = data.reviews || [];
      _shopProducts = products; // kept for the per-card Buy buttons below
      var statsHtml =
        '<div class="shop-stats-row">' +
          '<div class="shop-stat"><strong>' + (shop.products_listed || products.length) + '</strong><span>Products</span></div>' +
          '<div class="shop-stat"><strong>' + (shop.orders_completed || 0) + '</strong><span>Orders</span></div>' +
          '<div class="shop-stat"><strong>' + (shop.total_reviews || reviews.length) + '</strong><span>Reviews</span></div>' +
          '<div class="shop-stat"><strong>' + (shop.likes || 0) + '</strong><span>Likes</span></div>' +
        '</div>';
      var reviewsHtml = reviews.length
        ? reviews.map(function (r) {
          return '<div class="pd-review-item"><div class="pd-review-head">' + renderStars(r.rating) +
            ' <strong>' + esc(r.reviewer_name || 'Customer') + '</strong></div>' +
            '<div class="pd-review-body">' + esc(r.comment || '') + '</div></div>';
        }).join('')
        : '<p class="pd-muted">No public reviews yet.</p>';
      body.innerHTML =
        '<div class="shop-profile-header">' +
          '<div class="shop-profile-icon"><i class="fa-solid fa-store"></i></div>' +
          '<div style="flex:1">' +
            '<h3 style="font-family:var(--f-display,var(--font-display,Georgia,serif));font-size:20px">' + esc(shop.shop_name || 'Unnamed Shop') + '</h3>' +
            '<p style="font-size:13px;color:var(--c-text3,var(--text3))">' + esc(shop.shop_category || 'Agricultural Products') + ' · ' + esc(shop.address_city || '') + ', ' + esc(shop.address_state || '') + '</p>' +
            '<div class="pd-modal-rating" style="margin:6px 0">' + renderStars(shop.avg_rating) + '</div>' +
          '</div></div>' +
        statsHtml +
        '<div class="shop-about-block"><h4><i class="fa-solid fa-circle-info"></i> About This Shop</h4>' +
          '<p class="shop-profile-desc">' + esc(shop.shop_description || 'Verified seller on the Aarvex Global marketplace.') + '</p></div>' +
        (shop.contact_number || shop.address_line
          ? '<div class="shop-about-block"><h4><i class="fa-solid fa-address-card"></i> Contact</h4>' +
            (shop.contact_number ? '<p class="shop-profile-desc"><i class="fa-solid fa-phone"></i> ' + esc(shop.contact_number) + '</p>' : '') +
            (shop.address_line ? '<p class="shop-profile-desc"><i class="fa-solid fa-location-dot"></i> ' + esc(shop.address_line) + '</p>' : '') +
          '</div>'
          : '') +
        '<h4 class="shop-products-title">Products (' + products.length + ')</h4>' +
        '<div class="shop-products-grid">' +
          (products.length ? products.map(function (p, i) {
            // Tap the card → full product detail (expanded view). Tap the
            // green Buy button → straight into the order form for that
            // product, skipping the detail step.
            return '<div class="shop-product-mini" onclick="ProductModal.closeShop();ProductModal.openById(\'' +
              esc(p.product_id).replace(/'/g, "\\'") + '\',\'' + esc(p.category_id).replace(/'/g, "\\'") + '\')">' +
              (p.image_url ? '<img src="' + esc(p.image_url) + '" alt="">' : '<div class="shop-mini-ph"><i class="fa-solid fa-seedling"></i></div>') +
              '<div><strong>' + esc(p.product_name) + '</strong><br><small>₹' + (p.price_per_kg || '—') + '/kg</small></div>' +
              '<button type="button" class="shop-mini-buy-btn" onclick="event.stopPropagation();ProductModal.buyShopProduct(' + i + ')"><i class="fa-solid fa-bolt"></i> Buy</button>' +
              '</div>';
          }).join('') : '<p class="pd-muted">No active products listed.</p>') +
        '</div>' +
        '<div class="shop-reviews-block"><h4><i class="fa-solid fa-star"></i> Public Reviews</h4>' + reviewsHtml + '</div>' +
        '<div class="shop-feedback-form">' +
          '<h4>Rate This Shop</h4>' +
          '<div class="pd-reaction-bar">' +
            '<button type="button" class="pd-react-btn like" onclick="ProductModal.reactShop(\'' + esc(shopId).replace(/'/g, "\\'") + '\',\'like\')"><i class="fa-solid fa-thumbs-up"></i> <span id="shopLikeCount">' + (shop.likes || 0) + '</span></button>' +
            '<button type="button" class="pd-react-btn dislike" onclick="ProductModal.reactShop(\'' + esc(shopId).replace(/'/g, "\\'") + '\',\'dislike\')"><i class="fa-solid fa-thumbs-down"></i> <span id="shopDislikeCount">' + (shop.dislikes || 0) + '</span></button>' +
          '</div>' +
          (getUser()
            ? '<h4 style="margin-top:16px">Private Message to Shop Owner</h4>' +
              '<p class="pd-muted">Only the shop owner sees this — not shown publicly.</p>' +
              '<textarea id="shopPrivateFeedback" rows="3" maxlength="400" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--c-border,#E4DBCA);font-family:inherit;font-size:13px" placeholder="Write your message…"></textarea>' +
              '<button type="button" class="pd-btn-primary" style="margin-top:8px" onclick="ProductModal.sendShopFeedback(\'' + esc(shopId).replace(/'/g, "\\'") + '\')"><i class="fa-solid fa-envelope"></i> Send Message</button>'
            : '<p class="pd-muted" style="margin-top:8px"><a href="portal.html" class="pd-link">Sign in</a> to send a private message.</p>') +
        '</div>';
    } catch (e) {
      console.error('[ShopProfile] load failed:', e);
      body.innerHTML = '<p class="pd-muted">Could not load shop profile. Please try again.</p><p class="pd-muted" style="font-size:11px;margin-top:6px">Error: ' + esc(String(e)) + '</p>';
    }
  }

  async function sendShopFeedback(shopId) {
    var user = getUser();
    var token = localStorage.getItem('ax_google_token');
    var msg = (document.getElementById('shopPrivateFeedback')?.value || '').trim();
    if (!msg) { toast('Please enter your feedback', 'error'); return; }
    if (!user) { toast('Sign in to send feedback', 'warning'); return; }
    try {
      var headers = { 'Content-Type': 'application/json' };
      if (token) headers.Authorization = 'Bearer ' + token;
      var res = await fetch(apiUrl('/shop/feedback'), {
        method: 'POST', headers: headers,
        body: JSON.stringify({ shop_id: shopId, message: msg })
      });
      var data = await res.json();
      if (data.success) {
        toast('Feedback sent to the shop owner', 'success');
        document.getElementById('shopPrivateFeedback').value = '';
      } else toast(data.error || 'Could not send feedback', 'error');
    } catch (e) { toast('Network error', 'error'); }
  }

  function closeShop() {
    document.getElementById('shopProfileModal')?.classList.remove('open');
    if (_lastFocusedEl && typeof _lastFocusedEl.focus === 'function') _lastFocusedEl.focus();
    _lastFocusedEl = null;
  }

  /* Buy button on a shop-profile product card — jumps straight into the
     order form (portal) or the product detail (public site, where the
     order form lives on portal.html). */
  var _shopProducts = [];
  function buyShopProduct(index) {
    var p = _shopProducts[index];
    if (!p) return;
    closeShop();
    if (typeof global.selectProductForOrder === 'function') {
      global.selectProductForOrder(p);
    } else {
      redirectToPortalOrder(p);
    }
  }

  function listingModifyAllowed(dateStr) {
    if (!dateStr) return false;
    return (Date.now() - new Date(dateStr).getTime()) < LISTING_MODIFY_MS;
  }

  var _lastFocusedEl = null;

  function init() {
    document.getElementById('productDetailModal')?.addEventListener('click', function (e) {
      if (e.target.id === 'productDetailModal') closeModal();
    });
    document.getElementById('shopProfileModal')?.addEventListener('click', function (e) {
      if (e.target.id === 'shopProfileModal') closeShop();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      var pd = document.getElementById('productDetailModal');
      var sp = document.getElementById('shopProfileModal');
      if (sp && sp.classList.contains('open')) closeShop();
      else if (pd && pd.classList.contains('open')) closeModal();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  global.ProductModal = {
    openModal: openModal,
    openById: openById,
    closeModal: closeModal,
    orderViaPortal: orderViaPortal,
    buy: buy,
    toggleDesc: toggleDesc,
    setReviewStar: setReviewStar,
    submitReview: submitReview,
    openShopProfile: openShopProfile,
    closeShop: closeShop,
    buyShopProduct: buyShopProduct,
    reactShop: reactShop,
    sendShopFeedback: sendShopFeedback,
    searchShop: function (q) {
      var raw = (q || '').trim();
      if (/shop[-\s]?ax|^\d{4,5}$/i.test(raw)) {
        openShopProfile(normalizeShopId(raw));
        return true;
      }
      return false;
    },
    normalizeShopId: normalizeShopId,
    listingModifyAllowed: listingModifyAllowed,
    LISTING_MODIFY_MS: LISTING_MODIFY_MS
  };

  global.openProductModalById = openById;
  global.openProductModal = openModal;
  global.closeProductModal = closeModal;
})(typeof window !== 'undefined' ? window : this);
