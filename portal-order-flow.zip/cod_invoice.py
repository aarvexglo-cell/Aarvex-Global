"""
Cash-on-Delivery Invoice — separate from the online-payment invoice
(advanced_features._generate_invoice).

WHY A SEPARATE FILE:
  - Online invoices fire from the Razorpay webhook (payment.captured).
    COD orders never hit that webhook, so they never got an invoice at all.
  - COD invoices are generated only once delivery is confirmed (OTP
    verified, cash actually collected) — not at order placement — so the
    "amount due" printed always matches what was actually paid.
  - Keeping this in its own module means changes to COD invoicing can
    never accidentally break the online-payment invoice path, and vice versa.

Called from delivery.handle_delivery_complete() right after a COD order
is marked COMPLETED.
"""

from __future__ import annotations

import io
import logging
import os
from datetime import datetime, timezone
from decimal import Decimal

import boto3

logger = logging.getLogger()

S3_BUCKET_FOR_INVOICES = os.environ.get("S3_BUCKET_FOR_INVOICES", "")
COMPANY_NAME = os.environ.get("COMPANY_NAME", "Aarvex Global")
COMPANY_GST_NUMBER = os.environ.get("COMPANY_GST_NUMBER") or os.environ.get("COMPANY_GST", "")
COMPANY_ADDRESS = os.environ.get("COMPANY_ADDRESS", "Warora, Chandrapur, Maharashtra, India")
COMPANY_PHONE = os.environ.get("COMPANY_PHONE", "+91-8767205473")
COMPANY_EMAIL = os.environ.get("COMPANY_EMAIL", "aarvexglo@gmail.com")

s3 = boto3.client("s3")
ses = boto3.client("ses", region_name=os.environ.get("SES_REGION", "ap-south-1"))


def _money(v) -> str:
    try:
        return f"{Decimal(str(v)):,.2f}"
    except Exception:
        return str(v)


def generate_cod_invoice(delivery_record: dict) -> str:
    """Build + upload a COD invoice PDF. Returns a presigned S3 URL (or "").

    delivery_record is the DELIVERY#ARN#{arn} item — it already carries
    everything needed (lot_price, delivery_charge, platform_fee, gst_amount,
    cod_amount, buyer_name, buyer_email, buyer_gst_number) because
    create_delivery_record() was extended to store it at order time.
    """
    if not S3_BUCKET_FOR_INVOICES:
        logger.warning("[COD_INVOICE] S3_BUCKET_FOR_INVOICES not configured — skipping.")
        return ""

    arn = delivery_record.get("arn", "")
    if not arn:
        return ""

    lot_price = delivery_record.get("lot_price", 0)
    delivery_charge = delivery_record.get("delivery_charge", 0)
    platform_fee = delivery_record.get("platform_fee", 0)
    gst_amount = delivery_record.get("gst_amount", 0)
    cod_amount = delivery_record.get("cod_amount", 0)

    key = f"invoices/cod/{arn}/invoice_cod_{arn}.pdf"
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas

        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        y = 800

        def line(text, size=11, gap=18, bold=False):
            nonlocal y
            c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
            c.drawString(50, y, str(text)[:100])
            y -= gap

        line(COMPANY_NAME, 14, 20, bold=True)
        line(COMPANY_ADDRESS)
        line(f"GST: {COMPANY_GST_NUMBER}")
        line(f"Email: {COMPANY_EMAIL}  |  Phone: {COMPANY_PHONE}")
        y -= 8
        line("CASH ON DELIVERY — INVOICE", 13, 22, bold=True)
        line(f"Invoice No: INV-COD-{arn}")
        line(f"Order ID: {arn}")
        line(f"Date: {datetime.now(timezone.utc).date().isoformat()}")
        line(f"Delivery completed: {delivery_record.get('completed_at', '')}")
        y -= 8
        line("BILL TO:", bold=True)
        line(delivery_record.get("buyer_name", "") or "Customer")
        line(delivery_record.get("delivery_city", ""))
        if delivery_record.get("buyer_gst_number"):
            line(f"GST: {delivery_record.get('buyer_gst_number')}")
        y -= 8
        line(f"Product: {delivery_record.get('product_name', '')}")
        line(f"Quantity: {delivery_record.get('lot_size_kg', '')} kg")
        y -= 10

        # ── full breakdown — this is the part the old invoice never showed ──
        line("PAYMENT BREAKDOWN (Cash Collected on Delivery)", 11, 20, bold=True)
        line(f"Product / Lot Price ............ INR {_money(lot_price)}")
        line(f"Delivery Charge ................. INR {_money(delivery_charge)}")
        line(f"Platform Fee ..................... INR {_money(platform_fee)}")
        line(f"GST .............................. INR {_money(gst_amount)}")
        y -= 6
        line(f"TOTAL CASH COLLECTED ............ INR {_money(cod_amount)}", 13, 22, bold=True)
        y -= 10
        line("Payment Mode: Cash on Delivery (collected by delivery partner)")
        line(f"Tracking Key: {delivery_record.get('tracking_key', '')}")
        y -= 20
        line("This is a system-generated invoice. Thank you for choosing " + COMPANY_NAME + ".", 9, 14)

        c.save()
        s3.put_object(
            Bucket=S3_BUCKET_FOR_INVOICES,
            Key=key,
            Body=buffer.getvalue(),
            ContentType="application/pdf",
        )
        url = s3.generate_presigned_url(
            "get_object", Params={"Bucket": S3_BUCKET_FOR_INVOICES, "Key": key}, ExpiresIn=604800
        )
    except Exception as e:
        logger.error("[COD_INVOICE] PDF generation failed for %s: %s", arn, e, exc_info=True)
        return ""

    # Best-effort delivery of the invoice — never let this fail the
    # already-completed delivery.
    _notify_buyer(delivery_record, url)
    _email_buyer(delivery_record, url)
    return url


def _notify_buyer(delivery_record: dict, invoice_url: str) -> None:
    importer_sub = delivery_record.get("importer_sub", "")
    if not importer_sub or not invoice_url:
        return
    try:
        from marketplace import create_notification
        create_notification(
            importer_sub,
            "shop_status",
            "COD Invoice ready",
            f"Your Cash-on-Delivery invoice for order {delivery_record.get('arn', '')} is ready.\n{invoice_url}",
            arn=delivery_record.get("arn", ""),
        )
    except Exception as e:
        logger.warning("[COD_INVOICE] in-app notification failed: %s", e)


def _email_buyer(delivery_record: dict, invoice_url: str) -> None:
    email = delivery_record.get("buyer_email", "")
    if not email or not invoice_url:
        return
    arn = delivery_record.get("arn", "")
    subject = f"COD Invoice — Order {arn} | {COMPANY_NAME}"
    text = f"Your Cash-on-Delivery order {arn} has been delivered. Invoice: {invoice_url}"
    html = (
        f"<h2>Delivered — Cash on Delivery</h2>"
        f"<p>Order ID: <b>{arn}</b></p>"
        f"<p>Amount collected: INR {_money(delivery_record.get('cod_amount', 0))}</p>"
        f"<p>Invoice: <a href='{invoice_url}'>Download invoice</a></p>"
        f"<p>{COMPANY_NAME}<br>{COMPANY_PHONE}</p>"
    )
    try:
        ses.send_email(
            Source=COMPANY_EMAIL,
            Destination={"ToAddresses": [email]},
            Message={"Subject": {"Data": subject}, "Body": {"Text": {"Data": text}, "Html": {"Data": html}}},
        )
    except Exception as e:
        logger.warning("[COD_INVOICE] email send failed: %s", e)